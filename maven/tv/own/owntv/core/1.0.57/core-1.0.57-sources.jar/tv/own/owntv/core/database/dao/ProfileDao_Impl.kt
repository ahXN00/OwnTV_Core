package tv.own.owntv.core.database.dao

import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.ProfileEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class ProfileDao_Impl(
  __db: RoomDatabase,
) : ProfileDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfProfileEntity: EntityInsertAdapter<ProfileEntity>

  private val __deleteAdapterOfProfileEntity: EntityDeleteOrUpdateAdapter<ProfileEntity>

  private val __updateAdapterOfProfileEntity: EntityDeleteOrUpdateAdapter<ProfileEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfProfileEntity = object : EntityInsertAdapter<ProfileEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `profiles` (`id`,`name`,`avatarColor`,`avatarId`,`avatarPath`,`isKids`,`pinHash`,`createdAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ProfileEntity) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindLong(3, entity.avatarColor.toLong())
        statement.bindLong(4, entity.avatarId.toLong())
        val _tmpAvatarPath: String? = entity.avatarPath
        if (_tmpAvatarPath == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpAvatarPath)
        }
        val _tmp: Int = if (entity.isKids) 1 else 0
        statement.bindLong(6, _tmp.toLong())
        val _tmpPinHash: String? = entity.pinHash
        if (_tmpPinHash == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpPinHash)
        }
        statement.bindLong(8, entity.createdAt)
      }
    }
    this.__deleteAdapterOfProfileEntity = object : EntityDeleteOrUpdateAdapter<ProfileEntity>() {
      protected override fun createQuery(): String = "DELETE FROM `profiles` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: ProfileEntity) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfProfileEntity = object : EntityDeleteOrUpdateAdapter<ProfileEntity>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `profiles` SET `id` = ?,`name` = ?,`avatarColor` = ?,`avatarId` = ?,`avatarPath` = ?,`isKids` = ?,`pinHash` = ?,`createdAt` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: ProfileEntity) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindLong(3, entity.avatarColor.toLong())
        statement.bindLong(4, entity.avatarId.toLong())
        val _tmpAvatarPath: String? = entity.avatarPath
        if (_tmpAvatarPath == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpAvatarPath)
        }
        val _tmp: Int = if (entity.isKids) 1 else 0
        statement.bindLong(6, _tmp.toLong())
        val _tmpPinHash: String? = entity.pinHash
        if (_tmpPinHash == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpPinHash)
        }
        statement.bindLong(8, entity.createdAt)
        statement.bindLong(9, entity.id)
      }
    }
  }

  public override suspend fun insert(profile: ProfileEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfProfileEntity.insertAndReturnId(_connection, profile)
    _result
  }

  public override suspend fun delete(profile: ProfileEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfProfileEntity.handle(_connection, profile)
  }

  public override suspend fun update(profile: ProfileEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfProfileEntity.handle(_connection, profile)
  }

  public override fun observeAll(): Flow<List<ProfileEntity>> {
    val _sql: String = "SELECT * FROM profiles ORDER BY createdAt ASC"
    return createFlow(__db, false, arrayOf("profiles")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAvatarColor: Int = getColumnIndexOrThrow(_stmt, "avatarColor")
        val _columnIndexOfAvatarId: Int = getColumnIndexOrThrow(_stmt, "avatarId")
        val _columnIndexOfAvatarPath: Int = getColumnIndexOrThrow(_stmt, "avatarPath")
        val _columnIndexOfIsKids: Int = getColumnIndexOrThrow(_stmt, "isKids")
        val _columnIndexOfPinHash: Int = getColumnIndexOrThrow(_stmt, "pinHash")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<ProfileEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ProfileEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAvatarColor: Int
          _tmpAvatarColor = _stmt.getLong(_columnIndexOfAvatarColor).toInt()
          val _tmpAvatarId: Int
          _tmpAvatarId = _stmt.getLong(_columnIndexOfAvatarId).toInt()
          val _tmpAvatarPath: String?
          if (_stmt.isNull(_columnIndexOfAvatarPath)) {
            _tmpAvatarPath = null
          } else {
            _tmpAvatarPath = _stmt.getText(_columnIndexOfAvatarPath)
          }
          val _tmpIsKids: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsKids).toInt()
          _tmpIsKids = _tmp != 0
          val _tmpPinHash: String?
          if (_stmt.isNull(_columnIndexOfPinHash)) {
            _tmpPinHash = null
          } else {
            _tmpPinHash = _stmt.getText(_columnIndexOfPinHash)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = ProfileEntity(_tmpId,_tmpName,_tmpAvatarColor,_tmpAvatarId,_tmpAvatarPath,_tmpIsKids,_tmpPinHash,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<ProfileEntity> {
    val _sql: String = "SELECT * FROM profiles ORDER BY createdAt ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAvatarColor: Int = getColumnIndexOrThrow(_stmt, "avatarColor")
        val _columnIndexOfAvatarId: Int = getColumnIndexOrThrow(_stmt, "avatarId")
        val _columnIndexOfAvatarPath: Int = getColumnIndexOrThrow(_stmt, "avatarPath")
        val _columnIndexOfIsKids: Int = getColumnIndexOrThrow(_stmt, "isKids")
        val _columnIndexOfPinHash: Int = getColumnIndexOrThrow(_stmt, "pinHash")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<ProfileEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ProfileEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAvatarColor: Int
          _tmpAvatarColor = _stmt.getLong(_columnIndexOfAvatarColor).toInt()
          val _tmpAvatarId: Int
          _tmpAvatarId = _stmt.getLong(_columnIndexOfAvatarId).toInt()
          val _tmpAvatarPath: String?
          if (_stmt.isNull(_columnIndexOfAvatarPath)) {
            _tmpAvatarPath = null
          } else {
            _tmpAvatarPath = _stmt.getText(_columnIndexOfAvatarPath)
          }
          val _tmpIsKids: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsKids).toInt()
          _tmpIsKids = _tmp != 0
          val _tmpPinHash: String?
          if (_stmt.isNull(_columnIndexOfPinHash)) {
            _tmpPinHash = null
          } else {
            _tmpPinHash = _stmt.getText(_columnIndexOfPinHash)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = ProfileEntity(_tmpId,_tmpName,_tmpAvatarColor,_tmpAvatarId,_tmpAvatarPath,_tmpIsKids,_tmpPinHash,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getById(id: Long): ProfileEntity? {
    val _sql: String = "SELECT * FROM profiles WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAvatarColor: Int = getColumnIndexOrThrow(_stmt, "avatarColor")
        val _columnIndexOfAvatarId: Int = getColumnIndexOrThrow(_stmt, "avatarId")
        val _columnIndexOfAvatarPath: Int = getColumnIndexOrThrow(_stmt, "avatarPath")
        val _columnIndexOfIsKids: Int = getColumnIndexOrThrow(_stmt, "isKids")
        val _columnIndexOfPinHash: Int = getColumnIndexOrThrow(_stmt, "pinHash")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: ProfileEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAvatarColor: Int
          _tmpAvatarColor = _stmt.getLong(_columnIndexOfAvatarColor).toInt()
          val _tmpAvatarId: Int
          _tmpAvatarId = _stmt.getLong(_columnIndexOfAvatarId).toInt()
          val _tmpAvatarPath: String?
          if (_stmt.isNull(_columnIndexOfAvatarPath)) {
            _tmpAvatarPath = null
          } else {
            _tmpAvatarPath = _stmt.getText(_columnIndexOfAvatarPath)
          }
          val _tmpIsKids: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsKids).toInt()
          _tmpIsKids = _tmp != 0
          val _tmpPinHash: String?
          if (_stmt.isNull(_columnIndexOfPinHash)) {
            _tmpPinHash = null
          } else {
            _tmpPinHash = _stmt.getText(_columnIndexOfPinHash)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _result = ProfileEntity(_tmpId,_tmpName,_tmpAvatarColor,_tmpAvatarId,_tmpAvatarPath,_tmpIsKids,_tmpPinHash,_tmpCreatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeById(id: Long): Flow<ProfileEntity?> {
    val _sql: String = "SELECT * FROM profiles WHERE id = ?"
    return createFlow(__db, false, arrayOf("profiles")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAvatarColor: Int = getColumnIndexOrThrow(_stmt, "avatarColor")
        val _columnIndexOfAvatarId: Int = getColumnIndexOrThrow(_stmt, "avatarId")
        val _columnIndexOfAvatarPath: Int = getColumnIndexOrThrow(_stmt, "avatarPath")
        val _columnIndexOfIsKids: Int = getColumnIndexOrThrow(_stmt, "isKids")
        val _columnIndexOfPinHash: Int = getColumnIndexOrThrow(_stmt, "pinHash")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: ProfileEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAvatarColor: Int
          _tmpAvatarColor = _stmt.getLong(_columnIndexOfAvatarColor).toInt()
          val _tmpAvatarId: Int
          _tmpAvatarId = _stmt.getLong(_columnIndexOfAvatarId).toInt()
          val _tmpAvatarPath: String?
          if (_stmt.isNull(_columnIndexOfAvatarPath)) {
            _tmpAvatarPath = null
          } else {
            _tmpAvatarPath = _stmt.getText(_columnIndexOfAvatarPath)
          }
          val _tmpIsKids: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsKids).toInt()
          _tmpIsKids = _tmp != 0
          val _tmpPinHash: String?
          if (_stmt.isNull(_columnIndexOfPinHash)) {
            _tmpPinHash = null
          } else {
            _tmpPinHash = _stmt.getText(_columnIndexOfPinHash)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _result = ProfileEntity(_tmpId,_tmpName,_tmpAvatarColor,_tmpAvatarId,_tmpAvatarPath,_tmpIsKids,_tmpPinHash,_tmpCreatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun count(): Int {
    val _sql: String = "SELECT COUNT(*) FROM profiles"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAll() {
    val _sql: String = "DELETE FROM profiles"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setAvatar(id: Long, avatarId: Int) {
    val _sql: String = "UPDATE profiles SET avatarId = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, avatarId.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setAvatarPath(id: Long, path: String?) {
    val _sql: String = "UPDATE profiles SET avatarPath = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (path == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, path)
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setPin(id: Long, pinHash: String?) {
    val _sql: String = "UPDATE profiles SET pinHash = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (pinHash == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, pinHash)
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
