package tv.own.owntv.core.database.dao

import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.RecordingEntity
import tv.own.owntv.core.database.entity.RecordingRuleEntity
import tv.own.owntv.core.model.RecordingFailure
import tv.own.owntv.core.model.RecordingStatus

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class RecordingDao_Impl(
  __db: RoomDatabase,
) : RecordingDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfRecordingEntity: EntityInsertAdapter<RecordingEntity>

  private val __converters: Converters = Converters()

  private val __insertAdapterOfRecordingRuleEntity: EntityInsertAdapter<RecordingRuleEntity>

  private val __deleteAdapterOfRecordingEntity: EntityDeleteOrUpdateAdapter<RecordingEntity>

  private val __deleteAdapterOfRecordingRuleEntity: EntityDeleteOrUpdateAdapter<RecordingRuleEntity>

  private val __updateAdapterOfRecordingEntity: EntityDeleteOrUpdateAdapter<RecordingEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfRecordingEntity = object : EntityInsertAdapter<RecordingEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `recordings` (`id`,`profileId`,`sourceId`,`channelId`,`channelName`,`channelIconUrl`,`epgChannelId`,`streamUrl`,`httpHeaders`,`title`,`description`,`programmeStartMs`,`programmeStopMs`,`startMs`,`stopMs`,`status`,`failure`,`filePath`,`bytes`,`startedAt`,`endedAt`,`ruleId`,`createdAt`,`updatedAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        statement.bindLong(3, entity.sourceId)
        statement.bindLong(4, entity.channelId)
        statement.bindText(5, entity.channelName)
        val _tmpChannelIconUrl: String? = entity.channelIconUrl
        if (_tmpChannelIconUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpChannelIconUrl)
        }
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpEpgChannelId)
        }
        statement.bindText(8, entity.streamUrl)
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpHttpHeaders)
        }
        statement.bindText(10, entity.title)
        val _tmpDescription: String? = entity.description
        if (_tmpDescription == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpDescription)
        }
        statement.bindLong(12, entity.programmeStartMs)
        statement.bindLong(13, entity.programmeStopMs)
        statement.bindLong(14, entity.startMs)
        statement.bindLong(15, entity.stopMs)
        val _tmp: String = __converters.recordingStatusToString(entity.status)
        statement.bindText(16, _tmp)
        val _tmp_1: String = __converters.recordingFailureToString(entity.failure)
        statement.bindText(17, _tmp_1)
        val _tmpFilePath: String? = entity.filePath
        if (_tmpFilePath == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpFilePath)
        }
        statement.bindLong(19, entity.bytes)
        val _tmpStartedAt: Long? = entity.startedAt
        if (_tmpStartedAt == null) {
          statement.bindNull(20)
        } else {
          statement.bindLong(20, _tmpStartedAt)
        }
        val _tmpEndedAt: Long? = entity.endedAt
        if (_tmpEndedAt == null) {
          statement.bindNull(21)
        } else {
          statement.bindLong(21, _tmpEndedAt)
        }
        val _tmpRuleId: Long? = entity.ruleId
        if (_tmpRuleId == null) {
          statement.bindNull(22)
        } else {
          statement.bindLong(22, _tmpRuleId)
        }
        statement.bindLong(23, entity.createdAt)
        statement.bindLong(24, entity.updatedAt)
      }
    }
    this.__insertAdapterOfRecordingRuleEntity = object : EntityInsertAdapter<RecordingRuleEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `recording_rules` (`id`,`profileId`,`sourceId`,`channelId`,`channelName`,`epgChannelId`,`title`,`titleKey`,`enabled`,`createdAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingRuleEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        statement.bindLong(3, entity.sourceId)
        statement.bindLong(4, entity.channelId)
        statement.bindText(5, entity.channelName)
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpEpgChannelId)
        }
        statement.bindText(7, entity.title)
        statement.bindText(8, entity.titleKey)
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(9, _tmp.toLong())
        statement.bindLong(10, entity.createdAt)
      }
    }
    this.__deleteAdapterOfRecordingEntity = object : EntityDeleteOrUpdateAdapter<RecordingEntity>() {
      protected override fun createQuery(): String = "DELETE FROM `recordings` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingEntity) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__deleteAdapterOfRecordingRuleEntity = object : EntityDeleteOrUpdateAdapter<RecordingRuleEntity>() {
      protected override fun createQuery(): String = "DELETE FROM `recording_rules` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingRuleEntity) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfRecordingEntity = object : EntityDeleteOrUpdateAdapter<RecordingEntity>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `recordings` SET `id` = ?,`profileId` = ?,`sourceId` = ?,`channelId` = ?,`channelName` = ?,`channelIconUrl` = ?,`epgChannelId` = ?,`streamUrl` = ?,`httpHeaders` = ?,`title` = ?,`description` = ?,`programmeStartMs` = ?,`programmeStopMs` = ?,`startMs` = ?,`stopMs` = ?,`status` = ?,`failure` = ?,`filePath` = ?,`bytes` = ?,`startedAt` = ?,`endedAt` = ?,`ruleId` = ?,`createdAt` = ?,`updatedAt` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: RecordingEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        statement.bindLong(3, entity.sourceId)
        statement.bindLong(4, entity.channelId)
        statement.bindText(5, entity.channelName)
        val _tmpChannelIconUrl: String? = entity.channelIconUrl
        if (_tmpChannelIconUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpChannelIconUrl)
        }
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpEpgChannelId)
        }
        statement.bindText(8, entity.streamUrl)
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpHttpHeaders)
        }
        statement.bindText(10, entity.title)
        val _tmpDescription: String? = entity.description
        if (_tmpDescription == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpDescription)
        }
        statement.bindLong(12, entity.programmeStartMs)
        statement.bindLong(13, entity.programmeStopMs)
        statement.bindLong(14, entity.startMs)
        statement.bindLong(15, entity.stopMs)
        val _tmp: String = __converters.recordingStatusToString(entity.status)
        statement.bindText(16, _tmp)
        val _tmp_1: String = __converters.recordingFailureToString(entity.failure)
        statement.bindText(17, _tmp_1)
        val _tmpFilePath: String? = entity.filePath
        if (_tmpFilePath == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpFilePath)
        }
        statement.bindLong(19, entity.bytes)
        val _tmpStartedAt: Long? = entity.startedAt
        if (_tmpStartedAt == null) {
          statement.bindNull(20)
        } else {
          statement.bindLong(20, _tmpStartedAt)
        }
        val _tmpEndedAt: Long? = entity.endedAt
        if (_tmpEndedAt == null) {
          statement.bindNull(21)
        } else {
          statement.bindLong(21, _tmpEndedAt)
        }
        val _tmpRuleId: Long? = entity.ruleId
        if (_tmpRuleId == null) {
          statement.bindNull(22)
        } else {
          statement.bindLong(22, _tmpRuleId)
        }
        statement.bindLong(23, entity.createdAt)
        statement.bindLong(24, entity.updatedAt)
        statement.bindLong(25, entity.id)
      }
    }
  }

  public override suspend fun upsert(recording: RecordingEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfRecordingEntity.insertAndReturnId(_connection, recording)
    _result
  }

  public override suspend fun upsertRule(rule: RecordingRuleEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfRecordingRuleEntity.insertAndReturnId(_connection, rule)
    _result
  }

  public override suspend fun delete(recording: RecordingEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfRecordingEntity.handle(_connection, recording)
  }

  public override suspend fun deleteRule(rule: RecordingRuleEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfRecordingRuleEntity.handle(_connection, rule)
  }

  public override suspend fun update(recording: RecordingEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfRecordingEntity.handle(_connection, recording)
  }

  public override suspend fun getById(id: Long): RecordingEntity? {
    val _sql: String = "SELECT * FROM recordings WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: RecordingEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeForProfile(profileId: Long): Flow<List<RecordingEntity>> {
    val _sql: String = "SELECT * FROM recordings WHERE profileId = ? ORDER BY startMs DESC"
    return createFlow(__db, false, arrayOf("recordings")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeRunning(): Flow<List<RecordingEntity>> {
    val _sql: String = "SELECT * FROM recordings WHERE status = 'RECORDING' ORDER BY startMs ASC"
    return createFlow(__db, false, arrayOf("recordings")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun running(): List<RecordingEntity> {
    val _sql: String = "SELECT * FROM recordings WHERE status = 'RECORDING' ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun scheduled(): List<RecordingEntity> {
    val _sql: String = "SELECT * FROM recordings WHERE status = 'SCHEDULED' ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun dueAt(now: Long): List<RecordingEntity> {
    val _sql: String = "SELECT * FROM recordings WHERE status IN ('SCHEDULED', 'RECORDING') AND startMs <= ? AND stopMs > ? ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, now)
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun runningCountForSource(sourceId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM recordings WHERE sourceId = ? AND status = 'RECORDING'"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun overlapping(
    sourceId: Long,
    startMs: Long,
    stopMs: Long,
    excludeId: Long,
  ): List<RecordingEntity> {
    val _sql: String = "SELECT * FROM recordings WHERE sourceId = ? AND id != ? AND status IN ('SCHEDULED', 'RECORDING') AND startMs < ? AND stopMs > ? ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, excludeId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, stopMs)
        _argIndex = 4
        _stmt.bindLong(_argIndex, startMs)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<RecordingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun forProgramme(
    profileId: Long,
    channelId: Long,
    programmeStartMs: Long,
  ): RecordingEntity? {
    val _sql: String = "SELECT * FROM recordings WHERE profileId = ? AND channelId = ? AND programmeStartMs = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, channelId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, programmeStartMs)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfChannelIconUrl: Int = getColumnIndexOrThrow(_stmt, "channelIconUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfProgrammeStartMs: Int = getColumnIndexOrThrow(_stmt, "programmeStartMs")
        val _columnIndexOfProgrammeStopMs: Int = getColumnIndexOrThrow(_stmt, "programmeStopMs")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfFailure: Int = getColumnIndexOrThrow(_stmt, "failure")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfBytes: Int = getColumnIndexOrThrow(_stmt, "bytes")
        val _columnIndexOfStartedAt: Int = getColumnIndexOrThrow(_stmt, "startedAt")
        val _columnIndexOfEndedAt: Int = getColumnIndexOrThrow(_stmt, "endedAt")
        val _columnIndexOfRuleId: Int = getColumnIndexOrThrow(_stmt, "ruleId")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: RecordingEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpChannelIconUrl: String?
          if (_stmt.isNull(_columnIndexOfChannelIconUrl)) {
            _tmpChannelIconUrl = null
          } else {
            _tmpChannelIconUrl = _stmt.getText(_columnIndexOfChannelIconUrl)
          }
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpProgrammeStartMs: Long
          _tmpProgrammeStartMs = _stmt.getLong(_columnIndexOfProgrammeStartMs)
          val _tmpProgrammeStopMs: Long
          _tmpProgrammeStopMs = _stmt.getLong(_columnIndexOfProgrammeStopMs)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpStatus: RecordingStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToRecordingStatus(_tmp)
          val _tmpFailure: RecordingFailure
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfFailure)
          _tmpFailure = __converters.stringToRecordingFailure(_tmp_1)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpBytes: Long
          _tmpBytes = _stmt.getLong(_columnIndexOfBytes)
          val _tmpStartedAt: Long?
          if (_stmt.isNull(_columnIndexOfStartedAt)) {
            _tmpStartedAt = null
          } else {
            _tmpStartedAt = _stmt.getLong(_columnIndexOfStartedAt)
          }
          val _tmpEndedAt: Long?
          if (_stmt.isNull(_columnIndexOfEndedAt)) {
            _tmpEndedAt = null
          } else {
            _tmpEndedAt = _stmt.getLong(_columnIndexOfEndedAt)
          }
          val _tmpRuleId: Long?
          if (_stmt.isNull(_columnIndexOfRuleId)) {
            _tmpRuleId = null
          } else {
            _tmpRuleId = _stmt.getLong(_columnIndexOfRuleId)
          }
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = RecordingEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpChannelIconUrl,_tmpEpgChannelId,_tmpStreamUrl,_tmpHttpHeaders,_tmpTitle,_tmpDescription,_tmpProgrammeStartMs,_tmpProgrammeStopMs,_tmpStartMs,_tmpStopMs,_tmpStatus,_tmpFailure,_tmpFilePath,_tmpBytes,_tmpStartedAt,_tmpEndedAt,_tmpRuleId,_tmpCreatedAt,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeRules(profileId: Long): Flow<List<RecordingRuleEntity>> {
    val _sql: String = "SELECT * FROM recording_rules WHERE profileId = ? ORDER BY title ASC"
    return createFlow(__db, false, arrayOf("recording_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfTitleKey: Int = getColumnIndexOrThrow(_stmt, "titleKey")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<RecordingRuleEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingRuleEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpTitleKey: String
          _tmpTitleKey = _stmt.getText(_columnIndexOfTitleKey)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = RecordingRuleEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpTitleKey,_tmpEnabled,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabledRules(): List<RecordingRuleEntity> {
    val _sql: String = "SELECT * FROM recording_rules WHERE enabled = 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfTitleKey: Int = getColumnIndexOrThrow(_stmt, "titleKey")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: MutableList<RecordingRuleEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: RecordingRuleEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpTitleKey: String
          _tmpTitleKey = _stmt.getText(_columnIndexOfTitleKey)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _item = RecordingRuleEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpTitleKey,_tmpEnabled,_tmpCreatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findRule(
    profileId: Long,
    channelId: Long,
    titleKey: String,
  ): RecordingRuleEntity? {
    val _sql: String = "SELECT * FROM recording_rules WHERE profileId = ? AND channelId = ? AND titleKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, channelId)
        _argIndex = 3
        _stmt.bindText(_argIndex, titleKey)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfChannelId: Int = getColumnIndexOrThrow(_stmt, "channelId")
        val _columnIndexOfChannelName: Int = getColumnIndexOrThrow(_stmt, "channelName")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfTitleKey: Int = getColumnIndexOrThrow(_stmt, "titleKey")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _result: RecordingRuleEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpChannelId: Long
          _tmpChannelId = _stmt.getLong(_columnIndexOfChannelId)
          val _tmpChannelName: String
          _tmpChannelName = _stmt.getText(_columnIndexOfChannelName)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpTitleKey: String
          _tmpTitleKey = _stmt.getText(_columnIndexOfTitleKey)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          _result = RecordingRuleEntity(_tmpId,_tmpProfileId,_tmpSourceId,_tmpChannelId,_tmpChannelName,_tmpEpgChannelId,_tmpTitle,_tmpTitleKey,_tmpEnabled,_tmpCreatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateProgress(
    id: Long,
    status: RecordingStatus,
    failure: RecordingFailure,
    bytes: Long,
    filePath: String?,
    startedAt: Long?,
    endedAt: Long?,
    timestamp: Long,
  ) {
    val _sql: String = "UPDATE recordings SET status = ?, failure = ?, bytes = ?, filePath = ?, startedAt = ?, endedAt = ?, updatedAt = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: String = __converters.recordingStatusToString(status)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 2
        val _tmp_1: String = __converters.recordingFailureToString(failure)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 3
        _stmt.bindLong(_argIndex, bytes)
        _argIndex = 4
        if (filePath == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, filePath)
        }
        _argIndex = 5
        if (startedAt == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, startedAt)
        }
        _argIndex = 6
        if (endedAt == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, endedAt)
        }
        _argIndex = 7
        _stmt.bindLong(_argIndex, timestamp)
        _argIndex = 8
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
