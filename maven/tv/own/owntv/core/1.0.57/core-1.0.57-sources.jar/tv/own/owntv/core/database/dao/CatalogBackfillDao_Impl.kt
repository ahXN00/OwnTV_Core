package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.CatalogBackfillEntity
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class CatalogBackfillDao_Impl(
  __db: RoomDatabase,
) : CatalogBackfillDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfCatalogBackfillEntity: EntityInsertAdapter<CatalogBackfillEntity>

  private val __converters: Converters = Converters()
  init {
    this.__db = __db
    this.__insertAdapterOfCatalogBackfillEntity = object : EntityInsertAdapter<CatalogBackfillEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `catalog_backfill` (`sourceId`,`mediaType`,`categoryRemoteId`,`categoryDbId`,`totalItems`,`maxPageItems`,`nextPage`,`lastPage`,`sortBase`,`done`) VALUES (?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: CatalogBackfillEntity) {
        statement.bindLong(1, entity.sourceId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(2, _tmp)
        statement.bindText(3, entity.categoryRemoteId)
        val _tmpCategoryDbId: Long? = entity.categoryDbId
        if (_tmpCategoryDbId == null) {
          statement.bindNull(4)
        } else {
          statement.bindLong(4, _tmpCategoryDbId)
        }
        statement.bindLong(5, entity.totalItems.toLong())
        statement.bindLong(6, entity.maxPageItems.toLong())
        statement.bindLong(7, entity.nextPage.toLong())
        statement.bindLong(8, entity.lastPage.toLong())
        statement.bindLong(9, entity.sortBase.toLong())
        val _tmp_1: Int = if (entity.done) 1 else 0
        statement.bindLong(10, _tmp_1.toLong())
      }
    }
  }

  public override suspend fun upsertAll(rows: List<CatalogBackfillEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfCatalogBackfillEntity.insert(_connection, rows)
  }

  public override suspend fun pending(sourceId: Long, mediaType: MediaType): List<CatalogBackfillEntity> {
    val _sql: String = "SELECT * FROM catalog_backfill WHERE sourceId = ? AND mediaType = ? AND done = 0 ORDER BY sortBase ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfCategoryRemoteId: Int = getColumnIndexOrThrow(_stmt, "categoryRemoteId")
        val _columnIndexOfCategoryDbId: Int = getColumnIndexOrThrow(_stmt, "categoryDbId")
        val _columnIndexOfTotalItems: Int = getColumnIndexOrThrow(_stmt, "totalItems")
        val _columnIndexOfMaxPageItems: Int = getColumnIndexOrThrow(_stmt, "maxPageItems")
        val _columnIndexOfNextPage: Int = getColumnIndexOrThrow(_stmt, "nextPage")
        val _columnIndexOfLastPage: Int = getColumnIndexOrThrow(_stmt, "lastPage")
        val _columnIndexOfSortBase: Int = getColumnIndexOrThrow(_stmt, "sortBase")
        val _columnIndexOfDone: Int = getColumnIndexOrThrow(_stmt, "done")
        val _result: MutableList<CatalogBackfillEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: CatalogBackfillEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpCategoryRemoteId: String
          _tmpCategoryRemoteId = _stmt.getText(_columnIndexOfCategoryRemoteId)
          val _tmpCategoryDbId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryDbId)) {
            _tmpCategoryDbId = null
          } else {
            _tmpCategoryDbId = _stmt.getLong(_columnIndexOfCategoryDbId)
          }
          val _tmpTotalItems: Int
          _tmpTotalItems = _stmt.getLong(_columnIndexOfTotalItems).toInt()
          val _tmpMaxPageItems: Int
          _tmpMaxPageItems = _stmt.getLong(_columnIndexOfMaxPageItems).toInt()
          val _tmpNextPage: Int
          _tmpNextPage = _stmt.getLong(_columnIndexOfNextPage).toInt()
          val _tmpLastPage: Int
          _tmpLastPage = _stmt.getLong(_columnIndexOfLastPage).toInt()
          val _tmpSortBase: Int
          _tmpSortBase = _stmt.getLong(_columnIndexOfSortBase).toInt()
          val _tmpDone: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfDone).toInt()
          _tmpDone = _tmp_2 != 0
          _item = CatalogBackfillEntity(_tmpSourceId,_tmpMediaType,_tmpCategoryRemoteId,_tmpCategoryDbId,_tmpTotalItems,_tmpMaxPageItems,_tmpNextPage,_tmpLastPage,_tmpSortBase,_tmpDone)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun forCategory(
    sourceId: Long,
    mediaType: MediaType,
    categoryRemoteId: String,
  ): CatalogBackfillEntity? {
    val _sql: String = "SELECT * FROM catalog_backfill WHERE sourceId = ? AND mediaType = ? AND categoryRemoteId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, categoryRemoteId)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfCategoryRemoteId: Int = getColumnIndexOrThrow(_stmt, "categoryRemoteId")
        val _columnIndexOfCategoryDbId: Int = getColumnIndexOrThrow(_stmt, "categoryDbId")
        val _columnIndexOfTotalItems: Int = getColumnIndexOrThrow(_stmt, "totalItems")
        val _columnIndexOfMaxPageItems: Int = getColumnIndexOrThrow(_stmt, "maxPageItems")
        val _columnIndexOfNextPage: Int = getColumnIndexOrThrow(_stmt, "nextPage")
        val _columnIndexOfLastPage: Int = getColumnIndexOrThrow(_stmt, "lastPage")
        val _columnIndexOfSortBase: Int = getColumnIndexOrThrow(_stmt, "sortBase")
        val _columnIndexOfDone: Int = getColumnIndexOrThrow(_stmt, "done")
        val _result: CatalogBackfillEntity?
        if (_stmt.step()) {
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpCategoryRemoteId: String
          _tmpCategoryRemoteId = _stmt.getText(_columnIndexOfCategoryRemoteId)
          val _tmpCategoryDbId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryDbId)) {
            _tmpCategoryDbId = null
          } else {
            _tmpCategoryDbId = _stmt.getLong(_columnIndexOfCategoryDbId)
          }
          val _tmpTotalItems: Int
          _tmpTotalItems = _stmt.getLong(_columnIndexOfTotalItems).toInt()
          val _tmpMaxPageItems: Int
          _tmpMaxPageItems = _stmt.getLong(_columnIndexOfMaxPageItems).toInt()
          val _tmpNextPage: Int
          _tmpNextPage = _stmt.getLong(_columnIndexOfNextPage).toInt()
          val _tmpLastPage: Int
          _tmpLastPage = _stmt.getLong(_columnIndexOfLastPage).toInt()
          val _tmpSortBase: Int
          _tmpSortBase = _stmt.getLong(_columnIndexOfSortBase).toInt()
          val _tmpDone: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfDone).toInt()
          _tmpDone = _tmp_2 != 0
          _result = CatalogBackfillEntity(_tmpSourceId,_tmpMediaType,_tmpCategoryRemoteId,_tmpCategoryDbId,_tmpTotalItems,_tmpMaxPageItems,_tmpNextPage,_tmpLastPage,_tmpSortBase,_tmpDone)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun forCategoryDbId(categoryDbId: Long): CatalogBackfillEntity? {
    val _sql: String = "SELECT * FROM catalog_backfill WHERE categoryDbId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, categoryDbId)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfCategoryRemoteId: Int = getColumnIndexOrThrow(_stmt, "categoryRemoteId")
        val _columnIndexOfCategoryDbId: Int = getColumnIndexOrThrow(_stmt, "categoryDbId")
        val _columnIndexOfTotalItems: Int = getColumnIndexOrThrow(_stmt, "totalItems")
        val _columnIndexOfMaxPageItems: Int = getColumnIndexOrThrow(_stmt, "maxPageItems")
        val _columnIndexOfNextPage: Int = getColumnIndexOrThrow(_stmt, "nextPage")
        val _columnIndexOfLastPage: Int = getColumnIndexOrThrow(_stmt, "lastPage")
        val _columnIndexOfSortBase: Int = getColumnIndexOrThrow(_stmt, "sortBase")
        val _columnIndexOfDone: Int = getColumnIndexOrThrow(_stmt, "done")
        val _result: CatalogBackfillEntity?
        if (_stmt.step()) {
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpCategoryRemoteId: String
          _tmpCategoryRemoteId = _stmt.getText(_columnIndexOfCategoryRemoteId)
          val _tmpCategoryDbId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryDbId)) {
            _tmpCategoryDbId = null
          } else {
            _tmpCategoryDbId = _stmt.getLong(_columnIndexOfCategoryDbId)
          }
          val _tmpTotalItems: Int
          _tmpTotalItems = _stmt.getLong(_columnIndexOfTotalItems).toInt()
          val _tmpMaxPageItems: Int
          _tmpMaxPageItems = _stmt.getLong(_columnIndexOfMaxPageItems).toInt()
          val _tmpNextPage: Int
          _tmpNextPage = _stmt.getLong(_columnIndexOfNextPage).toInt()
          val _tmpLastPage: Int
          _tmpLastPage = _stmt.getLong(_columnIndexOfLastPage).toInt()
          val _tmpSortBase: Int
          _tmpSortBase = _stmt.getLong(_columnIndexOfSortBase).toInt()
          val _tmpDone: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfDone).toInt()
          _tmpDone = _tmp_1 != 0
          _result = CatalogBackfillEntity(_tmpSourceId,_tmpMediaType,_tmpCategoryRemoteId,_tmpCategoryDbId,_tmpTotalItems,_tmpMaxPageItems,_tmpNextPage,_tmpLastPage,_tmpSortBase,_tmpDone)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(sourceId: Long, mediaType: MediaType): List<CatalogBackfillEntity> {
    val _sql: String = "SELECT * FROM catalog_backfill WHERE sourceId = ? AND mediaType = ? ORDER BY sortBase ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfCategoryRemoteId: Int = getColumnIndexOrThrow(_stmt, "categoryRemoteId")
        val _columnIndexOfCategoryDbId: Int = getColumnIndexOrThrow(_stmt, "categoryDbId")
        val _columnIndexOfTotalItems: Int = getColumnIndexOrThrow(_stmt, "totalItems")
        val _columnIndexOfMaxPageItems: Int = getColumnIndexOrThrow(_stmt, "maxPageItems")
        val _columnIndexOfNextPage: Int = getColumnIndexOrThrow(_stmt, "nextPage")
        val _columnIndexOfLastPage: Int = getColumnIndexOrThrow(_stmt, "lastPage")
        val _columnIndexOfSortBase: Int = getColumnIndexOrThrow(_stmt, "sortBase")
        val _columnIndexOfDone: Int = getColumnIndexOrThrow(_stmt, "done")
        val _result: MutableList<CatalogBackfillEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: CatalogBackfillEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpCategoryRemoteId: String
          _tmpCategoryRemoteId = _stmt.getText(_columnIndexOfCategoryRemoteId)
          val _tmpCategoryDbId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryDbId)) {
            _tmpCategoryDbId = null
          } else {
            _tmpCategoryDbId = _stmt.getLong(_columnIndexOfCategoryDbId)
          }
          val _tmpTotalItems: Int
          _tmpTotalItems = _stmt.getLong(_columnIndexOfTotalItems).toInt()
          val _tmpMaxPageItems: Int
          _tmpMaxPageItems = _stmt.getLong(_columnIndexOfMaxPageItems).toInt()
          val _tmpNextPage: Int
          _tmpNextPage = _stmt.getLong(_columnIndexOfNextPage).toInt()
          val _tmpLastPage: Int
          _tmpLastPage = _stmt.getLong(_columnIndexOfLastPage).toInt()
          val _tmpSortBase: Int
          _tmpSortBase = _stmt.getLong(_columnIndexOfSortBase).toInt()
          val _tmpDone: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfDone).toInt()
          _tmpDone = _tmp_2 != 0
          _item = CatalogBackfillEntity(_tmpSourceId,_tmpMediaType,_tmpCategoryRemoteId,_tmpCategoryDbId,_tmpTotalItems,_tmpMaxPageItems,_tmpNextPage,_tmpLastPage,_tmpSortBase,_tmpDone)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun pendingCount(sourceId: Long, mediaType: MediaType): Int {
    val _sql: String = "SELECT COUNT(*) FROM catalog_backfill WHERE sourceId = ? AND mediaType = ? AND done = 0"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        val _result: Int
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun pendingCountForSource(sourceId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM catalog_backfill WHERE sourceId = ? AND done = 0"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun advertisedTotal(sourceId: Long, mediaType: MediaType): Int {
    val _sql: String = "SELECT COALESCE(SUM(totalItems), 0) FROM catalog_backfill WHERE sourceId = ? AND mediaType = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        val _result: Int
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun advance(
    sourceId: Long,
    mediaType: MediaType,
    categoryRemoteId: String,
    nextPage: Int,
  ) {
    val _sql: String = "UPDATE catalog_backfill SET nextPage = ? WHERE sourceId = ? AND mediaType = ? AND categoryRemoteId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, nextPage.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 4
        _stmt.bindText(_argIndex, categoryRemoteId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun markDone(
    sourceId: Long,
    mediaType: MediaType,
    categoryRemoteId: String,
  ) {
    val _sql: String = "UPDATE catalog_backfill SET done = 1, nextPage = lastPage + 1 WHERE sourceId = ? AND mediaType = ? AND categoryRemoteId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, categoryRemoteId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun reopen(
    sourceId: Long,
    mediaType: MediaType,
    categoryRemoteId: String,
  ) {
    val _sql: String = "UPDATE catalog_backfill SET done = 0, nextPage = 2 WHERE sourceId = ? AND mediaType = ? AND categoryRemoteId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, categoryRemoteId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clear(sourceId: Long, mediaType: MediaType) {
    val _sql: String = "DELETE FROM catalog_backfill WHERE sourceId = ? AND mediaType = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
