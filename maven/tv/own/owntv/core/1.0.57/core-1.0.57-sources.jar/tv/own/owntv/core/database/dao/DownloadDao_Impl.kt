package tv.own.owntv.core.database.dao

import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.DownloadEntity
import tv.own.owntv.core.model.DownloadStatus
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class DownloadDao_Impl(
  __db: RoomDatabase,
) : DownloadDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfDownloadEntity: EntityInsertAdapter<DownloadEntity>

  private val __converters: Converters = Converters()

  private val __deleteAdapterOfDownloadEntity: EntityDeleteOrUpdateAdapter<DownloadEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfDownloadEntity = object : EntityInsertAdapter<DownloadEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `downloads` (`id`,`profileId`,`mediaType`,`itemId`,`title`,`posterUrl`,`streamUrl`,`filePath`,`status`,`downloadedBytes`,`totalBytes`,`createdAt`,`updatedAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: DownloadEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(3, _tmp)
        statement.bindLong(4, entity.itemId)
        statement.bindText(5, entity.title)
        val _tmpPosterUrl: String? = entity.posterUrl
        if (_tmpPosterUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpPosterUrl)
        }
        statement.bindText(7, entity.streamUrl)
        val _tmpFilePath: String? = entity.filePath
        if (_tmpFilePath == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpFilePath)
        }
        val _tmp_1: String = __converters.downloadStatusToString(entity.status)
        statement.bindText(9, _tmp_1)
        statement.bindLong(10, entity.downloadedBytes)
        statement.bindLong(11, entity.totalBytes)
        statement.bindLong(12, entity.createdAt)
        statement.bindLong(13, entity.updatedAt)
      }
    }
    this.__deleteAdapterOfDownloadEntity = object : EntityDeleteOrUpdateAdapter<DownloadEntity>() {
      protected override fun createQuery(): String = "DELETE FROM `downloads` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: DownloadEntity) {
        statement.bindLong(1, entity.id)
      }
    }
  }

  public override suspend fun upsert(download: DownloadEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfDownloadEntity.insertAndReturnId(_connection, download)
    _result
  }

  public override suspend fun delete(download: DownloadEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfDownloadEntity.handle(_connection, download)
  }

  public override suspend fun getById(id: Long): DownloadEntity? {
    val _sql: String = "SELECT * FROM downloads WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfDownloadedBytes: Int = getColumnIndexOrThrow(_stmt, "downloadedBytes")
        val _columnIndexOfTotalBytes: Int = getColumnIndexOrThrow(_stmt, "totalBytes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: DownloadEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpStatus: DownloadStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToDownloadStatus(_tmp_1)
          val _tmpDownloadedBytes: Long
          _tmpDownloadedBytes = _stmt.getLong(_columnIndexOfDownloadedBytes)
          val _tmpTotalBytes: Long
          _tmpTotalBytes = _stmt.getLong(_columnIndexOfTotalBytes)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = DownloadEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpTitle,_tmpPosterUrl,_tmpStreamUrl,_tmpFilePath,_tmpStatus,_tmpDownloadedBytes,_tmpTotalBytes,_tmpCreatedAt,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeForProfile(profileId: Long): Flow<List<DownloadEntity>> {
    val _sql: String = "SELECT * FROM downloads WHERE profileId = ? ORDER BY createdAt DESC"
    return createFlow(__db, false, arrayOf("downloads")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfDownloadedBytes: Int = getColumnIndexOrThrow(_stmt, "downloadedBytes")
        val _columnIndexOfTotalBytes: Int = getColumnIndexOrThrow(_stmt, "totalBytes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<DownloadEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: DownloadEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpStatus: DownloadStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToDownloadStatus(_tmp_1)
          val _tmpDownloadedBytes: Long
          _tmpDownloadedBytes = _stmt.getLong(_columnIndexOfDownloadedBytes)
          val _tmpTotalBytes: Long
          _tmpTotalBytes = _stmt.getLong(_columnIndexOfTotalBytes)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = DownloadEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpTitle,_tmpPosterUrl,_tmpStreamUrl,_tmpFilePath,_tmpStatus,_tmpDownloadedBytes,_tmpTotalBytes,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeForSeries(seriesId: Long): Flow<List<DownloadEntity>> {
    val _sql: String = "SELECT d.* FROM downloads d INNER JOIN episodes e ON e.id = d.itemId WHERE d.mediaType = 'EPISODE' AND e.seriesId = ?"
    return createFlow(__db, false, arrayOf("downloads", "episodes")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, seriesId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfDownloadedBytes: Int = getColumnIndexOrThrow(_stmt, "downloadedBytes")
        val _columnIndexOfTotalBytes: Int = getColumnIndexOrThrow(_stmt, "totalBytes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<DownloadEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: DownloadEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpStatus: DownloadStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToDownloadStatus(_tmp_1)
          val _tmpDownloadedBytes: Long
          _tmpDownloadedBytes = _stmt.getLong(_columnIndexOfDownloadedBytes)
          val _tmpTotalBytes: Long
          _tmpTotalBytes = _stmt.getLong(_columnIndexOfTotalBytes)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = DownloadEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpTitle,_tmpPosterUrl,_tmpStreamUrl,_tmpFilePath,_tmpStatus,_tmpDownloadedBytes,_tmpTotalBytes,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun byStatus(status: DownloadStatus): List<DownloadEntity> {
    val _sql: String = "SELECT * FROM downloads WHERE status = ? ORDER BY createdAt ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: String = __converters.downloadStatusToString(status)
        _stmt.bindText(_argIndex, _tmp)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfDownloadedBytes: Int = getColumnIndexOrThrow(_stmt, "downloadedBytes")
        val _columnIndexOfTotalBytes: Int = getColumnIndexOrThrow(_stmt, "totalBytes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<DownloadEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: DownloadEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpStatus: DownloadStatus
          val _tmp_2: String
          _tmp_2 = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToDownloadStatus(_tmp_2)
          val _tmpDownloadedBytes: Long
          _tmpDownloadedBytes = _stmt.getLong(_columnIndexOfDownloadedBytes)
          val _tmpTotalBytes: Long
          _tmpTotalBytes = _stmt.getLong(_columnIndexOfTotalBytes)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = DownloadEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpTitle,_tmpPosterUrl,_tmpStreamUrl,_tmpFilePath,_tmpStatus,_tmpDownloadedBytes,_tmpTotalBytes,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun pending(): List<DownloadEntity> {
    val _sql: String = "SELECT * FROM downloads WHERE status IN ('QUEUED', 'RUNNING') ORDER BY createdAt ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfFilePath: Int = getColumnIndexOrThrow(_stmt, "filePath")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfDownloadedBytes: Int = getColumnIndexOrThrow(_stmt, "downloadedBytes")
        val _columnIndexOfTotalBytes: Int = getColumnIndexOrThrow(_stmt, "totalBytes")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<DownloadEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: DownloadEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpFilePath: String?
          if (_stmt.isNull(_columnIndexOfFilePath)) {
            _tmpFilePath = null
          } else {
            _tmpFilePath = _stmt.getText(_columnIndexOfFilePath)
          }
          val _tmpStatus: DownloadStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToDownloadStatus(_tmp_1)
          val _tmpDownloadedBytes: Long
          _tmpDownloadedBytes = _stmt.getLong(_columnIndexOfDownloadedBytes)
          val _tmpTotalBytes: Long
          _tmpTotalBytes = _stmt.getLong(_columnIndexOfTotalBytes)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = DownloadEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpTitle,_tmpPosterUrl,_tmpStreamUrl,_tmpFilePath,_tmpStatus,_tmpDownloadedBytes,_tmpTotalBytes,_tmpCreatedAt,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun count(profileId: Long): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM downloads WHERE profileId = ?"
    return createFlow(__db, false, arrayOf("downloads")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateProgress(
    id: Long,
    status: DownloadStatus,
    downloaded: Long,
    total: Long,
    timestamp: Long,
  ) {
    val _sql: String = "UPDATE downloads SET status = ?, downloadedBytes = ?, totalBytes = ?, updatedAt = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: String = __converters.downloadStatusToString(status)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 2
        _stmt.bindLong(_argIndex, downloaded)
        _argIndex = 3
        _stmt.bindLong(_argIndex, total)
        _argIndex = 4
        _stmt.bindLong(_argIndex, timestamp)
        _argIndex = 5
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
