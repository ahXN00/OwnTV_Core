package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.TrendingAttemptStatus
import tv.own.owntv.core.database.entity.TrendingItemEntity
import tv.own.owntv.core.database.entity.TrendingSnapshot
import tv.own.owntv.core.database.entity.TrendingSnapshotEntity
import tv.own.owntv.core.database.entity.TrendingSnapshotStatus
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TrendingDao_Impl(
  __db: RoomDatabase,
) : TrendingDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTrendingSnapshotEntity: EntityInsertAdapter<TrendingSnapshotEntity>

  private val __converters: Converters = Converters()

  private val __insertAdapterOfTrendingItemEntity: EntityInsertAdapter<TrendingItemEntity>

  private val __insertAdapterOfTrendingSnapshotEntity_1: EntityInsertAdapter<TrendingSnapshotEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfTrendingSnapshotEntity = object : EntityInsertAdapter<TrendingSnapshotEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `trending_snapshots` (`sourceId`,`status`,`metadataLanguage`,`refreshedAt`,`candidateFetchedAt`,`generationId`,`itemCount`,`matchedItemCount`,`lastAttemptAt`,`lastAttemptStatus`,`failureStage`) VALUES (?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TrendingSnapshotEntity) {
        statement.bindLong(1, entity.sourceId)
        val _tmp: String = __converters.trendingSnapshotStatusToString(entity.status)
        statement.bindText(2, _tmp)
        statement.bindText(3, entity.metadataLanguage)
        statement.bindLong(4, entity.refreshedAt)
        statement.bindLong(5, entity.candidateFetchedAt)
        statement.bindText(6, entity.generationId)
        statement.bindLong(7, entity.itemCount.toLong())
        statement.bindLong(8, entity.matchedItemCount.toLong())
        statement.bindLong(9, entity.lastAttemptAt)
        val _tmp_1: String = __converters.trendingAttemptStatusToString(entity.lastAttemptStatus)
        statement.bindText(10, _tmp_1)
        val _tmpFailureStage: String? = entity.failureStage
        if (_tmpFailureStage == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpFailureStage)
        }
      }
    }
    this.__insertAdapterOfTrendingItemEntity = object : EntityInsertAdapter<TrendingItemEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `trending_items` (`sourceId`,`position`,`tmdbId`,`mediaType`,`trendingRank`,`providerItemId`,`providerRemoteId`,`providerStableKey`,`providerRawName`,`canonicalTitle`,`providerLanguage`,`advertisedQuality`,`advertisedCapabilities`,`localizedTitle`,`originalTitle`,`year`,`overview`,`posterPath`,`backdropPath`,`rating`,`trailerKey`,`generationId`,`refreshedAt`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TrendingItemEntity) {
        statement.bindLong(1, entity.sourceId)
        statement.bindLong(2, entity.position.toLong())
        statement.bindLong(3, entity.tmdbId.toLong())
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(4, _tmp)
        statement.bindLong(5, entity.trendingRank.toLong())
        statement.bindLong(6, entity.providerItemId)
        val _tmpProviderRemoteId: String? = entity.providerRemoteId
        if (_tmpProviderRemoteId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpProviderRemoteId)
        }
        statement.bindText(8, entity.providerStableKey)
        statement.bindText(9, entity.providerRawName)
        statement.bindText(10, entity.canonicalTitle)
        val _tmpProviderLanguage: String? = entity.providerLanguage
        if (_tmpProviderLanguage == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpProviderLanguage)
        }
        val _tmpAdvertisedQuality: String? = entity.advertisedQuality
        if (_tmpAdvertisedQuality == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpAdvertisedQuality)
        }
        val _tmpAdvertisedCapabilities: String? = entity.advertisedCapabilities
        if (_tmpAdvertisedCapabilities == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpAdvertisedCapabilities)
        }
        statement.bindText(14, entity.localizedTitle)
        val _tmpOriginalTitle: String? = entity.originalTitle
        if (_tmpOriginalTitle == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpOriginalTitle)
        }
        val _tmpYear: Int? = entity.year
        if (_tmpYear == null) {
          statement.bindNull(16)
        } else {
          statement.bindLong(16, _tmpYear.toLong())
        }
        val _tmpOverview: String? = entity.overview
        if (_tmpOverview == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpOverview)
        }
        val _tmpPosterPath: String? = entity.posterPath
        if (_tmpPosterPath == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpPosterPath)
        }
        val _tmpBackdropPath: String? = entity.backdropPath
        if (_tmpBackdropPath == null) {
          statement.bindNull(19)
        } else {
          statement.bindText(19, _tmpBackdropPath)
        }
        val _tmpRating: Double? = entity.rating
        if (_tmpRating == null) {
          statement.bindNull(20)
        } else {
          statement.bindDouble(20, _tmpRating)
        }
        val _tmpTrailerKey: String? = entity.trailerKey
        if (_tmpTrailerKey == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpTrailerKey)
        }
        statement.bindText(22, entity.generationId)
        statement.bindLong(23, entity.refreshedAt)
      }
    }
    this.__insertAdapterOfTrendingSnapshotEntity_1 = object : EntityInsertAdapter<TrendingSnapshotEntity>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `trending_snapshots` (`sourceId`,`status`,`metadataLanguage`,`refreshedAt`,`candidateFetchedAt`,`generationId`,`itemCount`,`matchedItemCount`,`lastAttemptAt`,`lastAttemptStatus`,`failureStage`) VALUES (?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TrendingSnapshotEntity) {
        statement.bindLong(1, entity.sourceId)
        val _tmp: String = __converters.trendingSnapshotStatusToString(entity.status)
        statement.bindText(2, _tmp)
        statement.bindText(3, entity.metadataLanguage)
        statement.bindLong(4, entity.refreshedAt)
        statement.bindLong(5, entity.candidateFetchedAt)
        statement.bindText(6, entity.generationId)
        statement.bindLong(7, entity.itemCount.toLong())
        statement.bindLong(8, entity.matchedItemCount.toLong())
        statement.bindLong(9, entity.lastAttemptAt)
        val _tmp_1: String = __converters.trendingAttemptStatusToString(entity.lastAttemptStatus)
        statement.bindText(10, _tmp_1)
        val _tmpFailureStage: String? = entity.failureStage
        if (_tmpFailureStage == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpFailureStage)
        }
      }
    }
  }

  public override suspend fun upsertState(state: TrendingSnapshotEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfTrendingSnapshotEntity.insert(_connection, state)
  }

  public override suspend fun insertItems(items: List<TrendingItemEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfTrendingItemEntity.insert(_connection, items)
  }

  public override suspend fun insertStateIfMissing(state: TrendingSnapshotEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfTrendingSnapshotEntity_1.insertAndReturnId(_connection, state)
    _result
  }

  public override suspend fun recordFailure(stateIfMissing: TrendingSnapshotEntity, stage: String): Unit = performInTransactionSuspending(__db) {
    super@TrendingDao_Impl.recordFailure(stateIfMissing, stage)
  }

  public override suspend fun getSnapshot(sourceId: Long): TrendingSnapshot? = performInTransactionSuspending(__db) {
    super@TrendingDao_Impl.getSnapshot(sourceId)
  }

  public override suspend fun replaceSnapshot(state: TrendingSnapshotEntity, items: List<TrendingItemEntity>): Unit = performInTransactionSuspending(__db) {
    super@TrendingDao_Impl.replaceSnapshot(state, items)
  }

  public override suspend fun writeBelowThreshold(state: TrendingSnapshotEntity): Unit = performInTransactionSuspending(__db) {
    super@TrendingDao_Impl.writeBelowThreshold(state)
  }

  public override suspend fun getState(sourceId: Long): TrendingSnapshotEntity? {
    val _sql: String = "SELECT * FROM trending_snapshots WHERE sourceId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfMetadataLanguage: Int = getColumnIndexOrThrow(_stmt, "metadataLanguage")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _columnIndexOfCandidateFetchedAt: Int = getColumnIndexOrThrow(_stmt, "candidateFetchedAt")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfItemCount: Int = getColumnIndexOrThrow(_stmt, "itemCount")
        val _columnIndexOfMatchedItemCount: Int = getColumnIndexOrThrow(_stmt, "matchedItemCount")
        val _columnIndexOfLastAttemptAt: Int = getColumnIndexOrThrow(_stmt, "lastAttemptAt")
        val _columnIndexOfLastAttemptStatus: Int = getColumnIndexOrThrow(_stmt, "lastAttemptStatus")
        val _columnIndexOfFailureStage: Int = getColumnIndexOrThrow(_stmt, "failureStage")
        val _result: TrendingSnapshotEntity?
        if (_stmt.step()) {
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpStatus: TrendingSnapshotStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToTrendingSnapshotStatus(_tmp)
          val _tmpMetadataLanguage: String
          _tmpMetadataLanguage = _stmt.getText(_columnIndexOfMetadataLanguage)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          val _tmpCandidateFetchedAt: Long
          _tmpCandidateFetchedAt = _stmt.getLong(_columnIndexOfCandidateFetchedAt)
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpItemCount: Int
          _tmpItemCount = _stmt.getLong(_columnIndexOfItemCount).toInt()
          val _tmpMatchedItemCount: Int
          _tmpMatchedItemCount = _stmt.getLong(_columnIndexOfMatchedItemCount).toInt()
          val _tmpLastAttemptAt: Long
          _tmpLastAttemptAt = _stmt.getLong(_columnIndexOfLastAttemptAt)
          val _tmpLastAttemptStatus: TrendingAttemptStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfLastAttemptStatus)
          _tmpLastAttemptStatus = __converters.stringToTrendingAttemptStatus(_tmp_1)
          val _tmpFailureStage: String?
          if (_stmt.isNull(_columnIndexOfFailureStage)) {
            _tmpFailureStage = null
          } else {
            _tmpFailureStage = _stmt.getText(_columnIndexOfFailureStage)
          }
          _result = TrendingSnapshotEntity(_tmpSourceId,_tmpStatus,_tmpMetadataLanguage,_tmpRefreshedAt,_tmpCandidateFetchedAt,_tmpGenerationId,_tmpItemCount,_tmpMatchedItemCount,_tmpLastAttemptAt,_tmpLastAttemptStatus,_tmpFailureStage)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getItems(sourceId: Long): List<TrendingItemEntity> {
    val _sql: String = "SELECT * FROM trending_items WHERE sourceId = ? ORDER BY position"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfTrendingRank: Int = getColumnIndexOrThrow(_stmt, "trendingRank")
        val _columnIndexOfProviderItemId: Int = getColumnIndexOrThrow(_stmt, "providerItemId")
        val _columnIndexOfProviderRemoteId: Int = getColumnIndexOrThrow(_stmt, "providerRemoteId")
        val _columnIndexOfProviderStableKey: Int = getColumnIndexOrThrow(_stmt, "providerStableKey")
        val _columnIndexOfProviderRawName: Int = getColumnIndexOrThrow(_stmt, "providerRawName")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfAdvertisedQuality: Int = getColumnIndexOrThrow(_stmt, "advertisedQuality")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _columnIndexOfLocalizedTitle: Int = getColumnIndexOrThrow(_stmt, "localizedTitle")
        val _columnIndexOfOriginalTitle: Int = getColumnIndexOrThrow(_stmt, "originalTitle")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _result: MutableList<TrendingItemEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: TrendingItemEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpTrendingRank: Int
          _tmpTrendingRank = _stmt.getLong(_columnIndexOfTrendingRank).toInt()
          val _tmpProviderItemId: Long
          _tmpProviderItemId = _stmt.getLong(_columnIndexOfProviderItemId)
          val _tmpProviderRemoteId: String?
          if (_stmt.isNull(_columnIndexOfProviderRemoteId)) {
            _tmpProviderRemoteId = null
          } else {
            _tmpProviderRemoteId = _stmt.getText(_columnIndexOfProviderRemoteId)
          }
          val _tmpProviderStableKey: String
          _tmpProviderStableKey = _stmt.getText(_columnIndexOfProviderStableKey)
          val _tmpProviderRawName: String
          _tmpProviderRawName = _stmt.getText(_columnIndexOfProviderRawName)
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpAdvertisedQuality: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedQuality)) {
            _tmpAdvertisedQuality = null
          } else {
            _tmpAdvertisedQuality = _stmt.getText(_columnIndexOfAdvertisedQuality)
          }
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          val _tmpLocalizedTitle: String
          _tmpLocalizedTitle = _stmt.getText(_columnIndexOfLocalizedTitle)
          val _tmpOriginalTitle: String?
          if (_stmt.isNull(_columnIndexOfOriginalTitle)) {
            _tmpOriginalTitle = null
          } else {
            _tmpOriginalTitle = _stmt.getText(_columnIndexOfOriginalTitle)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          _item = TrendingItemEntity(_tmpSourceId,_tmpPosition,_tmpTmdbId,_tmpMediaType,_tmpTrendingRank,_tmpProviderItemId,_tmpProviderRemoteId,_tmpProviderStableKey,_tmpProviderRawName,_tmpCanonicalTitle,_tmpProviderLanguage,_tmpAdvertisedQuality,_tmpAdvertisedCapabilities,_tmpLocalizedTitle,_tmpOriginalTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpTrailerKey,_tmpGenerationId,_tmpRefreshedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getItemsForSources(sourceIds: List<Long>): List<TrendingItemEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM trending_items WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId, position")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfTrendingRank: Int = getColumnIndexOrThrow(_stmt, "trendingRank")
        val _columnIndexOfProviderItemId: Int = getColumnIndexOrThrow(_stmt, "providerItemId")
        val _columnIndexOfProviderRemoteId: Int = getColumnIndexOrThrow(_stmt, "providerRemoteId")
        val _columnIndexOfProviderStableKey: Int = getColumnIndexOrThrow(_stmt, "providerStableKey")
        val _columnIndexOfProviderRawName: Int = getColumnIndexOrThrow(_stmt, "providerRawName")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfAdvertisedQuality: Int = getColumnIndexOrThrow(_stmt, "advertisedQuality")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _columnIndexOfLocalizedTitle: Int = getColumnIndexOrThrow(_stmt, "localizedTitle")
        val _columnIndexOfOriginalTitle: Int = getColumnIndexOrThrow(_stmt, "originalTitle")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _result: MutableList<TrendingItemEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: TrendingItemEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpTrendingRank: Int
          _tmpTrendingRank = _stmt.getLong(_columnIndexOfTrendingRank).toInt()
          val _tmpProviderItemId: Long
          _tmpProviderItemId = _stmt.getLong(_columnIndexOfProviderItemId)
          val _tmpProviderRemoteId: String?
          if (_stmt.isNull(_columnIndexOfProviderRemoteId)) {
            _tmpProviderRemoteId = null
          } else {
            _tmpProviderRemoteId = _stmt.getText(_columnIndexOfProviderRemoteId)
          }
          val _tmpProviderStableKey: String
          _tmpProviderStableKey = _stmt.getText(_columnIndexOfProviderStableKey)
          val _tmpProviderRawName: String
          _tmpProviderRawName = _stmt.getText(_columnIndexOfProviderRawName)
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpAdvertisedQuality: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedQuality)) {
            _tmpAdvertisedQuality = null
          } else {
            _tmpAdvertisedQuality = _stmt.getText(_columnIndexOfAdvertisedQuality)
          }
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          val _tmpLocalizedTitle: String
          _tmpLocalizedTitle = _stmt.getText(_columnIndexOfLocalizedTitle)
          val _tmpOriginalTitle: String?
          if (_stmt.isNull(_columnIndexOfOriginalTitle)) {
            _tmpOriginalTitle = null
          } else {
            _tmpOriginalTitle = _stmt.getText(_columnIndexOfOriginalTitle)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          _item_1 = TrendingItemEntity(_tmpSourceId,_tmpPosition,_tmpTmdbId,_tmpMediaType,_tmpTrendingRank,_tmpProviderItemId,_tmpProviderRemoteId,_tmpProviderStableKey,_tmpProviderRawName,_tmpCanonicalTitle,_tmpProviderLanguage,_tmpAdvertisedQuality,_tmpAdvertisedCapabilities,_tmpLocalizedTitle,_tmpOriginalTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpTrailerKey,_tmpGenerationId,_tmpRefreshedAt)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeItems(sourceIds: List<Long>): Flow<List<TrendingItemEntity>> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM trending_items WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId, position")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("trending_items")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfTrendingRank: Int = getColumnIndexOrThrow(_stmt, "trendingRank")
        val _columnIndexOfProviderItemId: Int = getColumnIndexOrThrow(_stmt, "providerItemId")
        val _columnIndexOfProviderRemoteId: Int = getColumnIndexOrThrow(_stmt, "providerRemoteId")
        val _columnIndexOfProviderStableKey: Int = getColumnIndexOrThrow(_stmt, "providerStableKey")
        val _columnIndexOfProviderRawName: Int = getColumnIndexOrThrow(_stmt, "providerRawName")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfAdvertisedQuality: Int = getColumnIndexOrThrow(_stmt, "advertisedQuality")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _columnIndexOfLocalizedTitle: Int = getColumnIndexOrThrow(_stmt, "localizedTitle")
        val _columnIndexOfOriginalTitle: Int = getColumnIndexOrThrow(_stmt, "originalTitle")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _result: MutableList<TrendingItemEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: TrendingItemEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpTrendingRank: Int
          _tmpTrendingRank = _stmt.getLong(_columnIndexOfTrendingRank).toInt()
          val _tmpProviderItemId: Long
          _tmpProviderItemId = _stmt.getLong(_columnIndexOfProviderItemId)
          val _tmpProviderRemoteId: String?
          if (_stmt.isNull(_columnIndexOfProviderRemoteId)) {
            _tmpProviderRemoteId = null
          } else {
            _tmpProviderRemoteId = _stmt.getText(_columnIndexOfProviderRemoteId)
          }
          val _tmpProviderStableKey: String
          _tmpProviderStableKey = _stmt.getText(_columnIndexOfProviderStableKey)
          val _tmpProviderRawName: String
          _tmpProviderRawName = _stmt.getText(_columnIndexOfProviderRawName)
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpAdvertisedQuality: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedQuality)) {
            _tmpAdvertisedQuality = null
          } else {
            _tmpAdvertisedQuality = _stmt.getText(_columnIndexOfAdvertisedQuality)
          }
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          val _tmpLocalizedTitle: String
          _tmpLocalizedTitle = _stmt.getText(_columnIndexOfLocalizedTitle)
          val _tmpOriginalTitle: String?
          if (_stmt.isNull(_columnIndexOfOriginalTitle)) {
            _tmpOriginalTitle = null
          } else {
            _tmpOriginalTitle = _stmt.getText(_columnIndexOfOriginalTitle)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          _item_1 = TrendingItemEntity(_tmpSourceId,_tmpPosition,_tmpTmdbId,_tmpMediaType,_tmpTrendingRank,_tmpProviderItemId,_tmpProviderRemoteId,_tmpProviderStableKey,_tmpProviderRawName,_tmpCanonicalTitle,_tmpProviderLanguage,_tmpAdvertisedQuality,_tmpAdvertisedCapabilities,_tmpLocalizedTitle,_tmpOriginalTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpTrailerKey,_tmpGenerationId,_tmpRefreshedAt)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAllItems(): Flow<List<TrendingItemEntity>> {
    val _sql: String = "SELECT * FROM trending_items ORDER BY sourceId, position"
    return createFlow(__db, false, arrayOf("trending_items")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfTrendingRank: Int = getColumnIndexOrThrow(_stmt, "trendingRank")
        val _columnIndexOfProviderItemId: Int = getColumnIndexOrThrow(_stmt, "providerItemId")
        val _columnIndexOfProviderRemoteId: Int = getColumnIndexOrThrow(_stmt, "providerRemoteId")
        val _columnIndexOfProviderStableKey: Int = getColumnIndexOrThrow(_stmt, "providerStableKey")
        val _columnIndexOfProviderRawName: Int = getColumnIndexOrThrow(_stmt, "providerRawName")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfAdvertisedQuality: Int = getColumnIndexOrThrow(_stmt, "advertisedQuality")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _columnIndexOfLocalizedTitle: Int = getColumnIndexOrThrow(_stmt, "localizedTitle")
        val _columnIndexOfOriginalTitle: Int = getColumnIndexOrThrow(_stmt, "originalTitle")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _result: MutableList<TrendingItemEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: TrendingItemEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpTrendingRank: Int
          _tmpTrendingRank = _stmt.getLong(_columnIndexOfTrendingRank).toInt()
          val _tmpProviderItemId: Long
          _tmpProviderItemId = _stmt.getLong(_columnIndexOfProviderItemId)
          val _tmpProviderRemoteId: String?
          if (_stmt.isNull(_columnIndexOfProviderRemoteId)) {
            _tmpProviderRemoteId = null
          } else {
            _tmpProviderRemoteId = _stmt.getText(_columnIndexOfProviderRemoteId)
          }
          val _tmpProviderStableKey: String
          _tmpProviderStableKey = _stmt.getText(_columnIndexOfProviderStableKey)
          val _tmpProviderRawName: String
          _tmpProviderRawName = _stmt.getText(_columnIndexOfProviderRawName)
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpAdvertisedQuality: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedQuality)) {
            _tmpAdvertisedQuality = null
          } else {
            _tmpAdvertisedQuality = _stmt.getText(_columnIndexOfAdvertisedQuality)
          }
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          val _tmpLocalizedTitle: String
          _tmpLocalizedTitle = _stmt.getText(_columnIndexOfLocalizedTitle)
          val _tmpOriginalTitle: String?
          if (_stmt.isNull(_columnIndexOfOriginalTitle)) {
            _tmpOriginalTitle = null
          } else {
            _tmpOriginalTitle = _stmt.getText(_columnIndexOfOriginalTitle)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          _item = TrendingItemEntity(_tmpSourceId,_tmpPosition,_tmpTmdbId,_tmpMediaType,_tmpTrendingRank,_tmpProviderItemId,_tmpProviderRemoteId,_tmpProviderStableKey,_tmpProviderRawName,_tmpCanonicalTitle,_tmpProviderLanguage,_tmpAdvertisedQuality,_tmpAdvertisedCapabilities,_tmpLocalizedTitle,_tmpOriginalTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpTrailerKey,_tmpGenerationId,_tmpRefreshedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeStatesForSources(sourceIds: List<Long>): Flow<List<TrendingSnapshotEntity>> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM trending_snapshots WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("trending_snapshots")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfStatus: Int = getColumnIndexOrThrow(_stmt, "status")
        val _columnIndexOfMetadataLanguage: Int = getColumnIndexOrThrow(_stmt, "metadataLanguage")
        val _columnIndexOfRefreshedAt: Int = getColumnIndexOrThrow(_stmt, "refreshedAt")
        val _columnIndexOfCandidateFetchedAt: Int = getColumnIndexOrThrow(_stmt, "candidateFetchedAt")
        val _columnIndexOfGenerationId: Int = getColumnIndexOrThrow(_stmt, "generationId")
        val _columnIndexOfItemCount: Int = getColumnIndexOrThrow(_stmt, "itemCount")
        val _columnIndexOfMatchedItemCount: Int = getColumnIndexOrThrow(_stmt, "matchedItemCount")
        val _columnIndexOfLastAttemptAt: Int = getColumnIndexOrThrow(_stmt, "lastAttemptAt")
        val _columnIndexOfLastAttemptStatus: Int = getColumnIndexOrThrow(_stmt, "lastAttemptStatus")
        val _columnIndexOfFailureStage: Int = getColumnIndexOrThrow(_stmt, "failureStage")
        val _result: MutableList<TrendingSnapshotEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: TrendingSnapshotEntity
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpStatus: TrendingSnapshotStatus
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfStatus)
          _tmpStatus = __converters.stringToTrendingSnapshotStatus(_tmp)
          val _tmpMetadataLanguage: String
          _tmpMetadataLanguage = _stmt.getText(_columnIndexOfMetadataLanguage)
          val _tmpRefreshedAt: Long
          _tmpRefreshedAt = _stmt.getLong(_columnIndexOfRefreshedAt)
          val _tmpCandidateFetchedAt: Long
          _tmpCandidateFetchedAt = _stmt.getLong(_columnIndexOfCandidateFetchedAt)
          val _tmpGenerationId: String
          _tmpGenerationId = _stmt.getText(_columnIndexOfGenerationId)
          val _tmpItemCount: Int
          _tmpItemCount = _stmt.getLong(_columnIndexOfItemCount).toInt()
          val _tmpMatchedItemCount: Int
          _tmpMatchedItemCount = _stmt.getLong(_columnIndexOfMatchedItemCount).toInt()
          val _tmpLastAttemptAt: Long
          _tmpLastAttemptAt = _stmt.getLong(_columnIndexOfLastAttemptAt)
          val _tmpLastAttemptStatus: TrendingAttemptStatus
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfLastAttemptStatus)
          _tmpLastAttemptStatus = __converters.stringToTrendingAttemptStatus(_tmp_1)
          val _tmpFailureStage: String?
          if (_stmt.isNull(_columnIndexOfFailureStage)) {
            _tmpFailureStage = null
          } else {
            _tmpFailureStage = _stmt.getText(_columnIndexOfFailureStage)
          }
          _item_1 = TrendingSnapshotEntity(_tmpSourceId,_tmpStatus,_tmpMetadataLanguage,_tmpRefreshedAt,_tmpCandidateFetchedAt,_tmpGenerationId,_tmpItemCount,_tmpMatchedItemCount,_tmpLastAttemptAt,_tmpLastAttemptStatus,_tmpFailureStage)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteItems(sourceId: Long) {
    val _sql: String = "DELETE FROM trending_items WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteSnapshot(sourceId: Long) {
    val _sql: String = "DELETE FROM trending_snapshots WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun markFailureExisting(
    sourceId: Long,
    attemptAt: Long,
    stage: String,
  ): Int {
    val _sql: String = "UPDATE trending_snapshots SET lastAttemptAt = ?, lastAttemptStatus = 'FAILED', failureStage = ? WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, attemptAt)
        _argIndex = 2
        _stmt.bindText(_argIndex, stage)
        _argIndex = 3
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
