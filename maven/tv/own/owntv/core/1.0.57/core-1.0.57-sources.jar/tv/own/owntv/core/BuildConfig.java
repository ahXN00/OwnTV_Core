/**
 * Automatically generated file. DO NOT MODIFY
 */
package tv.own.owntv.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "tv.own.owntv.core";
  public static final String BUILD_TYPE = "release";
}
