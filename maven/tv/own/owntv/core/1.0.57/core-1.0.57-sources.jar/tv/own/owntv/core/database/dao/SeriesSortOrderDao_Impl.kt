package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.SeriesSortOrderEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class SeriesSortOrderDao_Impl(
  __db: RoomDatabase,
) : SeriesSortOrderDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSeriesSortOrderEntity: EntityInsertAdapter<SeriesSortOrderEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfSeriesSortOrderEntity = object : EntityInsertAdapter<SeriesSortOrderEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `series_sort_order` (`id`,`profileId`,`seriesId`,`seasonsDescending`,`episodesDescending`) VALUES (nullif(?, 0),?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SeriesSortOrderEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        statement.bindLong(3, entity.seriesId)
        val _tmp: Int = if (entity.seasonsDescending) 1 else 0
        statement.bindLong(4, _tmp.toLong())
        val _tmp_1: Int = if (entity.episodesDescending) 1 else 0
        statement.bindLong(5, _tmp_1.toLong())
      }
    }
  }

  public override suspend fun insertAll(rows: List<SeriesSortOrderEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSeriesSortOrderEntity.insert(_connection, rows)
  }

  public override fun observe(profileId: Long, seriesId: Long): Flow<SeriesSortOrderEntity?> {
    val _sql: String = "SELECT * FROM series_sort_order WHERE profileId = ? AND seriesId = ?"
    return createFlow(__db, false, arrayOf("series_sort_order")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSeriesId: Int = getColumnIndexOrThrow(_stmt, "seriesId")
        val _columnIndexOfSeasonsDescending: Int = getColumnIndexOrThrow(_stmt, "seasonsDescending")
        val _columnIndexOfEpisodesDescending: Int = getColumnIndexOrThrow(_stmt, "episodesDescending")
        val _result: SeriesSortOrderEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSeriesId: Long
          _tmpSeriesId = _stmt.getLong(_columnIndexOfSeriesId)
          val _tmpSeasonsDescending: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfSeasonsDescending).toInt()
          _tmpSeasonsDescending = _tmp != 0
          val _tmpEpisodesDescending: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEpisodesDescending).toInt()
          _tmpEpisodesDescending = _tmp_1 != 0
          _result = SeriesSortOrderEntity(_tmpId,_tmpProfileId,_tmpSeriesId,_tmpSeasonsDescending,_tmpEpisodesDescending)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findRowId(profileId: Long, seriesId: Long): Long? {
    val _sql: String = "SELECT id FROM series_sort_order WHERE profileId = ? AND seriesId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        val _result: Long?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getLong(0)
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<SeriesSortOrderEntity> {
    val _sql: String = "SELECT * FROM series_sort_order"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSeriesId: Int = getColumnIndexOrThrow(_stmt, "seriesId")
        val _columnIndexOfSeasonsDescending: Int = getColumnIndexOrThrow(_stmt, "seasonsDescending")
        val _columnIndexOfEpisodesDescending: Int = getColumnIndexOrThrow(_stmt, "episodesDescending")
        val _result: MutableList<SeriesSortOrderEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SeriesSortOrderEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSeriesId: Long
          _tmpSeriesId = _stmt.getLong(_columnIndexOfSeriesId)
          val _tmpSeasonsDescending: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfSeasonsDescending).toInt()
          _tmpSeasonsDescending = _tmp != 0
          val _tmpEpisodesDescending: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEpisodesDescending).toInt()
          _tmpEpisodesDescending = _tmp_1 != 0
          _item = SeriesSortOrderEntity(_tmpId,_tmpProfileId,_tmpSeriesId,_tmpSeasonsDescending,_tmpEpisodesDescending)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exportRowsForSource(sourceId: Long): List<SeriesSortOrderExportRow> {
    val _sql: String = "SELECT o.profileId AS profileId, o.seriesId AS seriesId, o.seasonsDescending AS seasonsDescending, o.episodesDescending AS episodesDescending, s.sourceId AS sourceId, s.remoteId AS remoteId, s.name AS name FROM series_sort_order o JOIN series s ON o.seriesId = s.id WHERE s.sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfProfileId: Int = 0
        val _columnIndexOfSeriesId: Int = 1
        val _columnIndexOfSeasonsDescending: Int = 2
        val _columnIndexOfEpisodesDescending: Int = 3
        val _columnIndexOfSourceId: Int = 4
        val _columnIndexOfRemoteId: Int = 5
        val _columnIndexOfName: Int = 6
        val _result: MutableList<SeriesSortOrderExportRow> = mutableListOf()
        while (_stmt.step()) {
          val _item: SeriesSortOrderExportRow
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSeriesId: Long
          _tmpSeriesId = _stmt.getLong(_columnIndexOfSeriesId)
          val _tmpSeasonsDescending: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfSeasonsDescending).toInt()
          _tmpSeasonsDescending = _tmp != 0
          val _tmpEpisodesDescending: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEpisodesDescending).toInt()
          _tmpEpisodesDescending = _tmp_1 != 0
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          _item = SeriesSortOrderExportRow(_tmpProfileId,_tmpSeriesId,_tmpSeasonsDescending,_tmpEpisodesDescending,_tmpSourceId,_tmpRemoteId,_tmpName)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setOrder(
    profileId: Long,
    seriesId: Long,
    seasonsDescending: Boolean,
    episodesDescending: Boolean,
  ) {
    val _sql: String = "INSERT INTO series_sort_order (profileId, seriesId, seasonsDescending, episodesDescending) VALUES (?, ?, ?, ?) ON CONFLICT(profileId, seriesId) DO UPDATE SET seasonsDescending = ?, episodesDescending = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        _argIndex = 3
        val _tmp: Int = if (seasonsDescending) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 4
        val _tmp_1: Int = if (episodesDescending) 1 else 0
        _stmt.bindLong(_argIndex, _tmp_1.toLong())
        _argIndex = 5
        val _tmp_2: Int = if (seasonsDescending) 1 else 0
        _stmt.bindLong(_argIndex, _tmp_2.toLong())
        _argIndex = 6
        val _tmp_3: Int = if (episodesDescending) 1 else 0
        _stmt.bindLong(_argIndex, _tmp_3.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeSnapshotOrphan(profileId: Long, seriesId: Long) {
    val _sql: String = "DELETE FROM series_sort_order WHERE profileId = ? AND seriesId = ? AND seriesId NOT IN (SELECT id FROM series)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeOrphans() {
    val _sql: String = "DELETE FROM series_sort_order WHERE seriesId NOT IN (SELECT id FROM series)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
