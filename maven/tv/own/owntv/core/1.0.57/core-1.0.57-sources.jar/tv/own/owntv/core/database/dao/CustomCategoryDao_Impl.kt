package tv.own.owntv.core.database.dao

import androidx.paging.PagingSource
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomRawQuery
import androidx.room.coroutines.createFlow
import androidx.room.paging.LimitOffsetPagingSource
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.CustomCategoryMemberEntity
import tv.own.owntv.core.database.entity.MovieEntity
import tv.own.owntv.core.database.entity.SeriesEntity
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class CustomCategoryDao_Impl(
  __db: RoomDatabase,
) : CustomCategoryDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfCustomCategoryMemberEntity:
      EntityInsertAdapter<CustomCategoryMemberEntity>

  private val __converters: Converters = Converters()
  init {
    this.__db = __db
    this.__insertAdapterOfCustomCategoryMemberEntity = object : EntityInsertAdapter<CustomCategoryMemberEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `custom_category_members` (`id`,`profileId`,`mediaType`,`contextKey`,`itemId`,`position`) VALUES (nullif(?, 0),?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: CustomCategoryMemberEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(3, _tmp)
        statement.bindText(4, entity.contextKey)
        statement.bindLong(5, entity.itemId)
        statement.bindLong(6, entity.position.toLong())
      }
    }
  }

  public override suspend fun insertAll(rows: List<CustomCategoryMemberEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfCustomCategoryMemberEntity.insert(_connection, rows)
  }

  public override suspend fun replaceContext(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    rows: List<CustomCategoryMemberEntity>,
  ): Unit = performInTransactionSuspending(__db) {
    super@CustomCategoryDao_Impl.replaceContext(profileId, type, contextKey, rows)
  }

  public override suspend fun appendItem(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    itemId: Long,
  ): Unit = performInTransactionSuspending(__db) {
    super@CustomCategoryDao_Impl.appendItem(profileId, type, contextKey, itemId)
  }

  public override fun observeContextKeys(profileId: Long, type: MediaType): Flow<List<String>> {
    val _sql: String = "SELECT DISTINCT contextKey FROM custom_category_members WHERE profileId = ? AND mediaType = ?"
    return createFlow(__db, false, arrayOf("custom_category_members")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxPosition(
    profileId: Long,
    type: MediaType,
    contextKey: String,
  ): Int {
    val _sql: String = "SELECT COALESCE(MAX(position), -1) FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND contextKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        val _result: Int
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exists(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    itemId: Long,
  ): Boolean {
    val _sql: String = "SELECT EXISTS(SELECT 1 FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND contextKey = ? AND itemId = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 4
        _stmt.bindLong(_argIndex, itemId)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1 != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeCountsByContexts(
    profileId: Long,
    type: MediaType,
    contextKeys: List<String>,
    sourceIds: List<Long>,
  ): Flow<List<CustomCategoryCount>> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT contextKey, COUNT(*) AS count FROM custom_category_members WHERE profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND mediaType = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND contextKey IN (")
    val _inputSize: Int = contextKeys.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND ((")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'LIVE' AND itemId IN (SELECT id FROM channels WHERE sourceId IN (")
    val _inputSize_1: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize_1)
    _stringBuilder.append("))) OR (")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'MOVIE' AND itemId IN (SELECT id FROM movies WHERE sourceId IN (")
    val _inputSize_2: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize_2)
    _stringBuilder.append("))) OR (")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'SERIES' AND itemId IN (SELECT id FROM series WHERE sourceId IN (")
    val _inputSize_3: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize_3)
    _stringBuilder.append(")))) GROUP BY contextKey")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("custom_category_members", "channels", "movies", "series")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        for (_item: String in contextKeys) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 3 + _inputSize
        val _tmp_1: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 4 + _inputSize
        for (_item_1: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item_1)
          _argIndex++
        }
        _argIndex = 4 + _inputSize + _inputSize_1
        val _tmp_2: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_2)
        _argIndex = 5 + _inputSize + _inputSize_1
        for (_item_2: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item_2)
          _argIndex++
        }
        _argIndex = 5 + _inputSize + _inputSize_1 + _inputSize_1
        val _tmp_3: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_3)
        _argIndex = 6 + _inputSize + _inputSize_1 + _inputSize_1
        for (_item_3: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item_3)
          _argIndex++
        }
        val _columnIndexOfContextKey: Int = 0
        val _columnIndexOfCount: Int = 1
        val _result: MutableList<CustomCategoryCount> = mutableListOf()
        while (_stmt.step()) {
          val _item_4: CustomCategoryCount
          val _tmpContextKey: String
          _tmpContextKey = _stmt.getText(_columnIndexOfContextKey)
          val _tmpCount: Int
          _tmpCount = _stmt.getLong(_columnIndexOfCount).toInt()
          _item_4 = CustomCategoryCount(_tmpContextKey,_tmpCount)
          _result.add(_item_4)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<CustomCategoryMemberEntity> {
    val _sql: String = "SELECT * FROM custom_category_members"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfContextKey: Int = getColumnIndexOrThrow(_stmt, "contextKey")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _result: MutableList<CustomCategoryMemberEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: CustomCategoryMemberEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpContextKey: String
          _tmpContextKey = _stmt.getText(_columnIndexOfContextKey)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          _item = CustomCategoryMemberEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpContextKey,_tmpItemId,_tmpPosition)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun stableItemKeys(profileId: Long, contextKey: String): List<String> {
    val _sql: String = "SELECT CAST(c.sourceId AS TEXT) || ':' || COALESCE(c.remoteId, c.name) FROM custom_category_members m INNER JOIN channels c ON m.mediaType = 'LIVE' AND m.itemId = c.id WHERE m.profileId = ? AND m.mediaType = 'LIVE' AND m.contextKey = ? UNION ALL SELECT CAST(mv.sourceId AS TEXT) || ':' || COALESCE(mv.remoteId, mv.name) FROM custom_category_members m INNER JOIN movies mv ON m.mediaType = 'MOVIE' AND m.itemId = mv.id WHERE m.profileId = ? AND m.mediaType = 'MOVIE' AND m.contextKey = ? UNION ALL SELECT CAST(s.sourceId AS TEXT) || ':' || COALESCE(s.remoteId, s.name) FROM custom_category_members m INNER JOIN series s ON m.mediaType = 'SERIES' AND m.itemId = s.id WHERE m.profileId = ? AND m.mediaType = 'SERIES' AND m.contextKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 5
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 6
        _stmt.bindText(_argIndex, contextKey)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          val _tmp: String
          _tmp = _stmt.getText(0)
          _item = _tmp
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exportRowsForSource(sourceId: Long): List<CustomCategoryMemberExportRow> {
    val _sql: String = "SELECT m.profileId AS profileId, m.mediaType AS mediaType, m.itemId AS itemId, m.contextKey AS contextKey, m.position AS position, COALESCE(c.sourceId, mv.sourceId, s.sourceId) AS sourceId, COALESCE(c.remoteId, mv.remoteId, s.remoteId) AS remoteId, COALESCE(c.name, mv.name, s.name) AS name FROM custom_category_members m LEFT JOIN channels c ON m.mediaType = 'LIVE' AND m.itemId = c.id LEFT JOIN movies mv ON m.mediaType = 'MOVIE' AND m.itemId = mv.id LEFT JOIN series s ON m.mediaType = 'SERIES' AND m.itemId = s.id WHERE c.sourceId = ? OR mv.sourceId = ? OR s.sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfProfileId: Int = 0
        val _columnIndexOfMediaType: Int = 1
        val _columnIndexOfItemId: Int = 2
        val _columnIndexOfContextKey: Int = 3
        val _columnIndexOfPosition: Int = 4
        val _columnIndexOfSourceId: Int = 5
        val _columnIndexOfRemoteId: Int = 6
        val _columnIndexOfName: Int = 7
        val _result: MutableList<CustomCategoryMemberExportRow> = mutableListOf()
        while (_stmt.step()) {
          val _item: CustomCategoryMemberExportRow
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpContextKey: String
          _tmpContextKey = _stmt.getText(_columnIndexOfContextKey)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          _item = CustomCategoryMemberExportRow(_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpContextKey,_tmpPosition,_tmpSourceId,_tmpRemoteId,_tmpName)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pagingChannels(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN custom_category_members m ON m.itemId = c.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'LIVE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'LIVE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, c.sortOrder, c.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingChannelsAlpha(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN custom_category_members m ON m.itemId = c.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'LIVE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'LIVE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, c.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingMovies(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT mv.* FROM movies mv INNER JOIN custom_category_members m ON m.itemId = mv.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'MOVIE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = mv.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'MOVIE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE mv.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, mv.sortOrder, mv.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingMoviesAlpha(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT mv.* FROM movies mv INNER JOIN custom_category_members m ON m.itemId = mv.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'MOVIE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = mv.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'MOVIE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE mv.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, mv.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingSeries(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, SeriesEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT s.* FROM series s INNER JOIN custom_category_members m ON m.itemId = s.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'SERIES' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = s.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'SERIES' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE s.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, s.sortOrder, s.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<SeriesEntity>(_rawQuery, __db, "series", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<SeriesEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfEpisodesSyncedAt: Int = getColumnIndexOrThrow(_stmt, "episodesSyncedAt")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<SeriesEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: SeriesEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpEpisodesSyncedAt: Long
            _tmpEpisodesSyncedAt = _stmt.getLong(_columnIndexOfEpisodesSyncedAt)
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = SeriesEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpPlot,_tmpRemoteId,_tmpSortOrder,_tmpContentHash,_tmpAddedAt,_tmpEpisodesSyncedAt,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingSeriesAlpha(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, SeriesEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT s.* FROM series s INNER JOIN custom_category_members m ON m.itemId = s.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'SERIES' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = s.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'SERIES' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE s.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, s.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 5
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<SeriesEntity>(_rawQuery, __db, "series", "custom_category_members", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<SeriesEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfEpisodesSyncedAt: Int = getColumnIndexOrThrow(_stmt, "episodesSyncedAt")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<SeriesEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: SeriesEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpEpisodesSyncedAt: Long
            _tmpEpisodesSyncedAt = _stmt.getLong(_columnIndexOfEpisodesSyncedAt)
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = SeriesEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpPlot,_tmpRemoteId,_tmpSortOrder,_tmpContentHash,_tmpAddedAt,_tmpEpisodesSyncedAt,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun countMembers(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    sourceIds: List<Long>,
  ): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM custom_category_members m LEFT JOIN channels c ON m.mediaType = 'LIVE' AND m.itemId = c.id LEFT JOIN movies mv ON m.mediaType = 'MOVIE' AND m.itemId = mv.id LEFT JOIN series s ON m.mediaType = 'SERIES' AND m.itemId = s.id WHERE m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND COALESCE(c.sourceId, mv.sourceId, s.sourceId) IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("custom_category_members", "channels", "movies", "series")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 4
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun itemIds(
    profileId: Long,
    type: MediaType,
    contextKey: String,
  ): List<Long> {
    val _sql: String = "SELECT itemId FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND contextKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotChannels(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN custom_category_members m ON m.itemId = c.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'LIVE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'LIVE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, c.sortOrder, c.name LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 5
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 5 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotMovies(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT mv.* FROM movies mv INNER JOIN custom_category_members m ON m.itemId = mv.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'MOVIE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = mv.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'MOVIE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE mv.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, mv.sortOrder, mv.name LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 5
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 5 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotSeries(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<SeriesEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT s.* FROM series s INNER JOIN custom_category_members m ON m.itemId = s.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'SERIES' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN content_order o ON o.itemId = s.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'SERIES' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE s.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.position, s.sortOrder, s.name LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 5
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 5 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfEpisodesSyncedAt: Int = getColumnIndexOrThrow(_stmt, "episodesSyncedAt")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<SeriesEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: SeriesEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpEpisodesSyncedAt: Long
          _tmpEpisodesSyncedAt = _stmt.getLong(_columnIndexOfEpisodesSyncedAt)
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = SeriesEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpPlot,_tmpRemoteId,_tmpSortOrder,_tmpContentHash,_tmpAddedAt,_tmpEpisodesSyncedAt,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun searchChannels(
    query: String,
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN custom_category_members m ON m.itemId = c.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'LIVE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND c.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY m.position, c.sortOrder, c.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 3 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "custom_category_members") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchMovies(
    query: String,
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT mv.* FROM movies mv INNER JOIN custom_category_members m ON m.itemId = mv.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'MOVIE' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE mv.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND mv.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY m.position, mv.sortOrder, mv.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 3 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "custom_category_members") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchSeries(
    query: String,
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, SeriesEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT s.* FROM series s INNER JOIN custom_category_members m ON m.itemId = s.id AND m.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.mediaType = 'SERIES' AND m.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE s.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND s.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY m.position, s.sortOrder, s.name")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 3 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<SeriesEntity>(_rawQuery, __db, "series", "custom_category_members") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<SeriesEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfEpisodesSyncedAt: Int = getColumnIndexOrThrow(_stmt, "episodesSyncedAt")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<SeriesEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: SeriesEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpEpisodesSyncedAt: Long
            _tmpEpisodesSyncedAt = _stmt.getLong(_columnIndexOfEpisodesSyncedAt)
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = SeriesEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpPlot,_tmpRemoteId,_tmpSortOrder,_tmpContentHash,_tmpAddedAt,_tmpEpisodesSyncedAt,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override suspend fun clearContext(
    profileId: Long,
    type: MediaType,
    contextKey: String,
  ) {
    val _sql: String = "DELETE FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND contextKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteItem(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    itemId: Long,
  ) {
    val _sql: String = "DELETE FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND contextKey = ? AND itemId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 4
        _stmt.bindLong(_argIndex, itemId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeSnapshotOrphan(
    profileId: Long,
    type: MediaType,
    itemId: Long,
  ) {
    val _sql: String = "DELETE FROM custom_category_members WHERE profileId = ? AND mediaType = ? AND itemId = ? AND ((? = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (? = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (? = 'SERIES' AND itemId NOT IN (SELECT id FROM series)))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        _argIndex = 4
        val _tmp_1: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 5
        val _tmp_2: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_2)
        _argIndex = 6
        val _tmp_3: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_3)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeOrphans() {
    val _sql: String = "DELETE FROM custom_category_members WHERE (mediaType = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (mediaType = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (mediaType = 'SERIES' AND itemId NOT IN (SELECT id FROM series))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
