package tv.own.owntv.core.database.dao

import androidx.paging.PagingSource
import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomRawQuery
import androidx.room.coroutines.createFlow
import androidx.room.paging.LimitOffsetPagingSource
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.ContentHashProjection

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class ChannelDao_Impl(
  __db: RoomDatabase,
) : ChannelDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfChannelEntity: EntityInsertAdapter<ChannelEntity>

  private val __insertAdapterOfChannelEntity_1: EntityInsertAdapter<ChannelEntity>

  private val __updateAdapterOfChannelEntity: EntityDeleteOrUpdateAdapter<ChannelEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfChannelEntity = object : EntityInsertAdapter<ChannelEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `channels` (`id`,`sourceId`,`categoryId`,`name`,`logoUrl`,`streamUrl`,`epgChannelId`,`number`,`remoteId`,`sortOrder`,`catchup`,`catchupDays`,`catchupSource`,`catchupType`,`httpHeaders`,`drmConfig`,`manifestType`,`directSource`,`contentHash`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ChannelEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpLogoUrl: String? = entity.logoUrl
        if (_tmpLogoUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpLogoUrl)
        }
        statement.bindText(6, entity.streamUrl)
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpEpgChannelId)
        }
        val _tmpNumber: Int? = entity.number
        if (_tmpNumber == null) {
          statement.bindNull(8)
        } else {
          statement.bindLong(8, _tmpNumber.toLong())
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpRemoteId)
        }
        statement.bindLong(10, entity.sortOrder.toLong())
        val _tmp: Int = if (entity.catchup) 1 else 0
        statement.bindLong(11, _tmp.toLong())
        statement.bindLong(12, entity.catchupDays.toLong())
        val _tmpCatchupSource: String? = entity.catchupSource
        if (_tmpCatchupSource == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpCatchupSource)
        }
        val _tmpCatchupType: String? = entity.catchupType
        if (_tmpCatchupType == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpCatchupType)
        }
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpManifestType)
        }
        val _tmpDirectSource: String? = entity.directSource
        if (_tmpDirectSource == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpDirectSource)
        }
        statement.bindLong(19, entity.contentHash.toLong())
      }
    }
    this.__insertAdapterOfChannelEntity_1 = object : EntityInsertAdapter<ChannelEntity>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `channels` (`id`,`sourceId`,`categoryId`,`name`,`logoUrl`,`streamUrl`,`epgChannelId`,`number`,`remoteId`,`sortOrder`,`catchup`,`catchupDays`,`catchupSource`,`catchupType`,`httpHeaders`,`drmConfig`,`manifestType`,`directSource`,`contentHash`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ChannelEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpLogoUrl: String? = entity.logoUrl
        if (_tmpLogoUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpLogoUrl)
        }
        statement.bindText(6, entity.streamUrl)
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpEpgChannelId)
        }
        val _tmpNumber: Int? = entity.number
        if (_tmpNumber == null) {
          statement.bindNull(8)
        } else {
          statement.bindLong(8, _tmpNumber.toLong())
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpRemoteId)
        }
        statement.bindLong(10, entity.sortOrder.toLong())
        val _tmp: Int = if (entity.catchup) 1 else 0
        statement.bindLong(11, _tmp.toLong())
        statement.bindLong(12, entity.catchupDays.toLong())
        val _tmpCatchupSource: String? = entity.catchupSource
        if (_tmpCatchupSource == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpCatchupSource)
        }
        val _tmpCatchupType: String? = entity.catchupType
        if (_tmpCatchupType == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpCatchupType)
        }
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpManifestType)
        }
        val _tmpDirectSource: String? = entity.directSource
        if (_tmpDirectSource == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpDirectSource)
        }
        statement.bindLong(19, entity.contentHash.toLong())
      }
    }
    this.__updateAdapterOfChannelEntity = object : EntityDeleteOrUpdateAdapter<ChannelEntity>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `channels` SET `id` = ?,`sourceId` = ?,`categoryId` = ?,`name` = ?,`logoUrl` = ?,`streamUrl` = ?,`epgChannelId` = ?,`number` = ?,`remoteId` = ?,`sortOrder` = ?,`catchup` = ?,`catchupDays` = ?,`catchupSource` = ?,`catchupType` = ?,`httpHeaders` = ?,`drmConfig` = ?,`manifestType` = ?,`directSource` = ?,`contentHash` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: ChannelEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpLogoUrl: String? = entity.logoUrl
        if (_tmpLogoUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpLogoUrl)
        }
        statement.bindText(6, entity.streamUrl)
        val _tmpEpgChannelId: String? = entity.epgChannelId
        if (_tmpEpgChannelId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpEpgChannelId)
        }
        val _tmpNumber: Int? = entity.number
        if (_tmpNumber == null) {
          statement.bindNull(8)
        } else {
          statement.bindLong(8, _tmpNumber.toLong())
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpRemoteId)
        }
        statement.bindLong(10, entity.sortOrder.toLong())
        val _tmp: Int = if (entity.catchup) 1 else 0
        statement.bindLong(11, _tmp.toLong())
        statement.bindLong(12, entity.catchupDays.toLong())
        val _tmpCatchupSource: String? = entity.catchupSource
        if (_tmpCatchupSource == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpCatchupSource)
        }
        val _tmpCatchupType: String? = entity.catchupType
        if (_tmpCatchupType == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpCatchupType)
        }
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpManifestType)
        }
        val _tmpDirectSource: String? = entity.directSource
        if (_tmpDirectSource == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpDirectSource)
        }
        statement.bindLong(19, entity.contentHash.toLong())
        statement.bindLong(20, entity.id)
      }
    }
  }

  public override suspend fun upsertAll(channels: List<ChannelEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfChannelEntity.insert(_connection, channels)
  }

  public override suspend fun insertAll(channels: List<ChannelEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfChannelEntity_1.insert(_connection, channels)
  }

  public override suspend fun updateAll(channels: List<ChannelEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfChannelEntity.handleMultiple(_connection, channels)
  }

  public override suspend fun applyPositionMoves(ids: List<Long>, sortOrders: List<Int>): Unit = performInTransactionSuspending(__db) {
    super@ChannelDao_Impl.applyPositionMoves(ids, sortOrders)
  }

  public override suspend fun applyPositionRanges(
    sourceId: Long,
    froms: List<Int>,
    tos: List<Int>,
    deltas: List<Int>,
  ): Unit = performInTransactionSuspending(__db) {
    super@ChannelDao_Impl.applyPositionRanges(sourceId, froms, tos, deltas)
  }

  public override suspend fun getById(id: Long): ChannelEntity? {
    val _sql: String = "SELECT * FROM channels WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: ChannelEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _result = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByRemote(sourceId: Long, remoteId: String): ChannelEntity? {
    val _sql: String = "SELECT * FROM channels WHERE sourceId = ? AND remoteId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, remoteId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: ChannelEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _result = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByName(sourceId: Long, name: String): ChannelEntity? {
    val _sql: String = "SELECT * FROM channels WHERE sourceId = ? AND name = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, name)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: ChannelEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _result = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsForGuide(sourceIds: List<Long>, limit: Int): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND epgChannelId IS NOT NULL AND epgChannelId != '' ORDER BY number ASC, name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allForSources(sourceIds: List<Long>, limit: Int): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId ASC, sortOrder ASC, name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allEpgChannelIds(): List<String> {
    val _sql: String = "SELECT DISTINCT LOWER(TRIM(epgChannelId)) FROM channels WHERE epgChannelId IS NOT NULL AND epgChannelId != ''"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          val _tmp: String
          _tmp = _stmt.getText(0)
          _item = _tmp
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun epgChannelIdsWithoutProgrammes(sourceId: Long): List<String> {
    val _sql: String = "SELECT DISTINCT LOWER(TRIM(epgChannelId)) FROM channels WHERE sourceId = ? AND epgChannelId IS NOT NULL AND TRIM(epgChannelId) != '' AND LOWER(TRIM(epgChannelId)) NOT IN (SELECT DISTINCT epgChannelId FROM epg_programmes)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          val _tmp: String
          _tmp = _stmt.getText(0)
          _item = _tmp
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allCatchupChannels(): List<ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE catchup = 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxCatchupDays(sourceIds: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COALESCE(MAX(catchupDays), 0) FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countCatchup(sourceIds: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsWithGuide(
    sourceIds: List<Long>,
    query: String,
    limit: Int,
  ): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND epgChannelId IS NOT NULL AND epgChannelId != '' AND (")
    _stringBuilder.append("?")
    _stringBuilder.append(" = '' OR name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%') AND LOWER(TRIM(epgChannelId)) IN (  SELECT DISTINCT epgChannelId FROM epg_programmes WHERE sourceId IN (")
    val _inputSize_1: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize_1)
    _stringBuilder.append(")) ORDER BY number ASC, name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, query)
        _argIndex = 2 + _inputSize
        _stmt.bindText(_argIndex, query)
        _argIndex = 3 + _inputSize
        for (_item_1: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item_1)
          _argIndex++
        }
        _argIndex = 3 + _inputSize + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_2: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_2 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_2)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByRemoteIds(sourceIds: List<Long>, remoteIds: List<String>): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND remoteId IN (")
    val _inputSize_1: Int = remoteIds.size
    appendPlaceholders(_stringBuilder, _inputSize_1)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        for (_item_1: String in remoteIds) {
          _stmt.bindText(_argIndex, _item_1)
          _argIndex++
        }
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_2: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_2 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_2)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByRemoteIds(sourceId: Long, remoteIds: List<String>): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND remoteId IN (")
    val _inputSize: Int = remoteIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in remoteIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remoteIdsForSource(sourceId: Long): List<String> {
    val _sql: String = "SELECT remoteId FROM channels WHERE sourceId = ? AND remoteId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun guideKeysForSource(sourceId: Long): List<ChannelGuideKey> {
    val _sql: String = "SELECT remoteId, epgChannelId FROM channels WHERE sourceId = ? AND remoteId IS NOT NULL AND epgChannelId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfRemoteId: Int = 0
        val _columnIndexOfEpgChannelId: Int = 1
        val _result: MutableList<ChannelGuideKey> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelGuideKey
          val _tmpRemoteId: String
          _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          _item = ChannelGuideKey(_tmpRemoteId,_tmpEpgChannelId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun anyRemoteId(sourceId: Long): String? {
    val _sql: String = "SELECT remoteId FROM channels WHERE sourceId = ? AND remoteId IS NOT NULL LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: String?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getText(0)
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remoteIdsInCategories(sourceId: Long, categoryIds: List<Long>): List<String> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT remoteId FROM channels WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND categoryId IN (")
    val _inputSize: Int = categoryIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND remoteId IS NOT NULL")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: Long in categoryIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: String
          _item_1 = _stmt.getText(0)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun contentHashesForSource(sourceId: Long): List<ContentHashProjection> {
    val _sql: String = "SELECT remoteId, id, contentHash, sortOrder FROM channels WHERE sourceId = ? AND remoteId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfRemoteId: Int = 0
        val _columnIndexOfId: Int = 1
        val _columnIndexOfContentHash: Int = 2
        val _columnIndexOfSortOrder: Int = 3
        val _result: MutableList<ContentHashProjection> = mutableListOf()
        while (_stmt.step()) {
          val _item: ContentHashProjection
          val _tmpRemoteId: String
          _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          _item = ContentHashProjection(_tmpRemoteId,_tmpId,_tmpContentHash,_tmpSortOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByNumber(sourceIds: List<Long>, number: Int): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND number = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" ORDER BY sourceId ASC, sortOrder ASC, name ASC, id ASC")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindLong(_argIndex, number.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsAfterCategory(
    categoryId: Long,
    afterSortOrder: Int,
    afterId: Long,
    limit: Int,
  ): List<ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE categoryId = ? AND (sortOrder > ? OR (sortOrder = ? AND id > ?)) ORDER BY sortOrder ASC, id ASC LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, categoryId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, afterSortOrder.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, afterSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, afterId)
        _argIndex = 5
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsBeforeCategory(
    categoryId: Long,
    beforeSortOrder: Int,
    beforeId: Long,
    limit: Int,
  ): List<ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE categoryId = ? AND (sortOrder < ? OR (sortOrder = ? AND id < ?)) ORDER BY sortOrder DESC, id DESC LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, categoryId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, beforeSortOrder.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, beforeSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, beforeId)
        _argIndex = 5
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsAfterSource(
    sourceId: Long,
    afterSortOrder: Int,
    afterId: Long,
    limit: Int,
  ): List<ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE sourceId = ? AND (sortOrder > ? OR (sortOrder = ? AND id > ?)) ORDER BY sortOrder ASC, id ASC LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, afterSortOrder.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, afterSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, afterId)
        _argIndex = 5
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun channelsBeforeSource(
    sourceId: Long,
    beforeSortOrder: Int,
    beforeId: Long,
    limit: Int,
  ): List<ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE sourceId = ? AND (sortOrder < ? OR (sortOrder = ? AND id < ?)) ORDER BY sortOrder DESC, id DESC LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, beforeSortOrder.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, beforeSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, beforeId)
        _argIndex = 5
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pagingByCategory(categoryId: Long): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE categoryId = ? ORDER BY sortOrder ASC, name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryAlpha(categoryId: Long): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE categoryId = ? ORDER BY name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAll(sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAllOriginal(sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId ASC, sortOrder ASC, name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingCatchup(sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1 ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingCatchupOriginal(sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1 ORDER BY sourceId ASC, sortOrder ASC, name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryManual(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
  ): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT c.* FROM channels c LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ? AND o.mediaType = 'LIVE' AND o.contextKey = ? WHERE c.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, c.sortOrder, c.name"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryManualAlpha(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
  ): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT c.* FROM channels c LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ? AND o.mediaType = 'LIVE' AND o.contextKey = ? WHERE c.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, c.name"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingFavoritesManual(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN favorites f ON f.itemId = c.id AND f.mediaType = 'LIVE' LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'LIVE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, f.addedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "favorites", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override suspend fun snapshotByCategoryManual(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
    limit: Int,
  ): List<ChannelEntity> {
    val _sql: String = "SELECT c.* FROM channels c LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ? AND o.mediaType = 'LIVE' AND o.contextKey = ? WHERE c.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, c.sortOrder, c.name LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, categoryId)
        _argIndex = 4
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotAll(sourceIds: List<Long>, limit: Int): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId ASC, sortOrder ASC, name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotFavoritesManual(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN favorites f ON f.itemId = c.id AND f.mediaType = 'LIVE' LEFT JOIN content_order o ON o.itemId = c.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'LIVE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, f.addedAt DESC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 4 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countByCategory(categoryId: Long): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM channels WHERE categoryId = ?"
    return createFlow(__db, false, arrayOf("channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, categoryId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countAll(sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countAllExcluding(sourceIds: List<Long>, excludedCategoryIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND (categoryId IS NULL OR categoryId NOT IN (")
    val _inputSize_1: Int = excludedCategoryIds.size
    appendPlaceholders(_stringBuilder, _inputSize_1)
    _stringBuilder.append("))")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        for (_item_1: Long in excludedCategoryIds) {
          _stmt.bindLong(_argIndex, _item_1)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countForSourceOnce(sourceId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM channels WHERE sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeCatchupCount(sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun search(query: String, sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND id IN (SELECT rowid FROM channels_fts WHERE channels_fts MATCH ")
    _stringBuilder.append("?")
    _stringBuilder.append(") ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "channels_fts") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchAll(query: String, sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchInCategory(query: String, categoryId: Long): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT * FROM channels WHERE categoryId = ? AND name LIKE '%' || ? || '%' ORDER BY sortOrder ASC, name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
      _argIndex = 2
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchCatchup(query: String, sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND catchup = 1 AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override suspend fun searchList(
    query: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, query)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun searchListDetailed(
    query: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<ChannelSearchResult> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.*, cat.name AS categoryName FROM channels c LEFT JOIN categories cat ON c.categoryId = cat.id WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND c.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY c.name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, query)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCategoryName: Int = getColumnIndexOrThrow(_stmt, "categoryName")
        val _result: MutableList<ChannelSearchResult> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelSearchResult
          val _tmpCategoryName: String?
          if (_stmt.isNull(_columnIndexOfCategoryName)) {
            _tmpCategoryName = null
          } else {
            _tmpCategoryName = _stmt.getText(_columnIndexOfCategoryName)
          }
          val _tmpChannel: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _tmpChannel = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _item_1 = ChannelSearchResult(_tmpChannel,_tmpCategoryName)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun searchListDetailedFts(
    ftsQuery: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<ChannelSearchResult> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.*, cat.name AS categoryName FROM channels c LEFT JOIN categories cat ON c.categoryId = cat.id WHERE c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND c.id IN (SELECT rowid FROM channels_fts WHERE channels_fts MATCH ")
    _stringBuilder.append("?")
    _stringBuilder.append(") ORDER BY c.name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, ftsQuery)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCategoryName: Int = getColumnIndexOrThrow(_stmt, "categoryName")
        val _result: MutableList<ChannelSearchResult> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelSearchResult
          val _tmpCategoryName: String?
          if (_stmt.isNull(_columnIndexOfCategoryName)) {
            _tmpCategoryName = null
          } else {
            _tmpCategoryName = _stmt.getText(_columnIndexOfCategoryName)
          }
          val _tmpChannel: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _tmpChannel = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _item_1 = ChannelSearchResult(_tmpChannel,_tmpCategoryName)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun searchFavorites(
    query: String,
    profileId: Long,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN favorites f ON f.itemId = c.id AND f.mediaType = 'LIVE' WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND c.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY f.addedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 2 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "favorites") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchHistory(
    query: String,
    profileId: Long,
    sourceIds: List<Long>,
  ): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN watch_history h ON h.itemId = c.id AND h.mediaType = 'LIVE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND c.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY h.watchedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 2 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "watch_history") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingFavorites(profileId: Long): PagingSource<Int, ChannelEntity> {
    val _sql: String = "SELECT c.* FROM channels c INNER JOIN favorites f ON f.itemId = c.id AND f.mediaType = 'LIVE' WHERE f.profileId = ? ORDER BY f.addedAt DESC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "favorites") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun favoritesListAlpha(profileId: Long): Flow<List<ChannelEntity>> {
    val _sql: String = "SELECT c.* FROM channels c INNER JOIN favorites f ON f.itemId = c.id AND f.mediaType = 'LIVE' WHERE f.profileId = ? ORDER BY LOWER(c.name) ASC, c.id ASC"
    return createFlow(__db, false, arrayOf("channels", "favorites")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countFavorites(profileId: Long, sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM favorites f INNER JOIN channels c ON c.id = f.itemId WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND f.mediaType = 'LIVE' AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("favorites", "channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countHistory(profileId: Long, sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM watch_history h INNER JOIN channels c ON c.id = h.itemId WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND h.mediaType = 'LIVE' AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("watch_history", "channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pagingHistory(profileId: Long, sourceIds: List<Long>): PagingSource<Int, ChannelEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.* FROM channels c INNER JOIN watch_history h ON h.itemId = c.id AND h.mediaType = 'LIVE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY h.watchedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<ChannelEntity>(_rawQuery, __db, "channels", "watch_history") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<ChannelEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
          val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
          val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
          val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
          val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _result: MutableList<ChannelEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: ChannelEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpLogoUrl: String?
            if (_stmt.isNull(_columnIndexOfLogoUrl)) {
              _tmpLogoUrl = null
            } else {
              _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpEpgChannelId: String?
            if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
              _tmpEpgChannelId = null
            } else {
              _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
            }
            val _tmpNumber: Int?
            if (_stmt.isNull(_columnIndexOfNumber)) {
              _tmpNumber = null
            } else {
              _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpCatchup: Boolean
            val _tmp: Int
            _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
            _tmpCatchup = _tmp != 0
            val _tmpCatchupDays: Int
            _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
            val _tmpCatchupSource: String?
            if (_stmt.isNull(_columnIndexOfCatchupSource)) {
              _tmpCatchupSource = null
            } else {
              _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
            }
            val _tmpCatchupType: String?
            if (_stmt.isNull(_columnIndexOfCatchupType)) {
              _tmpCatchupType = null
            } else {
              _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
            }
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpDirectSource: String?
            if (_stmt.isNull(_columnIndexOfDirectSource)) {
              _tmpDirectSource = null
            } else {
              _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            _item_1 = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun recentlyWatched(profileId: Long, limit: Int): Flow<List<ChannelEntity>> {
    val _sql: String = "SELECT c.* FROM channels c INNER JOIN watch_history h ON h.itemId = c.id AND h.mediaType = 'LIVE' WHERE h.profileId = ? ORDER BY h.watchedAt DESC LIMIT ?"
    return createFlow(__db, false, arrayOf("channels", "watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<ChannelEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun recentlyWatchedWithTimestamp(profileId: Long, limit: Int): Flow<List<ChannelWithWatchedAt>> {
    val _sql: String = "SELECT c.*, h.watchedAt FROM channels c INNER JOIN watch_history h ON h.itemId = c.id AND h.mediaType = 'LIVE' WHERE h.profileId = ? ORDER BY h.watchedAt DESC LIMIT ?"
    return createFlow(__db, false, arrayOf("channels", "watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: MutableList<ChannelWithWatchedAt> = mutableListOf()
        while (_stmt.step()) {
          val _item: ChannelWithWatchedAt
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          val _tmpChannel: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _tmpChannel = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _item = ChannelWithWatchedAt(_tmpChannel,_tmpWatchedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun recentlyWatchedWithTimestampFiltered(
    profileId: Long,
    sourceIds: List<Long>,
    limit: Int,
  ): Flow<List<ChannelWithWatchedAt>> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT c.*, h.watchedAt FROM channels c INNER JOIN watch_history h ON h.itemId = c.id AND h.mediaType = 'LIVE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND c.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY h.watchedAt DESC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("channels", "watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfLogoUrl: Int = getColumnIndexOrThrow(_stmt, "logoUrl")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfNumber: Int = getColumnIndexOrThrow(_stmt, "number")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCatchup: Int = getColumnIndexOrThrow(_stmt, "catchup")
        val _columnIndexOfCatchupDays: Int = getColumnIndexOrThrow(_stmt, "catchupDays")
        val _columnIndexOfCatchupSource: Int = getColumnIndexOrThrow(_stmt, "catchupSource")
        val _columnIndexOfCatchupType: Int = getColumnIndexOrThrow(_stmt, "catchupType")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfDirectSource: Int = getColumnIndexOrThrow(_stmt, "directSource")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: MutableList<ChannelWithWatchedAt> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: ChannelWithWatchedAt
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          val _tmpChannel: ChannelEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpLogoUrl: String?
          if (_stmt.isNull(_columnIndexOfLogoUrl)) {
            _tmpLogoUrl = null
          } else {
            _tmpLogoUrl = _stmt.getText(_columnIndexOfLogoUrl)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpEpgChannelId: String?
          if (_stmt.isNull(_columnIndexOfEpgChannelId)) {
            _tmpEpgChannelId = null
          } else {
            _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          }
          val _tmpNumber: Int?
          if (_stmt.isNull(_columnIndexOfNumber)) {
            _tmpNumber = null
          } else {
            _tmpNumber = _stmt.getLong(_columnIndexOfNumber).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCatchup: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCatchup).toInt()
          _tmpCatchup = _tmp != 0
          val _tmpCatchupDays: Int
          _tmpCatchupDays = _stmt.getLong(_columnIndexOfCatchupDays).toInt()
          val _tmpCatchupSource: String?
          if (_stmt.isNull(_columnIndexOfCatchupSource)) {
            _tmpCatchupSource = null
          } else {
            _tmpCatchupSource = _stmt.getText(_columnIndexOfCatchupSource)
          }
          val _tmpCatchupType: String?
          if (_stmt.isNull(_columnIndexOfCatchupType)) {
            _tmpCatchupType = null
          } else {
            _tmpCatchupType = _stmt.getText(_columnIndexOfCatchupType)
          }
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpDirectSource: String?
          if (_stmt.isNull(_columnIndexOfDirectSource)) {
            _tmpDirectSource = null
          } else {
            _tmpDirectSource = _stmt.getText(_columnIndexOfDirectSource)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _tmpChannel = ChannelEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpLogoUrl,_tmpStreamUrl,_tmpEpgChannelId,_tmpNumber,_tmpRemoteId,_tmpSortOrder,_tmpCatchup,_tmpCatchupDays,_tmpCatchupSource,_tmpCatchupType,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpDirectSource,_tmpContentHash)
          _item_1 = ChannelWithWatchedAt(_tmpChannel,_tmpWatchedAt)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearSource(sourceId: Long) {
    val _sql: String = "DELETE FROM channels WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteNullRemoteIds(sourceId: Long) {
    val _sql: String = "DELETE FROM channels WHERE sourceId = ? AND remoteId IS NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setSortOrder(id: Long, sortOrder: Int) {
    val _sql: String = "UPDATE channels SET sortOrder = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sortOrder.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun shiftSortOrders(
    sourceId: Long,
    fromSortOrder: Int,
    toSortOrder: Int,
    delta: Int,
  ) {
    val _sql: String = "UPDATE channels SET sortOrder = sortOrder + ? WHERE sourceId = ? AND sortOrder BETWEEN ? AND ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, delta.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, fromSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, toSortOrder.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteByRemoteIds(sourceId: Long, remoteIds: List<String>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM channels WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND remoteId IN (")
    val _inputSize: Int = remoteIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in remoteIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
