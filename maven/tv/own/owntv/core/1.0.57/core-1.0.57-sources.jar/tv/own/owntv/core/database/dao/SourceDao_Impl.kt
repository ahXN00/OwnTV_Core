package tv.own.owntv.core.database.dao

import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.ProfileSourceCrossRef
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.HlsSupport
import tv.own.owntv.core.model.SourceType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class SourceDao_Impl(
  __db: RoomDatabase,
) : SourceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSourceEntity: EntityInsertAdapter<SourceEntity>

  private val __converters: Converters = Converters()

  private val __insertAdapterOfProfileSourceCrossRef: EntityInsertAdapter<ProfileSourceCrossRef>

  private val __deleteAdapterOfSourceEntity: EntityDeleteOrUpdateAdapter<SourceEntity>

  private val __updateAdapterOfSourceEntity: EntityDeleteOrUpdateAdapter<SourceEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfSourceEntity = object : EntityInsertAdapter<SourceEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `sources` (`id`,`name`,`type`,`url`,`username`,`password`,`mac`,`stalkerSerialNumber`,`stalkerDeviceId`,`stalkerDeviceId2`,`stalkerSignature`,`userAgent`,`epgUrl`,`syncLive`,`syncMovies`,`syncSeries`,`importPortalEpg`,`hlsSupported`,`preferHls`,`livePrerollSecs`,`liveEnginePreference`,`liveLatencyMode`,`liveLatencyCustomSecs`,`maxConnections`,`maxConnectionsProbedAt`,`createdAt`,`lastSyncAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SourceEntity) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmp: String = __converters.sourceTypeToString(entity.type)
        statement.bindText(3, _tmp)
        statement.bindText(4, entity.url)
        val _tmpUsername: String? = entity.username
        if (_tmpUsername == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpUsername)
        }
        val _tmpPassword: String? = entity.password
        if (_tmpPassword == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpPassword)
        }
        val _tmpMac: String? = entity.mac
        if (_tmpMac == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpMac)
        }
        val _tmpStalkerSerialNumber: String? = entity.stalkerSerialNumber
        if (_tmpStalkerSerialNumber == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpStalkerSerialNumber)
        }
        val _tmpStalkerDeviceId: String? = entity.stalkerDeviceId
        if (_tmpStalkerDeviceId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpStalkerDeviceId)
        }
        val _tmpStalkerDeviceId2: String? = entity.stalkerDeviceId2
        if (_tmpStalkerDeviceId2 == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpStalkerDeviceId2)
        }
        val _tmpStalkerSignature: String? = entity.stalkerSignature
        if (_tmpStalkerSignature == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpStalkerSignature)
        }
        val _tmpUserAgent: String? = entity.userAgent
        if (_tmpUserAgent == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpUserAgent)
        }
        val _tmpEpgUrl: String? = entity.epgUrl
        if (_tmpEpgUrl == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpEpgUrl)
        }
        val _tmp_1: Int = if (entity.syncLive) 1 else 0
        statement.bindLong(14, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.syncMovies) 1 else 0
        statement.bindLong(15, _tmp_2.toLong())
        val _tmp_3: Int = if (entity.syncSeries) 1 else 0
        statement.bindLong(16, _tmp_3.toLong())
        val _tmp_4: Int = if (entity.importPortalEpg) 1 else 0
        statement.bindLong(17, _tmp_4.toLong())
        val _tmp_5: Int = __converters.hlsSupportToInt(entity.hlsSupported)
        statement.bindLong(18, _tmp_5.toLong())
        val _tmp_6: Int = if (entity.preferHls) 1 else 0
        statement.bindLong(19, _tmp_6.toLong())
        statement.bindLong(20, entity.livePrerollSecs.toLong())
        val _tmpLiveEnginePreference: String? = entity.liveEnginePreference
        if (_tmpLiveEnginePreference == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpLiveEnginePreference)
        }
        val _tmpLiveLatencyMode: String? = entity.liveLatencyMode
        if (_tmpLiveLatencyMode == null) {
          statement.bindNull(22)
        } else {
          statement.bindText(22, _tmpLiveLatencyMode)
        }
        statement.bindLong(23, entity.liveLatencyCustomSecs.toLong())
        statement.bindLong(24, entity.maxConnections.toLong())
        statement.bindLong(25, entity.maxConnectionsProbedAt)
        statement.bindLong(26, entity.createdAt)
        val _tmpLastSyncAt: Long? = entity.lastSyncAt
        if (_tmpLastSyncAt == null) {
          statement.bindNull(27)
        } else {
          statement.bindLong(27, _tmpLastSyncAt)
        }
      }
    }
    this.__insertAdapterOfProfileSourceCrossRef = object : EntityInsertAdapter<ProfileSourceCrossRef>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `profile_source` (`profileId`,`sourceId`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ProfileSourceCrossRef) {
        statement.bindLong(1, entity.profileId)
        statement.bindLong(2, entity.sourceId)
      }
    }
    this.__deleteAdapterOfSourceEntity = object : EntityDeleteOrUpdateAdapter<SourceEntity>() {
      protected override fun createQuery(): String = "DELETE FROM `sources` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SourceEntity) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfSourceEntity = object : EntityDeleteOrUpdateAdapter<SourceEntity>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `sources` SET `id` = ?,`name` = ?,`type` = ?,`url` = ?,`username` = ?,`password` = ?,`mac` = ?,`stalkerSerialNumber` = ?,`stalkerDeviceId` = ?,`stalkerDeviceId2` = ?,`stalkerSignature` = ?,`userAgent` = ?,`epgUrl` = ?,`syncLive` = ?,`syncMovies` = ?,`syncSeries` = ?,`importPortalEpg` = ?,`hlsSupported` = ?,`preferHls` = ?,`livePrerollSecs` = ?,`liveEnginePreference` = ?,`liveLatencyMode` = ?,`liveLatencyCustomSecs` = ?,`maxConnections` = ?,`maxConnectionsProbedAt` = ?,`createdAt` = ?,`lastSyncAt` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SourceEntity) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmp: String = __converters.sourceTypeToString(entity.type)
        statement.bindText(3, _tmp)
        statement.bindText(4, entity.url)
        val _tmpUsername: String? = entity.username
        if (_tmpUsername == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpUsername)
        }
        val _tmpPassword: String? = entity.password
        if (_tmpPassword == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpPassword)
        }
        val _tmpMac: String? = entity.mac
        if (_tmpMac == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpMac)
        }
        val _tmpStalkerSerialNumber: String? = entity.stalkerSerialNumber
        if (_tmpStalkerSerialNumber == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpStalkerSerialNumber)
        }
        val _tmpStalkerDeviceId: String? = entity.stalkerDeviceId
        if (_tmpStalkerDeviceId == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpStalkerDeviceId)
        }
        val _tmpStalkerDeviceId2: String? = entity.stalkerDeviceId2
        if (_tmpStalkerDeviceId2 == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpStalkerDeviceId2)
        }
        val _tmpStalkerSignature: String? = entity.stalkerSignature
        if (_tmpStalkerSignature == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpStalkerSignature)
        }
        val _tmpUserAgent: String? = entity.userAgent
        if (_tmpUserAgent == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpUserAgent)
        }
        val _tmpEpgUrl: String? = entity.epgUrl
        if (_tmpEpgUrl == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpEpgUrl)
        }
        val _tmp_1: Int = if (entity.syncLive) 1 else 0
        statement.bindLong(14, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.syncMovies) 1 else 0
        statement.bindLong(15, _tmp_2.toLong())
        val _tmp_3: Int = if (entity.syncSeries) 1 else 0
        statement.bindLong(16, _tmp_3.toLong())
        val _tmp_4: Int = if (entity.importPortalEpg) 1 else 0
        statement.bindLong(17, _tmp_4.toLong())
        val _tmp_5: Int = __converters.hlsSupportToInt(entity.hlsSupported)
        statement.bindLong(18, _tmp_5.toLong())
        val _tmp_6: Int = if (entity.preferHls) 1 else 0
        statement.bindLong(19, _tmp_6.toLong())
        statement.bindLong(20, entity.livePrerollSecs.toLong())
        val _tmpLiveEnginePreference: String? = entity.liveEnginePreference
        if (_tmpLiveEnginePreference == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpLiveEnginePreference)
        }
        val _tmpLiveLatencyMode: String? = entity.liveLatencyMode
        if (_tmpLiveLatencyMode == null) {
          statement.bindNull(22)
        } else {
          statement.bindText(22, _tmpLiveLatencyMode)
        }
        statement.bindLong(23, entity.liveLatencyCustomSecs.toLong())
        statement.bindLong(24, entity.maxConnections.toLong())
        statement.bindLong(25, entity.maxConnectionsProbedAt)
        statement.bindLong(26, entity.createdAt)
        val _tmpLastSyncAt: Long? = entity.lastSyncAt
        if (_tmpLastSyncAt == null) {
          statement.bindNull(27)
        } else {
          statement.bindLong(27, _tmpLastSyncAt)
        }
        statement.bindLong(28, entity.id)
      }
    }
  }

  public override suspend fun insert(source: SourceEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfSourceEntity.insertAndReturnId(_connection, source)
    _result
  }

  public override suspend fun link(ref: ProfileSourceCrossRef): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfProfileSourceCrossRef.insert(_connection, ref)
  }

  public override suspend fun delete(source: SourceEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfSourceEntity.handle(_connection, source)
  }

  public override suspend fun update(source: SourceEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfSourceEntity.handle(_connection, source)
  }

  public override suspend fun getById(id: Long): SourceEntity? {
    val _sql: String = "SELECT * FROM sources WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfUsername: Int = getColumnIndexOrThrow(_stmt, "username")
        val _columnIndexOfPassword: Int = getColumnIndexOrThrow(_stmt, "password")
        val _columnIndexOfMac: Int = getColumnIndexOrThrow(_stmt, "mac")
        val _columnIndexOfStalkerSerialNumber: Int = getColumnIndexOrThrow(_stmt, "stalkerSerialNumber")
        val _columnIndexOfStalkerDeviceId: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId")
        val _columnIndexOfStalkerDeviceId2: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId2")
        val _columnIndexOfStalkerSignature: Int = getColumnIndexOrThrow(_stmt, "stalkerSignature")
        val _columnIndexOfUserAgent: Int = getColumnIndexOrThrow(_stmt, "userAgent")
        val _columnIndexOfEpgUrl: Int = getColumnIndexOrThrow(_stmt, "epgUrl")
        val _columnIndexOfSyncLive: Int = getColumnIndexOrThrow(_stmt, "syncLive")
        val _columnIndexOfSyncMovies: Int = getColumnIndexOrThrow(_stmt, "syncMovies")
        val _columnIndexOfSyncSeries: Int = getColumnIndexOrThrow(_stmt, "syncSeries")
        val _columnIndexOfImportPortalEpg: Int = getColumnIndexOrThrow(_stmt, "importPortalEpg")
        val _columnIndexOfHlsSupported: Int = getColumnIndexOrThrow(_stmt, "hlsSupported")
        val _columnIndexOfPreferHls: Int = getColumnIndexOrThrow(_stmt, "preferHls")
        val _columnIndexOfLivePrerollSecs: Int = getColumnIndexOrThrow(_stmt, "livePrerollSecs")
        val _columnIndexOfLiveEnginePreference: Int = getColumnIndexOrThrow(_stmt, "liveEnginePreference")
        val _columnIndexOfLiveLatencyMode: Int = getColumnIndexOrThrow(_stmt, "liveLatencyMode")
        val _columnIndexOfLiveLatencyCustomSecs: Int = getColumnIndexOrThrow(_stmt, "liveLatencyCustomSecs")
        val _columnIndexOfMaxConnections: Int = getColumnIndexOrThrow(_stmt, "maxConnections")
        val _columnIndexOfMaxConnectionsProbedAt: Int = getColumnIndexOrThrow(_stmt, "maxConnectionsProbedAt")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfLastSyncAt: Int = getColumnIndexOrThrow(_stmt, "lastSyncAt")
        val _result: SourceEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: SourceType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfType)
          _tmpType = __converters.stringToSourceType(_tmp)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpUsername: String?
          if (_stmt.isNull(_columnIndexOfUsername)) {
            _tmpUsername = null
          } else {
            _tmpUsername = _stmt.getText(_columnIndexOfUsername)
          }
          val _tmpPassword: String?
          if (_stmt.isNull(_columnIndexOfPassword)) {
            _tmpPassword = null
          } else {
            _tmpPassword = _stmt.getText(_columnIndexOfPassword)
          }
          val _tmpMac: String?
          if (_stmt.isNull(_columnIndexOfMac)) {
            _tmpMac = null
          } else {
            _tmpMac = _stmt.getText(_columnIndexOfMac)
          }
          val _tmpStalkerSerialNumber: String?
          if (_stmt.isNull(_columnIndexOfStalkerSerialNumber)) {
            _tmpStalkerSerialNumber = null
          } else {
            _tmpStalkerSerialNumber = _stmt.getText(_columnIndexOfStalkerSerialNumber)
          }
          val _tmpStalkerDeviceId: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId)) {
            _tmpStalkerDeviceId = null
          } else {
            _tmpStalkerDeviceId = _stmt.getText(_columnIndexOfStalkerDeviceId)
          }
          val _tmpStalkerDeviceId2: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId2)) {
            _tmpStalkerDeviceId2 = null
          } else {
            _tmpStalkerDeviceId2 = _stmt.getText(_columnIndexOfStalkerDeviceId2)
          }
          val _tmpStalkerSignature: String?
          if (_stmt.isNull(_columnIndexOfStalkerSignature)) {
            _tmpStalkerSignature = null
          } else {
            _tmpStalkerSignature = _stmt.getText(_columnIndexOfStalkerSignature)
          }
          val _tmpUserAgent: String?
          if (_stmt.isNull(_columnIndexOfUserAgent)) {
            _tmpUserAgent = null
          } else {
            _tmpUserAgent = _stmt.getText(_columnIndexOfUserAgent)
          }
          val _tmpEpgUrl: String?
          if (_stmt.isNull(_columnIndexOfEpgUrl)) {
            _tmpEpgUrl = null
          } else {
            _tmpEpgUrl = _stmt.getText(_columnIndexOfEpgUrl)
          }
          val _tmpSyncLive: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfSyncLive).toInt()
          _tmpSyncLive = _tmp_1 != 0
          val _tmpSyncMovies: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfSyncMovies).toInt()
          _tmpSyncMovies = _tmp_2 != 0
          val _tmpSyncSeries: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfSyncSeries).toInt()
          _tmpSyncSeries = _tmp_3 != 0
          val _tmpImportPortalEpg: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfImportPortalEpg).toInt()
          _tmpImportPortalEpg = _tmp_4 != 0
          val _tmpHlsSupported: HlsSupport
          val _tmp_5: Int
          _tmp_5 = _stmt.getLong(_columnIndexOfHlsSupported).toInt()
          _tmpHlsSupported = __converters.intToHlsSupport(_tmp_5)
          val _tmpPreferHls: Boolean
          val _tmp_6: Int
          _tmp_6 = _stmt.getLong(_columnIndexOfPreferHls).toInt()
          _tmpPreferHls = _tmp_6 != 0
          val _tmpLivePrerollSecs: Int
          _tmpLivePrerollSecs = _stmt.getLong(_columnIndexOfLivePrerollSecs).toInt()
          val _tmpLiveEnginePreference: String?
          if (_stmt.isNull(_columnIndexOfLiveEnginePreference)) {
            _tmpLiveEnginePreference = null
          } else {
            _tmpLiveEnginePreference = _stmt.getText(_columnIndexOfLiveEnginePreference)
          }
          val _tmpLiveLatencyMode: String?
          if (_stmt.isNull(_columnIndexOfLiveLatencyMode)) {
            _tmpLiveLatencyMode = null
          } else {
            _tmpLiveLatencyMode = _stmt.getText(_columnIndexOfLiveLatencyMode)
          }
          val _tmpLiveLatencyCustomSecs: Int
          _tmpLiveLatencyCustomSecs = _stmt.getLong(_columnIndexOfLiveLatencyCustomSecs).toInt()
          val _tmpMaxConnections: Int
          _tmpMaxConnections = _stmt.getLong(_columnIndexOfMaxConnections).toInt()
          val _tmpMaxConnectionsProbedAt: Long
          _tmpMaxConnectionsProbedAt = _stmt.getLong(_columnIndexOfMaxConnectionsProbedAt)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpLastSyncAt: Long?
          if (_stmt.isNull(_columnIndexOfLastSyncAt)) {
            _tmpLastSyncAt = null
          } else {
            _tmpLastSyncAt = _stmt.getLong(_columnIndexOfLastSyncAt)
          }
          _result = SourceEntity(_tmpId,_tmpName,_tmpType,_tmpUrl,_tmpUsername,_tmpPassword,_tmpMac,_tmpStalkerSerialNumber,_tmpStalkerDeviceId,_tmpStalkerDeviceId2,_tmpStalkerSignature,_tmpUserAgent,_tmpEpgUrl,_tmpSyncLive,_tmpSyncMovies,_tmpSyncSeries,_tmpImportPortalEpg,_tmpHlsSupported,_tmpPreferHls,_tmpLivePrerollSecs,_tmpLiveEnginePreference,_tmpLiveLatencyMode,_tmpLiveLatencyCustomSecs,_tmpMaxConnections,_tmpMaxConnectionsProbedAt,_tmpCreatedAt,_tmpLastSyncAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAll(): Flow<List<SourceEntity>> {
    val _sql: String = "SELECT * FROM sources ORDER BY createdAt ASC"
    return createFlow(__db, false, arrayOf("sources")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfUsername: Int = getColumnIndexOrThrow(_stmt, "username")
        val _columnIndexOfPassword: Int = getColumnIndexOrThrow(_stmt, "password")
        val _columnIndexOfMac: Int = getColumnIndexOrThrow(_stmt, "mac")
        val _columnIndexOfStalkerSerialNumber: Int = getColumnIndexOrThrow(_stmt, "stalkerSerialNumber")
        val _columnIndexOfStalkerDeviceId: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId")
        val _columnIndexOfStalkerDeviceId2: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId2")
        val _columnIndexOfStalkerSignature: Int = getColumnIndexOrThrow(_stmt, "stalkerSignature")
        val _columnIndexOfUserAgent: Int = getColumnIndexOrThrow(_stmt, "userAgent")
        val _columnIndexOfEpgUrl: Int = getColumnIndexOrThrow(_stmt, "epgUrl")
        val _columnIndexOfSyncLive: Int = getColumnIndexOrThrow(_stmt, "syncLive")
        val _columnIndexOfSyncMovies: Int = getColumnIndexOrThrow(_stmt, "syncMovies")
        val _columnIndexOfSyncSeries: Int = getColumnIndexOrThrow(_stmt, "syncSeries")
        val _columnIndexOfImportPortalEpg: Int = getColumnIndexOrThrow(_stmt, "importPortalEpg")
        val _columnIndexOfHlsSupported: Int = getColumnIndexOrThrow(_stmt, "hlsSupported")
        val _columnIndexOfPreferHls: Int = getColumnIndexOrThrow(_stmt, "preferHls")
        val _columnIndexOfLivePrerollSecs: Int = getColumnIndexOrThrow(_stmt, "livePrerollSecs")
        val _columnIndexOfLiveEnginePreference: Int = getColumnIndexOrThrow(_stmt, "liveEnginePreference")
        val _columnIndexOfLiveLatencyMode: Int = getColumnIndexOrThrow(_stmt, "liveLatencyMode")
        val _columnIndexOfLiveLatencyCustomSecs: Int = getColumnIndexOrThrow(_stmt, "liveLatencyCustomSecs")
        val _columnIndexOfMaxConnections: Int = getColumnIndexOrThrow(_stmt, "maxConnections")
        val _columnIndexOfMaxConnectionsProbedAt: Int = getColumnIndexOrThrow(_stmt, "maxConnectionsProbedAt")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfLastSyncAt: Int = getColumnIndexOrThrow(_stmt, "lastSyncAt")
        val _result: MutableList<SourceEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: SourceType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfType)
          _tmpType = __converters.stringToSourceType(_tmp)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpUsername: String?
          if (_stmt.isNull(_columnIndexOfUsername)) {
            _tmpUsername = null
          } else {
            _tmpUsername = _stmt.getText(_columnIndexOfUsername)
          }
          val _tmpPassword: String?
          if (_stmt.isNull(_columnIndexOfPassword)) {
            _tmpPassword = null
          } else {
            _tmpPassword = _stmt.getText(_columnIndexOfPassword)
          }
          val _tmpMac: String?
          if (_stmt.isNull(_columnIndexOfMac)) {
            _tmpMac = null
          } else {
            _tmpMac = _stmt.getText(_columnIndexOfMac)
          }
          val _tmpStalkerSerialNumber: String?
          if (_stmt.isNull(_columnIndexOfStalkerSerialNumber)) {
            _tmpStalkerSerialNumber = null
          } else {
            _tmpStalkerSerialNumber = _stmt.getText(_columnIndexOfStalkerSerialNumber)
          }
          val _tmpStalkerDeviceId: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId)) {
            _tmpStalkerDeviceId = null
          } else {
            _tmpStalkerDeviceId = _stmt.getText(_columnIndexOfStalkerDeviceId)
          }
          val _tmpStalkerDeviceId2: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId2)) {
            _tmpStalkerDeviceId2 = null
          } else {
            _tmpStalkerDeviceId2 = _stmt.getText(_columnIndexOfStalkerDeviceId2)
          }
          val _tmpStalkerSignature: String?
          if (_stmt.isNull(_columnIndexOfStalkerSignature)) {
            _tmpStalkerSignature = null
          } else {
            _tmpStalkerSignature = _stmt.getText(_columnIndexOfStalkerSignature)
          }
          val _tmpUserAgent: String?
          if (_stmt.isNull(_columnIndexOfUserAgent)) {
            _tmpUserAgent = null
          } else {
            _tmpUserAgent = _stmt.getText(_columnIndexOfUserAgent)
          }
          val _tmpEpgUrl: String?
          if (_stmt.isNull(_columnIndexOfEpgUrl)) {
            _tmpEpgUrl = null
          } else {
            _tmpEpgUrl = _stmt.getText(_columnIndexOfEpgUrl)
          }
          val _tmpSyncLive: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfSyncLive).toInt()
          _tmpSyncLive = _tmp_1 != 0
          val _tmpSyncMovies: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfSyncMovies).toInt()
          _tmpSyncMovies = _tmp_2 != 0
          val _tmpSyncSeries: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfSyncSeries).toInt()
          _tmpSyncSeries = _tmp_3 != 0
          val _tmpImportPortalEpg: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfImportPortalEpg).toInt()
          _tmpImportPortalEpg = _tmp_4 != 0
          val _tmpHlsSupported: HlsSupport
          val _tmp_5: Int
          _tmp_5 = _stmt.getLong(_columnIndexOfHlsSupported).toInt()
          _tmpHlsSupported = __converters.intToHlsSupport(_tmp_5)
          val _tmpPreferHls: Boolean
          val _tmp_6: Int
          _tmp_6 = _stmt.getLong(_columnIndexOfPreferHls).toInt()
          _tmpPreferHls = _tmp_6 != 0
          val _tmpLivePrerollSecs: Int
          _tmpLivePrerollSecs = _stmt.getLong(_columnIndexOfLivePrerollSecs).toInt()
          val _tmpLiveEnginePreference: String?
          if (_stmt.isNull(_columnIndexOfLiveEnginePreference)) {
            _tmpLiveEnginePreference = null
          } else {
            _tmpLiveEnginePreference = _stmt.getText(_columnIndexOfLiveEnginePreference)
          }
          val _tmpLiveLatencyMode: String?
          if (_stmt.isNull(_columnIndexOfLiveLatencyMode)) {
            _tmpLiveLatencyMode = null
          } else {
            _tmpLiveLatencyMode = _stmt.getText(_columnIndexOfLiveLatencyMode)
          }
          val _tmpLiveLatencyCustomSecs: Int
          _tmpLiveLatencyCustomSecs = _stmt.getLong(_columnIndexOfLiveLatencyCustomSecs).toInt()
          val _tmpMaxConnections: Int
          _tmpMaxConnections = _stmt.getLong(_columnIndexOfMaxConnections).toInt()
          val _tmpMaxConnectionsProbedAt: Long
          _tmpMaxConnectionsProbedAt = _stmt.getLong(_columnIndexOfMaxConnectionsProbedAt)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpLastSyncAt: Long?
          if (_stmt.isNull(_columnIndexOfLastSyncAt)) {
            _tmpLastSyncAt = null
          } else {
            _tmpLastSyncAt = _stmt.getLong(_columnIndexOfLastSyncAt)
          }
          _item = SourceEntity(_tmpId,_tmpName,_tmpType,_tmpUrl,_tmpUsername,_tmpPassword,_tmpMac,_tmpStalkerSerialNumber,_tmpStalkerDeviceId,_tmpStalkerDeviceId2,_tmpStalkerSignature,_tmpUserAgent,_tmpEpgUrl,_tmpSyncLive,_tmpSyncMovies,_tmpSyncSeries,_tmpImportPortalEpg,_tmpHlsSupported,_tmpPreferHls,_tmpLivePrerollSecs,_tmpLiveEnginePreference,_tmpLiveLatencyMode,_tmpLiveLatencyCustomSecs,_tmpMaxConnections,_tmpMaxConnectionsProbedAt,_tmpCreatedAt,_tmpLastSyncAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeForProfile(profileId: Long): Flow<List<SourceEntity>> {
    val _sql: String = "SELECT s.* FROM sources s INNER JOIN profile_source ps ON ps.sourceId = s.id WHERE ps.profileId = ? ORDER BY s.createdAt ASC"
    return createFlow(__db, false, arrayOf("sources", "profile_source")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfUsername: Int = getColumnIndexOrThrow(_stmt, "username")
        val _columnIndexOfPassword: Int = getColumnIndexOrThrow(_stmt, "password")
        val _columnIndexOfMac: Int = getColumnIndexOrThrow(_stmt, "mac")
        val _columnIndexOfStalkerSerialNumber: Int = getColumnIndexOrThrow(_stmt, "stalkerSerialNumber")
        val _columnIndexOfStalkerDeviceId: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId")
        val _columnIndexOfStalkerDeviceId2: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId2")
        val _columnIndexOfStalkerSignature: Int = getColumnIndexOrThrow(_stmt, "stalkerSignature")
        val _columnIndexOfUserAgent: Int = getColumnIndexOrThrow(_stmt, "userAgent")
        val _columnIndexOfEpgUrl: Int = getColumnIndexOrThrow(_stmt, "epgUrl")
        val _columnIndexOfSyncLive: Int = getColumnIndexOrThrow(_stmt, "syncLive")
        val _columnIndexOfSyncMovies: Int = getColumnIndexOrThrow(_stmt, "syncMovies")
        val _columnIndexOfSyncSeries: Int = getColumnIndexOrThrow(_stmt, "syncSeries")
        val _columnIndexOfImportPortalEpg: Int = getColumnIndexOrThrow(_stmt, "importPortalEpg")
        val _columnIndexOfHlsSupported: Int = getColumnIndexOrThrow(_stmt, "hlsSupported")
        val _columnIndexOfPreferHls: Int = getColumnIndexOrThrow(_stmt, "preferHls")
        val _columnIndexOfLivePrerollSecs: Int = getColumnIndexOrThrow(_stmt, "livePrerollSecs")
        val _columnIndexOfLiveEnginePreference: Int = getColumnIndexOrThrow(_stmt, "liveEnginePreference")
        val _columnIndexOfLiveLatencyMode: Int = getColumnIndexOrThrow(_stmt, "liveLatencyMode")
        val _columnIndexOfLiveLatencyCustomSecs: Int = getColumnIndexOrThrow(_stmt, "liveLatencyCustomSecs")
        val _columnIndexOfMaxConnections: Int = getColumnIndexOrThrow(_stmt, "maxConnections")
        val _columnIndexOfMaxConnectionsProbedAt: Int = getColumnIndexOrThrow(_stmt, "maxConnectionsProbedAt")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfLastSyncAt: Int = getColumnIndexOrThrow(_stmt, "lastSyncAt")
        val _result: MutableList<SourceEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: SourceType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfType)
          _tmpType = __converters.stringToSourceType(_tmp)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpUsername: String?
          if (_stmt.isNull(_columnIndexOfUsername)) {
            _tmpUsername = null
          } else {
            _tmpUsername = _stmt.getText(_columnIndexOfUsername)
          }
          val _tmpPassword: String?
          if (_stmt.isNull(_columnIndexOfPassword)) {
            _tmpPassword = null
          } else {
            _tmpPassword = _stmt.getText(_columnIndexOfPassword)
          }
          val _tmpMac: String?
          if (_stmt.isNull(_columnIndexOfMac)) {
            _tmpMac = null
          } else {
            _tmpMac = _stmt.getText(_columnIndexOfMac)
          }
          val _tmpStalkerSerialNumber: String?
          if (_stmt.isNull(_columnIndexOfStalkerSerialNumber)) {
            _tmpStalkerSerialNumber = null
          } else {
            _tmpStalkerSerialNumber = _stmt.getText(_columnIndexOfStalkerSerialNumber)
          }
          val _tmpStalkerDeviceId: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId)) {
            _tmpStalkerDeviceId = null
          } else {
            _tmpStalkerDeviceId = _stmt.getText(_columnIndexOfStalkerDeviceId)
          }
          val _tmpStalkerDeviceId2: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId2)) {
            _tmpStalkerDeviceId2 = null
          } else {
            _tmpStalkerDeviceId2 = _stmt.getText(_columnIndexOfStalkerDeviceId2)
          }
          val _tmpStalkerSignature: String?
          if (_stmt.isNull(_columnIndexOfStalkerSignature)) {
            _tmpStalkerSignature = null
          } else {
            _tmpStalkerSignature = _stmt.getText(_columnIndexOfStalkerSignature)
          }
          val _tmpUserAgent: String?
          if (_stmt.isNull(_columnIndexOfUserAgent)) {
            _tmpUserAgent = null
          } else {
            _tmpUserAgent = _stmt.getText(_columnIndexOfUserAgent)
          }
          val _tmpEpgUrl: String?
          if (_stmt.isNull(_columnIndexOfEpgUrl)) {
            _tmpEpgUrl = null
          } else {
            _tmpEpgUrl = _stmt.getText(_columnIndexOfEpgUrl)
          }
          val _tmpSyncLive: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfSyncLive).toInt()
          _tmpSyncLive = _tmp_1 != 0
          val _tmpSyncMovies: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfSyncMovies).toInt()
          _tmpSyncMovies = _tmp_2 != 0
          val _tmpSyncSeries: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfSyncSeries).toInt()
          _tmpSyncSeries = _tmp_3 != 0
          val _tmpImportPortalEpg: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfImportPortalEpg).toInt()
          _tmpImportPortalEpg = _tmp_4 != 0
          val _tmpHlsSupported: HlsSupport
          val _tmp_5: Int
          _tmp_5 = _stmt.getLong(_columnIndexOfHlsSupported).toInt()
          _tmpHlsSupported = __converters.intToHlsSupport(_tmp_5)
          val _tmpPreferHls: Boolean
          val _tmp_6: Int
          _tmp_6 = _stmt.getLong(_columnIndexOfPreferHls).toInt()
          _tmpPreferHls = _tmp_6 != 0
          val _tmpLivePrerollSecs: Int
          _tmpLivePrerollSecs = _stmt.getLong(_columnIndexOfLivePrerollSecs).toInt()
          val _tmpLiveEnginePreference: String?
          if (_stmt.isNull(_columnIndexOfLiveEnginePreference)) {
            _tmpLiveEnginePreference = null
          } else {
            _tmpLiveEnginePreference = _stmt.getText(_columnIndexOfLiveEnginePreference)
          }
          val _tmpLiveLatencyMode: String?
          if (_stmt.isNull(_columnIndexOfLiveLatencyMode)) {
            _tmpLiveLatencyMode = null
          } else {
            _tmpLiveLatencyMode = _stmt.getText(_columnIndexOfLiveLatencyMode)
          }
          val _tmpLiveLatencyCustomSecs: Int
          _tmpLiveLatencyCustomSecs = _stmt.getLong(_columnIndexOfLiveLatencyCustomSecs).toInt()
          val _tmpMaxConnections: Int
          _tmpMaxConnections = _stmt.getLong(_columnIndexOfMaxConnections).toInt()
          val _tmpMaxConnectionsProbedAt: Long
          _tmpMaxConnectionsProbedAt = _stmt.getLong(_columnIndexOfMaxConnectionsProbedAt)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpLastSyncAt: Long?
          if (_stmt.isNull(_columnIndexOfLastSyncAt)) {
            _tmpLastSyncAt = null
          } else {
            _tmpLastSyncAt = _stmt.getLong(_columnIndexOfLastSyncAt)
          }
          _item = SourceEntity(_tmpId,_tmpName,_tmpType,_tmpUrl,_tmpUsername,_tmpPassword,_tmpMac,_tmpStalkerSerialNumber,_tmpStalkerDeviceId,_tmpStalkerDeviceId2,_tmpStalkerSignature,_tmpUserAgent,_tmpEpgUrl,_tmpSyncLive,_tmpSyncMovies,_tmpSyncSeries,_tmpImportPortalEpg,_tmpHlsSupported,_tmpPreferHls,_tmpLivePrerollSecs,_tmpLiveEnginePreference,_tmpLiveLatencyMode,_tmpLiveLatencyCustomSecs,_tmpMaxConnections,_tmpMaxConnectionsProbedAt,_tmpCreatedAt,_tmpLastSyncAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun sourceIdsForProfile(profileId: Long): List<Long> {
    val _sql: String = "SELECT sourceId FROM profile_source WHERE profileId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun profileIdsForSource(sourceId: Long): List<Long> {
    val _sql: String = "SELECT profileId FROM profile_source WHERE sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allSourceIds(): List<Long> {
    val _sql: String = "SELECT id FROM sources"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<SourceEntity> {
    val _sql: String = "SELECT * FROM sources ORDER BY createdAt ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfUsername: Int = getColumnIndexOrThrow(_stmt, "username")
        val _columnIndexOfPassword: Int = getColumnIndexOrThrow(_stmt, "password")
        val _columnIndexOfMac: Int = getColumnIndexOrThrow(_stmt, "mac")
        val _columnIndexOfStalkerSerialNumber: Int = getColumnIndexOrThrow(_stmt, "stalkerSerialNumber")
        val _columnIndexOfStalkerDeviceId: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId")
        val _columnIndexOfStalkerDeviceId2: Int = getColumnIndexOrThrow(_stmt, "stalkerDeviceId2")
        val _columnIndexOfStalkerSignature: Int = getColumnIndexOrThrow(_stmt, "stalkerSignature")
        val _columnIndexOfUserAgent: Int = getColumnIndexOrThrow(_stmt, "userAgent")
        val _columnIndexOfEpgUrl: Int = getColumnIndexOrThrow(_stmt, "epgUrl")
        val _columnIndexOfSyncLive: Int = getColumnIndexOrThrow(_stmt, "syncLive")
        val _columnIndexOfSyncMovies: Int = getColumnIndexOrThrow(_stmt, "syncMovies")
        val _columnIndexOfSyncSeries: Int = getColumnIndexOrThrow(_stmt, "syncSeries")
        val _columnIndexOfImportPortalEpg: Int = getColumnIndexOrThrow(_stmt, "importPortalEpg")
        val _columnIndexOfHlsSupported: Int = getColumnIndexOrThrow(_stmt, "hlsSupported")
        val _columnIndexOfPreferHls: Int = getColumnIndexOrThrow(_stmt, "preferHls")
        val _columnIndexOfLivePrerollSecs: Int = getColumnIndexOrThrow(_stmt, "livePrerollSecs")
        val _columnIndexOfLiveEnginePreference: Int = getColumnIndexOrThrow(_stmt, "liveEnginePreference")
        val _columnIndexOfLiveLatencyMode: Int = getColumnIndexOrThrow(_stmt, "liveLatencyMode")
        val _columnIndexOfLiveLatencyCustomSecs: Int = getColumnIndexOrThrow(_stmt, "liveLatencyCustomSecs")
        val _columnIndexOfMaxConnections: Int = getColumnIndexOrThrow(_stmt, "maxConnections")
        val _columnIndexOfMaxConnectionsProbedAt: Int = getColumnIndexOrThrow(_stmt, "maxConnectionsProbedAt")
        val _columnIndexOfCreatedAt: Int = getColumnIndexOrThrow(_stmt, "createdAt")
        val _columnIndexOfLastSyncAt: Int = getColumnIndexOrThrow(_stmt, "lastSyncAt")
        val _result: MutableList<SourceEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: SourceType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfType)
          _tmpType = __converters.stringToSourceType(_tmp)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpUsername: String?
          if (_stmt.isNull(_columnIndexOfUsername)) {
            _tmpUsername = null
          } else {
            _tmpUsername = _stmt.getText(_columnIndexOfUsername)
          }
          val _tmpPassword: String?
          if (_stmt.isNull(_columnIndexOfPassword)) {
            _tmpPassword = null
          } else {
            _tmpPassword = _stmt.getText(_columnIndexOfPassword)
          }
          val _tmpMac: String?
          if (_stmt.isNull(_columnIndexOfMac)) {
            _tmpMac = null
          } else {
            _tmpMac = _stmt.getText(_columnIndexOfMac)
          }
          val _tmpStalkerSerialNumber: String?
          if (_stmt.isNull(_columnIndexOfStalkerSerialNumber)) {
            _tmpStalkerSerialNumber = null
          } else {
            _tmpStalkerSerialNumber = _stmt.getText(_columnIndexOfStalkerSerialNumber)
          }
          val _tmpStalkerDeviceId: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId)) {
            _tmpStalkerDeviceId = null
          } else {
            _tmpStalkerDeviceId = _stmt.getText(_columnIndexOfStalkerDeviceId)
          }
          val _tmpStalkerDeviceId2: String?
          if (_stmt.isNull(_columnIndexOfStalkerDeviceId2)) {
            _tmpStalkerDeviceId2 = null
          } else {
            _tmpStalkerDeviceId2 = _stmt.getText(_columnIndexOfStalkerDeviceId2)
          }
          val _tmpStalkerSignature: String?
          if (_stmt.isNull(_columnIndexOfStalkerSignature)) {
            _tmpStalkerSignature = null
          } else {
            _tmpStalkerSignature = _stmt.getText(_columnIndexOfStalkerSignature)
          }
          val _tmpUserAgent: String?
          if (_stmt.isNull(_columnIndexOfUserAgent)) {
            _tmpUserAgent = null
          } else {
            _tmpUserAgent = _stmt.getText(_columnIndexOfUserAgent)
          }
          val _tmpEpgUrl: String?
          if (_stmt.isNull(_columnIndexOfEpgUrl)) {
            _tmpEpgUrl = null
          } else {
            _tmpEpgUrl = _stmt.getText(_columnIndexOfEpgUrl)
          }
          val _tmpSyncLive: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfSyncLive).toInt()
          _tmpSyncLive = _tmp_1 != 0
          val _tmpSyncMovies: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfSyncMovies).toInt()
          _tmpSyncMovies = _tmp_2 != 0
          val _tmpSyncSeries: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfSyncSeries).toInt()
          _tmpSyncSeries = _tmp_3 != 0
          val _tmpImportPortalEpg: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfImportPortalEpg).toInt()
          _tmpImportPortalEpg = _tmp_4 != 0
          val _tmpHlsSupported: HlsSupport
          val _tmp_5: Int
          _tmp_5 = _stmt.getLong(_columnIndexOfHlsSupported).toInt()
          _tmpHlsSupported = __converters.intToHlsSupport(_tmp_5)
          val _tmpPreferHls: Boolean
          val _tmp_6: Int
          _tmp_6 = _stmt.getLong(_columnIndexOfPreferHls).toInt()
          _tmpPreferHls = _tmp_6 != 0
          val _tmpLivePrerollSecs: Int
          _tmpLivePrerollSecs = _stmt.getLong(_columnIndexOfLivePrerollSecs).toInt()
          val _tmpLiveEnginePreference: String?
          if (_stmt.isNull(_columnIndexOfLiveEnginePreference)) {
            _tmpLiveEnginePreference = null
          } else {
            _tmpLiveEnginePreference = _stmt.getText(_columnIndexOfLiveEnginePreference)
          }
          val _tmpLiveLatencyMode: String?
          if (_stmt.isNull(_columnIndexOfLiveLatencyMode)) {
            _tmpLiveLatencyMode = null
          } else {
            _tmpLiveLatencyMode = _stmt.getText(_columnIndexOfLiveLatencyMode)
          }
          val _tmpLiveLatencyCustomSecs: Int
          _tmpLiveLatencyCustomSecs = _stmt.getLong(_columnIndexOfLiveLatencyCustomSecs).toInt()
          val _tmpMaxConnections: Int
          _tmpMaxConnections = _stmt.getLong(_columnIndexOfMaxConnections).toInt()
          val _tmpMaxConnectionsProbedAt: Long
          _tmpMaxConnectionsProbedAt = _stmt.getLong(_columnIndexOfMaxConnectionsProbedAt)
          val _tmpCreatedAt: Long
          _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt)
          val _tmpLastSyncAt: Long?
          if (_stmt.isNull(_columnIndexOfLastSyncAt)) {
            _tmpLastSyncAt = null
          } else {
            _tmpLastSyncAt = _stmt.getLong(_columnIndexOfLastSyncAt)
          }
          _item = SourceEntity(_tmpId,_tmpName,_tmpType,_tmpUrl,_tmpUsername,_tmpPassword,_tmpMac,_tmpStalkerSerialNumber,_tmpStalkerDeviceId,_tmpStalkerDeviceId2,_tmpStalkerSignature,_tmpUserAgent,_tmpEpgUrl,_tmpSyncLive,_tmpSyncMovies,_tmpSyncSeries,_tmpImportPortalEpg,_tmpHlsSupported,_tmpPreferHls,_tmpLivePrerollSecs,_tmpLiveEnginePreference,_tmpLiveLatencyMode,_tmpLiveLatencyCustomSecs,_tmpMaxConnections,_tmpMaxConnectionsProbedAt,_tmpCreatedAt,_tmpLastSyncAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allLinks(): List<ProfileSourceCrossRef> {
    val _sql: String = "SELECT * FROM profile_source"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _result: MutableList<ProfileSourceCrossRef> = mutableListOf()
        while (_stmt.step()) {
          val _item: ProfileSourceCrossRef
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          _item = ProfileSourceCrossRef(_tmpProfileId,_tmpSourceId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun markSynced(id: Long, timestamp: Long) {
    val _sql: String = "UPDATE sources SET lastSyncAt = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, timestamp)
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateHlsSupport(id: Long, hlsSupported: HlsSupport) {
    val _sql: String = "UPDATE sources SET hlsSupported = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = __converters.hlsSupportToInt(hlsSupported)
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateHlsSupportFromSync(id: Long, hlsSupported: HlsSupport) {
    val _sql: String = "UPDATE sources SET hlsSupported = ? WHERE id = ? AND (? = 1 OR hlsSupported != 1)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = __converters.hlsSupportToInt(hlsSupported)
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _argIndex = 3
        val _tmp_1: Int = __converters.hlsSupportToInt(hlsSupported)
        _stmt.bindLong(_argIndex, _tmp_1.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateMaxConnections(id: Long, maxConnections: Int) {
    val _sql: String = "UPDATE sources SET maxConnections = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, maxConnections.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateProbedConnections(
    id: Long,
    maxConnections: Int,
    probedAt: Long,
  ) {
    val _sql: String = "UPDATE sources SET maxConnections = ?, maxConnectionsProbedAt = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, maxConnections.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, probedAt)
        _argIndex = 3
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updatePreferHls(id: Long, preferHls: Boolean) {
    val _sql: String = "UPDATE sources SET preferHls = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (preferHls) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateLivePreroll(id: Long, secs: Int) {
    val _sql: String = "UPDATE sources SET livePrerollSecs = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, secs.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateLiveEnginePreference(id: Long, preference: String?) {
    val _sql: String = "UPDATE sources SET liveEnginePreference = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (preference == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, preference)
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateLiveLatency(
    id: Long,
    mode: String?,
    customSecs: Int,
  ) {
    val _sql: String = "UPDATE sources SET liveLatencyMode = ?, liveLatencyCustomSecs = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (mode == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, mode)
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, customSecs.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun unlink(profileId: Long, sourceId: Long) {
    val _sql: String = "DELETE FROM profile_source WHERE profileId = ? AND sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAllSources() {
    val _sql: String = "DELETE FROM sources"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
