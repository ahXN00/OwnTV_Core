package tv.own.owntv.core.database.dao

import androidx.paging.PagingSource
import androidx.room.EntityDeleteOrUpdateAdapter
import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.RoomRawQuery
import androidx.room.coroutines.createFlow
import androidx.room.paging.LimitOffsetPagingSource
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.ContentHashProjection
import tv.own.owntv.core.database.entity.MovieEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MovieDao_Impl(
  __db: RoomDatabase,
) : MovieDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfMovieEntity: EntityInsertAdapter<MovieEntity>

  private val __insertAdapterOfMovieEntity_1: EntityInsertAdapter<MovieEntity>

  private val __updateAdapterOfMovieEntity: EntityDeleteOrUpdateAdapter<MovieEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfMovieEntity = object : EntityInsertAdapter<MovieEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `movies` (`id`,`sourceId`,`categoryId`,`name`,`posterUrl`,`backdropUrl`,`year`,`rating`,`durationSecs`,`plot`,`streamUrl`,`containerExt`,`remoteId`,`addedAt`,`sortOrder`,`httpHeaders`,`drmConfig`,`manifestType`,`contentHash`,`canonicalTitle`,`titleSignature`,`parsedYear`,`providerLanguage`,`qualityRank`,`advertisedCapabilities`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MovieEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpPosterUrl: String? = entity.posterUrl
        if (_tmpPosterUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpPosterUrl)
        }
        val _tmpBackdropUrl: String? = entity.backdropUrl
        if (_tmpBackdropUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpBackdropUrl)
        }
        val _tmpYear: Int? = entity.year
        if (_tmpYear == null) {
          statement.bindNull(7)
        } else {
          statement.bindLong(7, _tmpYear.toLong())
        }
        val _tmpRating: Double? = entity.rating
        if (_tmpRating == null) {
          statement.bindNull(8)
        } else {
          statement.bindDouble(8, _tmpRating)
        }
        val _tmpDurationSecs: Int? = entity.durationSecs
        if (_tmpDurationSecs == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpDurationSecs.toLong())
        }
        val _tmpPlot: String? = entity.plot
        if (_tmpPlot == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpPlot)
        }
        statement.bindText(11, entity.streamUrl)
        val _tmpContainerExt: String? = entity.containerExt
        if (_tmpContainerExt == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpContainerExt)
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpRemoteId)
        }
        val _tmpAddedAt: Long? = entity.addedAt
        if (_tmpAddedAt == null) {
          statement.bindNull(14)
        } else {
          statement.bindLong(14, _tmpAddedAt)
        }
        statement.bindLong(15, entity.sortOrder.toLong())
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpManifestType)
        }
        statement.bindLong(19, entity.contentHash.toLong())
        statement.bindText(20, entity.canonicalTitle)
        statement.bindText(21, entity.titleSignature)
        val _tmpParsedYear: Int? = entity.parsedYear
        if (_tmpParsedYear == null) {
          statement.bindNull(22)
        } else {
          statement.bindLong(22, _tmpParsedYear.toLong())
        }
        val _tmpProviderLanguage: String? = entity.providerLanguage
        if (_tmpProviderLanguage == null) {
          statement.bindNull(23)
        } else {
          statement.bindText(23, _tmpProviderLanguage)
        }
        statement.bindLong(24, entity.qualityRank.toLong())
        val _tmpAdvertisedCapabilities: String? = entity.advertisedCapabilities
        if (_tmpAdvertisedCapabilities == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpAdvertisedCapabilities)
        }
      }
    }
    this.__insertAdapterOfMovieEntity_1 = object : EntityInsertAdapter<MovieEntity>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `movies` (`id`,`sourceId`,`categoryId`,`name`,`posterUrl`,`backdropUrl`,`year`,`rating`,`durationSecs`,`plot`,`streamUrl`,`containerExt`,`remoteId`,`addedAt`,`sortOrder`,`httpHeaders`,`drmConfig`,`manifestType`,`contentHash`,`canonicalTitle`,`titleSignature`,`parsedYear`,`providerLanguage`,`qualityRank`,`advertisedCapabilities`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MovieEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpPosterUrl: String? = entity.posterUrl
        if (_tmpPosterUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpPosterUrl)
        }
        val _tmpBackdropUrl: String? = entity.backdropUrl
        if (_tmpBackdropUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpBackdropUrl)
        }
        val _tmpYear: Int? = entity.year
        if (_tmpYear == null) {
          statement.bindNull(7)
        } else {
          statement.bindLong(7, _tmpYear.toLong())
        }
        val _tmpRating: Double? = entity.rating
        if (_tmpRating == null) {
          statement.bindNull(8)
        } else {
          statement.bindDouble(8, _tmpRating)
        }
        val _tmpDurationSecs: Int? = entity.durationSecs
        if (_tmpDurationSecs == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpDurationSecs.toLong())
        }
        val _tmpPlot: String? = entity.plot
        if (_tmpPlot == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpPlot)
        }
        statement.bindText(11, entity.streamUrl)
        val _tmpContainerExt: String? = entity.containerExt
        if (_tmpContainerExt == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpContainerExt)
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpRemoteId)
        }
        val _tmpAddedAt: Long? = entity.addedAt
        if (_tmpAddedAt == null) {
          statement.bindNull(14)
        } else {
          statement.bindLong(14, _tmpAddedAt)
        }
        statement.bindLong(15, entity.sortOrder.toLong())
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpManifestType)
        }
        statement.bindLong(19, entity.contentHash.toLong())
        statement.bindText(20, entity.canonicalTitle)
        statement.bindText(21, entity.titleSignature)
        val _tmpParsedYear: Int? = entity.parsedYear
        if (_tmpParsedYear == null) {
          statement.bindNull(22)
        } else {
          statement.bindLong(22, _tmpParsedYear.toLong())
        }
        val _tmpProviderLanguage: String? = entity.providerLanguage
        if (_tmpProviderLanguage == null) {
          statement.bindNull(23)
        } else {
          statement.bindText(23, _tmpProviderLanguage)
        }
        statement.bindLong(24, entity.qualityRank.toLong())
        val _tmpAdvertisedCapabilities: String? = entity.advertisedCapabilities
        if (_tmpAdvertisedCapabilities == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpAdvertisedCapabilities)
        }
      }
    }
    this.__updateAdapterOfMovieEntity = object : EntityDeleteOrUpdateAdapter<MovieEntity>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `movies` SET `id` = ?,`sourceId` = ?,`categoryId` = ?,`name` = ?,`posterUrl` = ?,`backdropUrl` = ?,`year` = ?,`rating` = ?,`durationSecs` = ?,`plot` = ?,`streamUrl` = ?,`containerExt` = ?,`remoteId` = ?,`addedAt` = ?,`sortOrder` = ?,`httpHeaders` = ?,`drmConfig` = ?,`manifestType` = ?,`contentHash` = ?,`canonicalTitle` = ?,`titleSignature` = ?,`parsedYear` = ?,`providerLanguage` = ?,`qualityRank` = ?,`advertisedCapabilities` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: MovieEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        val _tmpCategoryId: Long? = entity.categoryId
        if (_tmpCategoryId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCategoryId)
        }
        statement.bindText(4, entity.name)
        val _tmpPosterUrl: String? = entity.posterUrl
        if (_tmpPosterUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpPosterUrl)
        }
        val _tmpBackdropUrl: String? = entity.backdropUrl
        if (_tmpBackdropUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpBackdropUrl)
        }
        val _tmpYear: Int? = entity.year
        if (_tmpYear == null) {
          statement.bindNull(7)
        } else {
          statement.bindLong(7, _tmpYear.toLong())
        }
        val _tmpRating: Double? = entity.rating
        if (_tmpRating == null) {
          statement.bindNull(8)
        } else {
          statement.bindDouble(8, _tmpRating)
        }
        val _tmpDurationSecs: Int? = entity.durationSecs
        if (_tmpDurationSecs == null) {
          statement.bindNull(9)
        } else {
          statement.bindLong(9, _tmpDurationSecs.toLong())
        }
        val _tmpPlot: String? = entity.plot
        if (_tmpPlot == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpPlot)
        }
        statement.bindText(11, entity.streamUrl)
        val _tmpContainerExt: String? = entity.containerExt
        if (_tmpContainerExt == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpContainerExt)
        }
        val _tmpRemoteId: String? = entity.remoteId
        if (_tmpRemoteId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpRemoteId)
        }
        val _tmpAddedAt: Long? = entity.addedAt
        if (_tmpAddedAt == null) {
          statement.bindNull(14)
        } else {
          statement.bindLong(14, _tmpAddedAt)
        }
        statement.bindLong(15, entity.sortOrder.toLong())
        val _tmpHttpHeaders: String? = entity.httpHeaders
        if (_tmpHttpHeaders == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpHttpHeaders)
        }
        val _tmpDrmConfig: String? = entity.drmConfig
        if (_tmpDrmConfig == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpDrmConfig)
        }
        val _tmpManifestType: String? = entity.manifestType
        if (_tmpManifestType == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpManifestType)
        }
        statement.bindLong(19, entity.contentHash.toLong())
        statement.bindText(20, entity.canonicalTitle)
        statement.bindText(21, entity.titleSignature)
        val _tmpParsedYear: Int? = entity.parsedYear
        if (_tmpParsedYear == null) {
          statement.bindNull(22)
        } else {
          statement.bindLong(22, _tmpParsedYear.toLong())
        }
        val _tmpProviderLanguage: String? = entity.providerLanguage
        if (_tmpProviderLanguage == null) {
          statement.bindNull(23)
        } else {
          statement.bindText(23, _tmpProviderLanguage)
        }
        statement.bindLong(24, entity.qualityRank.toLong())
        val _tmpAdvertisedCapabilities: String? = entity.advertisedCapabilities
        if (_tmpAdvertisedCapabilities == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpAdvertisedCapabilities)
        }
        statement.bindLong(26, entity.id)
      }
    }
  }

  public override suspend fun upsertAllNormalized(movies: List<MovieEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfMovieEntity.insert(_connection, movies)
  }

  public override suspend fun insertAllNormalized(movies: List<MovieEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfMovieEntity_1.insert(_connection, movies)
  }

  public override suspend fun updateAllNormalized(movies: List<MovieEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfMovieEntity.handleMultiple(_connection, movies)
  }

  public override suspend fun applyPositionMoves(ids: List<Long>, sortOrders: List<Int>): Unit = performInTransactionSuspending(__db) {
    super@MovieDao_Impl.applyPositionMoves(ids, sortOrders)
  }

  public override suspend fun applyPositionRanges(
    sourceId: Long,
    froms: List<Int>,
    tos: List<Int>,
    deltas: List<Int>,
  ): Unit = performInTransactionSuspending(__db) {
    super@MovieDao_Impl.applyPositionRanges(sourceId, froms, tos, deltas)
  }

  public override suspend fun getById(id: Long): MovieEntity? {
    val _sql: String = "SELECT * FROM movies WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MovieEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _result = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getByIds(ids: List<Long>): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE id IN (")
    val _inputSize: Int = ids.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in ids) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByRemote(sourceId: Long, remoteId: String): MovieEntity? {
    val _sql: String = "SELECT * FROM movies WHERE sourceId = ? AND remoteId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, remoteId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MovieEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _result = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByRemoteIds(sourceId: Long, remoteIds: List<String>): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND remoteId IN (")
    val _inputSize: Int = remoteIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in remoteIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remoteIdsForSource(sourceId: Long): List<String> {
    val _sql: String = "SELECT remoteId FROM movies WHERE sourceId = ? AND remoteId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun contentHashesForSource(sourceId: Long): List<ContentHashProjection> {
    val _sql: String = "SELECT remoteId, id, contentHash, sortOrder FROM movies WHERE sourceId = ? AND remoteId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfRemoteId: Int = 0
        val _columnIndexOfId: Int = 1
        val _columnIndexOfContentHash: Int = 2
        val _columnIndexOfSortOrder: Int = 3
        val _result: MutableList<ContentHashProjection> = mutableListOf()
        while (_stmt.step()) {
          val _item: ContentHashProjection
          val _tmpRemoteId: String
          _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          _item = ContentHashProjection(_tmpRemoteId,_tmpId,_tmpContentHash,_tmpSortOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countsByCategoryOnce(sourceId: Long): List<CategoryItemCount> {
    val _sql: String = "SELECT categoryId, COUNT(*) AS itemCount FROM movies WHERE sourceId = ? AND categoryId IS NOT NULL GROUP BY categoryId"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfCategoryId: Int = 0
        val _columnIndexOfItemCount: Int = 1
        val _result: MutableList<CategoryItemCount> = mutableListOf()
        while (_stmt.step()) {
          val _item: CategoryItemCount
          val _tmpCategoryId: Long
          _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          val _tmpItemCount: Int
          _tmpItemCount = _stmt.getLong(_columnIndexOfItemCount).toInt()
          _item = CategoryItemCount(_tmpCategoryId,_tmpItemCount)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remoteIdsForCategory(sourceId: Long, categoryId: Long): List<String> {
    val _sql: String = "SELECT remoteId FROM movies WHERE sourceId = ? AND categoryId = ? AND remoteId IS NOT NULL"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, categoryId)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remoteIdsInCategories(sourceId: Long, categoryIds: List<Long>): List<String> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT remoteId FROM movies WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND categoryId IN (")
    val _inputSize: Int = categoryIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND remoteId IS NOT NULL")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: Long in categoryIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: String
          _item_1 = _stmt.getText(0)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByName(sourceId: Long, name: String): MovieEntity? {
    val _sql: String = "SELECT * FROM movies WHERE sourceId = ? AND name = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, name)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MovieEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _result = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pagingByCategory(categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? ORDER BY sortOrder ASC, name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryAlpha(categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? ORDER BY name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAll(sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAllOriginal(sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sourceId ASC, sortOrder ASC, name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAllRating(sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY rating DESC, name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryRating(categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? ORDER BY rating DESC, name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingAllDateAdded(sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY addedAt DESC, sortOrder DESC, id DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryDateAdded(categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? ORDER BY addedAt DESC, sortOrder DESC, id DESC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchAllDateAdded(query: String, sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY addedAt DESC, sortOrder DESC, id DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchInCategoryDateAdded(query: String, categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? AND name LIKE '%' || ? || '%' ORDER BY addedAt DESC, sortOrder DESC, id DESC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
      _argIndex = 2
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryManual(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
  ): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT m.* FROM movies m LEFT JOIN content_order o ON o.itemId = m.id AND o.profileId = ? AND o.mediaType = 'MOVIE' AND o.contextKey = ? WHERE m.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.sortOrder, m.name"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingByCategoryManualAlpha(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
  ): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT m.* FROM movies m LEFT JOIN content_order o ON o.itemId = m.id AND o.profileId = ? AND o.mediaType = 'MOVIE' AND o.contextKey = ? WHERE m.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.name"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, categoryId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingFavoritesManual(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN favorites f ON f.itemId = m.id AND f.mediaType = 'MOVIE' LEFT JOIN content_order o ON o.itemId = m.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'MOVIE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, f.addedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      _stmt.bindText(_argIndex, contextKey)
      _argIndex = 3
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 4
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "favorites", "content_order") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override suspend fun snapshotByCategoryManual(
    categoryId: Long,
    profileId: Long,
    contextKey: String,
    limit: Int,
  ): List<MovieEntity> {
    val _sql: String = "SELECT m.* FROM movies m LEFT JOIN content_order o ON o.itemId = m.id AND o.profileId = ? AND o.mediaType = 'MOVIE' AND o.contextKey = ? WHERE m.categoryId = ? ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, m.sortOrder, m.name LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, categoryId)
        _argIndex = 4
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun snapshotFavoritesManual(
    profileId: Long,
    contextKey: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN favorites f ON f.itemId = m.id AND f.mediaType = 'MOVIE' LEFT JOIN content_order o ON o.itemId = m.id AND o.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND o.mediaType = 'MOVIE' AND o.contextKey = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY (CASE WHEN o.position IS NULL THEN 1 ELSE 0 END), o.position, f.addedAt DESC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 3
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 4
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 4 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countByCategory(categoryId: Long): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM movies WHERE categoryId = ?"
    return createFlow(__db, false, arrayOf("movies")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, categoryId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countAll(sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("movies")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countAllExcluding(sourceIds: List<Long>, excludedCategoryIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND (categoryId IS NULL OR categoryId NOT IN (")
    val _inputSize_1: Int = excludedCategoryIds.size
    appendPlaceholders(_stringBuilder, _inputSize_1)
    _stringBuilder.append("))")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("movies")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        for (_item_1: Long in excludedCategoryIds) {
          _stmt.bindLong(_argIndex, _item_1)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countForSourceOnce(sourceId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM movies WHERE sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun trendingMetadataBackfill(sourceId: Long, limit: Int): List<MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE sourceId = ? AND titleSignature = '' LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun trendingMetadataBackfillCount(sourceId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM movies WHERE sourceId = ? AND titleSignature = ''"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun trendingExact(sourceId: Long, titleSignatures: List<String>): List<TrendingCatalogRow> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT id, sourceId, categoryId, name, year, remoteId, sortOrder, canonicalTitle, titleSignature, parsedYear, providerLanguage, qualityRank, advertisedCapabilities FROM movies WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND titleSignature IN (")
    val _inputSize: Int = titleSignatures.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY sortOrder ASC, name ASC, id ASC")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in titleSignatures) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfId: Int = 0
        val _columnIndexOfSourceId: Int = 1
        val _columnIndexOfCategoryId: Int = 2
        val _columnIndexOfName: Int = 3
        val _columnIndexOfYear: Int = 4
        val _columnIndexOfRemoteId: Int = 5
        val _columnIndexOfSortOrder: Int = 6
        val _columnIndexOfCanonicalTitle: Int = 7
        val _columnIndexOfTitleSignature: Int = 8
        val _columnIndexOfParsedYear: Int = 9
        val _columnIndexOfProviderLanguage: Int = 10
        val _columnIndexOfQualityRank: Int = 11
        val _columnIndexOfAdvertisedCapabilities: Int = 12
        val _result: MutableList<TrendingCatalogRow> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: TrendingCatalogRow
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = TrendingCatalogRow(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpYear,_tmpRemoteId,_tmpSortOrder,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun trendingFts(
    sourceId: Long,
    ftsQuery: String,
    limit: Int,
  ): List<TrendingCatalogRow> {
    val _sql: String = "SELECT id, sourceId, categoryId, name, year, remoteId, sortOrder, canonicalTitle, titleSignature, parsedYear, providerLanguage, qualityRank, advertisedCapabilities FROM movies WHERE sourceId = ? AND id IN (SELECT rowid FROM movies_fts WHERE movies_fts MATCH ?) ORDER BY sortOrder ASC, name ASC, id ASC LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, ftsQuery)
        _argIndex = 3
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = 0
        val _columnIndexOfSourceId: Int = 1
        val _columnIndexOfCategoryId: Int = 2
        val _columnIndexOfName: Int = 3
        val _columnIndexOfYear: Int = 4
        val _columnIndexOfRemoteId: Int = 5
        val _columnIndexOfSortOrder: Int = 6
        val _columnIndexOfCanonicalTitle: Int = 7
        val _columnIndexOfTitleSignature: Int = 8
        val _columnIndexOfParsedYear: Int = 9
        val _columnIndexOfProviderLanguage: Int = 10
        val _columnIndexOfQualityRank: Int = 11
        val _columnIndexOfAdvertisedCapabilities: Int = 12
        val _result: MutableList<TrendingCatalogRow> = mutableListOf()
        while (_stmt.step()) {
          val _item: TrendingCatalogRow
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item = TrendingCatalogRow(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpYear,_tmpRemoteId,_tmpSortOrder,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun search(query: String, sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND id IN (SELECT rowid FROM movies_fts WHERE movies_fts MATCH ")
    _stringBuilder.append("?")
    _stringBuilder.append(") ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "movies_fts") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchAll(query: String, sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY name ASC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 1 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchInCategory(query: String, categoryId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT * FROM movies WHERE categoryId = ? AND name LIKE '%' || ? || '%' ORDER BY sortOrder ASC, name ASC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, categoryId)
      _argIndex = 2
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override suspend fun searchList(
    query: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, query)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun searchListFts(
    ftsQuery: String,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM movies WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND id IN (SELECT rowid FROM movies_fts WHERE movies_fts MATCH ")
    _stringBuilder.append("?")
    _stringBuilder.append(") ORDER BY name ASC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindText(_argIndex, ftsQuery)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun searchFavorites(
    query: String,
    profileId: Long,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN favorites f ON f.itemId = m.id AND f.mediaType = 'MOVIE' WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND m.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY f.addedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 2 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "favorites") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun searchHistory(
    query: String,
    profileId: Long,
    sourceIds: List<Long>,
  ): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN watch_history h ON h.itemId = m.id AND h.mediaType = 'MOVIE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND m.name LIKE '%' || ")
    _stringBuilder.append("?")
    _stringBuilder.append(" || '%' ORDER BY h.watchedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
      _argIndex = 2 + _inputSize
      _stmt.bindText(_argIndex, query)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "watch_history") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun pagingFavorites(profileId: Long): PagingSource<Int, MovieEntity> {
    val _sql: String = "SELECT m.* FROM movies m INNER JOIN favorites f ON f.itemId = m.id AND f.mediaType = 'MOVIE' WHERE f.profileId = ? ORDER BY f.addedAt DESC"
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "favorites") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun countFavorites(profileId: Long, sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM favorites f INNER JOIN movies m ON m.id = f.itemId WHERE f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND f.mediaType = 'MOVIE' AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("favorites", "movies")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countHistory(profileId: Long, sourceIds: List<Long>): Flow<Int> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM watch_history h INNER JOIN movies m ON m.id = h.itemId WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND h.mediaType = 'MOVIE' AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("watch_history", "movies")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun pagingHistory(profileId: Long, sourceIds: List<Long>): PagingSource<Int, MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN watch_history h ON h.itemId = m.id AND h.mediaType = 'MOVIE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY h.watchedAt DESC")
    val _sql: String = _stringBuilder.toString()
    val _rawQuery: RoomRawQuery = RoomRawQuery(_sql) { _stmt ->
      var _argIndex: Int = 1
      _stmt.bindLong(_argIndex, profileId)
      _argIndex = 2
      for (_item: Long in sourceIds) {
        _stmt.bindLong(_argIndex, _item)
        _argIndex++
      }
    }
    return object : LimitOffsetPagingSource<MovieEntity>(_rawQuery, __db, "movies", "watch_history") {
      protected override suspend fun convertRows(limitOffsetQuery: RoomRawQuery, itemCount: Int): List<MovieEntity> = performSuspending(__db, true, false) { _connection ->
        val _stmt: SQLiteStatement = _connection.prepare(limitOffsetQuery.sql)
        limitOffsetQuery.getBindingFunction().invoke(_stmt)
        try {
          val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
          val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
          val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
          val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
          val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
          val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
          val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
          val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
          val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
          val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
          val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
          val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
          val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
          val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
          val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
          val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
          val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
          val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
          val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
          val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
          val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
          val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
          val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
          val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
          val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
          val _result: MutableList<MovieEntity> = mutableListOf()
          while (_stmt.step()) {
            val _item_1: MovieEntity
            val _tmpId: Long
            _tmpId = _stmt.getLong(_columnIndexOfId)
            val _tmpSourceId: Long
            _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
            val _tmpCategoryId: Long?
            if (_stmt.isNull(_columnIndexOfCategoryId)) {
              _tmpCategoryId = null
            } else {
              _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
            }
            val _tmpName: String
            _tmpName = _stmt.getText(_columnIndexOfName)
            val _tmpPosterUrl: String?
            if (_stmt.isNull(_columnIndexOfPosterUrl)) {
              _tmpPosterUrl = null
            } else {
              _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
            }
            val _tmpBackdropUrl: String?
            if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
              _tmpBackdropUrl = null
            } else {
              _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
            }
            val _tmpYear: Int?
            if (_stmt.isNull(_columnIndexOfYear)) {
              _tmpYear = null
            } else {
              _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
            }
            val _tmpRating: Double?
            if (_stmt.isNull(_columnIndexOfRating)) {
              _tmpRating = null
            } else {
              _tmpRating = _stmt.getDouble(_columnIndexOfRating)
            }
            val _tmpDurationSecs: Int?
            if (_stmt.isNull(_columnIndexOfDurationSecs)) {
              _tmpDurationSecs = null
            } else {
              _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
            }
            val _tmpPlot: String?
            if (_stmt.isNull(_columnIndexOfPlot)) {
              _tmpPlot = null
            } else {
              _tmpPlot = _stmt.getText(_columnIndexOfPlot)
            }
            val _tmpStreamUrl: String
            _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
            val _tmpContainerExt: String?
            if (_stmt.isNull(_columnIndexOfContainerExt)) {
              _tmpContainerExt = null
            } else {
              _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
            }
            val _tmpRemoteId: String?
            if (_stmt.isNull(_columnIndexOfRemoteId)) {
              _tmpRemoteId = null
            } else {
              _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
            }
            val _tmpAddedAt: Long?
            if (_stmt.isNull(_columnIndexOfAddedAt)) {
              _tmpAddedAt = null
            } else {
              _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
            }
            val _tmpSortOrder: Int
            _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
            val _tmpHttpHeaders: String?
            if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
              _tmpHttpHeaders = null
            } else {
              _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
            }
            val _tmpDrmConfig: String?
            if (_stmt.isNull(_columnIndexOfDrmConfig)) {
              _tmpDrmConfig = null
            } else {
              _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
            }
            val _tmpManifestType: String?
            if (_stmt.isNull(_columnIndexOfManifestType)) {
              _tmpManifestType = null
            } else {
              _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
            }
            val _tmpContentHash: Int
            _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
            val _tmpCanonicalTitle: String
            _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
            val _tmpTitleSignature: String
            _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
            val _tmpParsedYear: Int?
            if (_stmt.isNull(_columnIndexOfParsedYear)) {
              _tmpParsedYear = null
            } else {
              _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
            }
            val _tmpProviderLanguage: String?
            if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
              _tmpProviderLanguage = null
            } else {
              _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
            }
            val _tmpQualityRank: Int
            _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
            val _tmpAdvertisedCapabilities: String?
            if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
              _tmpAdvertisedCapabilities = null
            } else {
              _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
            }
            _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
            _result.add(_item_1)
          }
          _result
        } finally {
          _stmt.close()
        }
      }
    }
  }

  public override fun recentlyWatched(profileId: Long, limit: Int): Flow<List<MovieEntity>> {
    val _sql: String = "SELECT m.* FROM movies m INNER JOIN watch_history h ON h.itemId = m.id AND h.mediaType = 'MOVIE' WHERE h.profileId = ? ORDER BY h.watchedAt DESC LIMIT ?"
    return createFlow(__db, false, arrayOf("movies", "watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun recentlyWatchedSnapshot(
    profileId: Long,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN watch_history h ON h.itemId = m.id AND h.mediaType = 'MOVIE' WHERE h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") ORDER BY h.watchedAt DESC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun unwatchedFavorites(
    profileId: Long,
    sourceIds: List<Long>,
    limit: Int,
  ): List<MovieEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT m.* FROM movies m INNER JOIN favorites f ON f.itemId = m.id AND f.mediaType = 'MOVIE' AND f.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" LEFT JOIN watch_history h ON h.itemId = m.id AND h.mediaType = 'MOVIE' AND h.profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" WHERE m.sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND h.itemId IS NULL ORDER BY f.addedAt DESC LIMIT ")
    _stringBuilder.append("?")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 3
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 3 + _inputSize
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfCategoryId: Int = getColumnIndexOrThrow(_stmt, "categoryId")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfPosterUrl: Int = getColumnIndexOrThrow(_stmt, "posterUrl")
        val _columnIndexOfBackdropUrl: Int = getColumnIndexOrThrow(_stmt, "backdropUrl")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfDurationSecs: Int = getColumnIndexOrThrow(_stmt, "durationSecs")
        val _columnIndexOfPlot: Int = getColumnIndexOrThrow(_stmt, "plot")
        val _columnIndexOfStreamUrl: Int = getColumnIndexOrThrow(_stmt, "streamUrl")
        val _columnIndexOfContainerExt: Int = getColumnIndexOrThrow(_stmt, "containerExt")
        val _columnIndexOfRemoteId: Int = getColumnIndexOrThrow(_stmt, "remoteId")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfHttpHeaders: Int = getColumnIndexOrThrow(_stmt, "httpHeaders")
        val _columnIndexOfDrmConfig: Int = getColumnIndexOrThrow(_stmt, "drmConfig")
        val _columnIndexOfManifestType: Int = getColumnIndexOrThrow(_stmt, "manifestType")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _columnIndexOfCanonicalTitle: Int = getColumnIndexOrThrow(_stmt, "canonicalTitle")
        val _columnIndexOfTitleSignature: Int = getColumnIndexOrThrow(_stmt, "titleSignature")
        val _columnIndexOfParsedYear: Int = getColumnIndexOrThrow(_stmt, "parsedYear")
        val _columnIndexOfProviderLanguage: Int = getColumnIndexOrThrow(_stmt, "providerLanguage")
        val _columnIndexOfQualityRank: Int = getColumnIndexOrThrow(_stmt, "qualityRank")
        val _columnIndexOfAdvertisedCapabilities: Int = getColumnIndexOrThrow(_stmt, "advertisedCapabilities")
        val _result: MutableList<MovieEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MovieEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpCategoryId: Long?
          if (_stmt.isNull(_columnIndexOfCategoryId)) {
            _tmpCategoryId = null
          } else {
            _tmpCategoryId = _stmt.getLong(_columnIndexOfCategoryId)
          }
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpPosterUrl: String?
          if (_stmt.isNull(_columnIndexOfPosterUrl)) {
            _tmpPosterUrl = null
          } else {
            _tmpPosterUrl = _stmt.getText(_columnIndexOfPosterUrl)
          }
          val _tmpBackdropUrl: String?
          if (_stmt.isNull(_columnIndexOfBackdropUrl)) {
            _tmpBackdropUrl = null
          } else {
            _tmpBackdropUrl = _stmt.getText(_columnIndexOfBackdropUrl)
          }
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpDurationSecs: Int?
          if (_stmt.isNull(_columnIndexOfDurationSecs)) {
            _tmpDurationSecs = null
          } else {
            _tmpDurationSecs = _stmt.getLong(_columnIndexOfDurationSecs).toInt()
          }
          val _tmpPlot: String?
          if (_stmt.isNull(_columnIndexOfPlot)) {
            _tmpPlot = null
          } else {
            _tmpPlot = _stmt.getText(_columnIndexOfPlot)
          }
          val _tmpStreamUrl: String
          _tmpStreamUrl = _stmt.getText(_columnIndexOfStreamUrl)
          val _tmpContainerExt: String?
          if (_stmt.isNull(_columnIndexOfContainerExt)) {
            _tmpContainerExt = null
          } else {
            _tmpContainerExt = _stmt.getText(_columnIndexOfContainerExt)
          }
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpAddedAt: Long?
          if (_stmt.isNull(_columnIndexOfAddedAt)) {
            _tmpAddedAt = null
          } else {
            _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          }
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpHttpHeaders: String?
          if (_stmt.isNull(_columnIndexOfHttpHeaders)) {
            _tmpHttpHeaders = null
          } else {
            _tmpHttpHeaders = _stmt.getText(_columnIndexOfHttpHeaders)
          }
          val _tmpDrmConfig: String?
          if (_stmt.isNull(_columnIndexOfDrmConfig)) {
            _tmpDrmConfig = null
          } else {
            _tmpDrmConfig = _stmt.getText(_columnIndexOfDrmConfig)
          }
          val _tmpManifestType: String?
          if (_stmt.isNull(_columnIndexOfManifestType)) {
            _tmpManifestType = null
          } else {
            _tmpManifestType = _stmt.getText(_columnIndexOfManifestType)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          val _tmpCanonicalTitle: String
          _tmpCanonicalTitle = _stmt.getText(_columnIndexOfCanonicalTitle)
          val _tmpTitleSignature: String
          _tmpTitleSignature = _stmt.getText(_columnIndexOfTitleSignature)
          val _tmpParsedYear: Int?
          if (_stmt.isNull(_columnIndexOfParsedYear)) {
            _tmpParsedYear = null
          } else {
            _tmpParsedYear = _stmt.getLong(_columnIndexOfParsedYear).toInt()
          }
          val _tmpProviderLanguage: String?
          if (_stmt.isNull(_columnIndexOfProviderLanguage)) {
            _tmpProviderLanguage = null
          } else {
            _tmpProviderLanguage = _stmt.getText(_columnIndexOfProviderLanguage)
          }
          val _tmpQualityRank: Int
          _tmpQualityRank = _stmt.getLong(_columnIndexOfQualityRank).toInt()
          val _tmpAdvertisedCapabilities: String?
          if (_stmt.isNull(_columnIndexOfAdvertisedCapabilities)) {
            _tmpAdvertisedCapabilities = null
          } else {
            _tmpAdvertisedCapabilities = _stmt.getText(_columnIndexOfAdvertisedCapabilities)
          }
          _item_1 = MovieEntity(_tmpId,_tmpSourceId,_tmpCategoryId,_tmpName,_tmpPosterUrl,_tmpBackdropUrl,_tmpYear,_tmpRating,_tmpDurationSecs,_tmpPlot,_tmpStreamUrl,_tmpContainerExt,_tmpRemoteId,_tmpAddedAt,_tmpSortOrder,_tmpHttpHeaders,_tmpDrmConfig,_tmpManifestType,_tmpContentHash,_tmpCanonicalTitle,_tmpTitleSignature,_tmpParsedYear,_tmpProviderLanguage,_tmpQualityRank,_tmpAdvertisedCapabilities)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearSource(sourceId: Long) {
    val _sql: String = "DELETE FROM movies WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun setSortOrder(id: Long, sortOrder: Int) {
    val _sql: String = "UPDATE movies SET sortOrder = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sortOrder.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun shiftSortOrders(
    sourceId: Long,
    fromSortOrder: Int,
    toSortOrder: Int,
    delta: Int,
  ) {
    val _sql: String = "UPDATE movies SET sortOrder = sortOrder + ? WHERE sourceId = ? AND sortOrder BETWEEN ? AND ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, delta.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, fromSortOrder.toLong())
        _argIndex = 4
        _stmt.bindLong(_argIndex, toSortOrder.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteByRemoteIds(sourceId: Long, remoteIds: List<String>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM movies WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND remoteId IN (")
    val _inputSize: Int = remoteIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in remoteIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteNullRemoteIds(sourceId: Long) {
    val _sql: String = "DELETE FROM movies WHERE sourceId = ? AND remoteId IS NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
