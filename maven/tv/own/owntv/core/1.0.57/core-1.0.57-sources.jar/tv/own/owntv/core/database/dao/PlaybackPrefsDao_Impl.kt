package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.PlaybackPrefsEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class PlaybackPrefsDao_Impl(
  __db: RoomDatabase,
) : PlaybackPrefsDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfPlaybackPrefsEntity: EntityInsertAdapter<PlaybackPrefsEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfPlaybackPrefsEntity = object : EntityInsertAdapter<PlaybackPrefsEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `playback_prefs` (`profileId`,`contentKey`,`zoomMode`,`volumeBoost`,`audioDelayMs`,`updatedAt`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: PlaybackPrefsEntity) {
        statement.bindLong(1, entity.profileId)
        statement.bindText(2, entity.contentKey)
        val _tmpZoomMode: String? = entity.zoomMode
        if (_tmpZoomMode == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpZoomMode)
        }
        val _tmpVolumeBoost: Int? = entity.volumeBoost
        if (_tmpVolumeBoost == null) {
          statement.bindNull(4)
        } else {
          statement.bindLong(4, _tmpVolumeBoost.toLong())
        }
        val _tmpAudioDelayMs: Int? = entity.audioDelayMs
        if (_tmpAudioDelayMs == null) {
          statement.bindNull(5)
        } else {
          statement.bindLong(5, _tmpAudioDelayMs.toLong())
        }
        statement.bindLong(6, entity.updatedAt)
      }
    }
  }

  public override suspend fun upsert(row: PlaybackPrefsEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfPlaybackPrefsEntity.insert(_connection, row)
  }

  public override suspend fun insertAll(rows: List<PlaybackPrefsEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfPlaybackPrefsEntity.insert(_connection, rows)
  }

  public override suspend fun setZoom(
    profileId: Long,
    contentKey: String,
    zoomMode: String?,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.setZoom(profileId, contentKey, zoomMode)
  }

  public override suspend fun setVolume(
    profileId: Long,
    contentKey: String,
    volumeBoost: Int?,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.setVolume(profileId, contentKey, volumeBoost)
  }

  public override suspend fun setAudioDelay(
    profileId: Long,
    contentKey: String,
    audioDelayMs: Int?,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.setAudioDelay(profileId, contentKey, audioDelayMs)
  }

  public override suspend fun clearZoom(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.clearZoom()
  }

  public override suspend fun clearVolume(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.clearVolume()
  }

  public override suspend fun clearAudioDelay(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackPrefsDao_Impl.clearAudioDelay()
  }

  public override suspend fun `get`(profileId: Long, contentKey: String): PlaybackPrefsEntity? {
    val _sql: String = "SELECT * FROM playback_prefs WHERE profileId = ? AND contentKey = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfZoomMode: Int = getColumnIndexOrThrow(_stmt, "zoomMode")
        val _columnIndexOfVolumeBoost: Int = getColumnIndexOrThrow(_stmt, "volumeBoost")
        val _columnIndexOfAudioDelayMs: Int = getColumnIndexOrThrow(_stmt, "audioDelayMs")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: PlaybackPrefsEntity?
        if (_stmt.step()) {
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpZoomMode: String?
          if (_stmt.isNull(_columnIndexOfZoomMode)) {
            _tmpZoomMode = null
          } else {
            _tmpZoomMode = _stmt.getText(_columnIndexOfZoomMode)
          }
          val _tmpVolumeBoost: Int?
          if (_stmt.isNull(_columnIndexOfVolumeBoost)) {
            _tmpVolumeBoost = null
          } else {
            _tmpVolumeBoost = _stmt.getLong(_columnIndexOfVolumeBoost).toInt()
          }
          val _tmpAudioDelayMs: Int?
          if (_stmt.isNull(_columnIndexOfAudioDelayMs)) {
            _tmpAudioDelayMs = null
          } else {
            _tmpAudioDelayMs = _stmt.getLong(_columnIndexOfAudioDelayMs).toInt()
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = PlaybackPrefsEntity(_tmpProfileId,_tmpContentKey,_tmpZoomMode,_tmpVolumeBoost,_tmpAudioDelayMs,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<PlaybackPrefsEntity> {
    val _sql: String = "SELECT * FROM playback_prefs"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfZoomMode: Int = getColumnIndexOrThrow(_stmt, "zoomMode")
        val _columnIndexOfVolumeBoost: Int = getColumnIndexOrThrow(_stmt, "volumeBoost")
        val _columnIndexOfAudioDelayMs: Int = getColumnIndexOrThrow(_stmt, "audioDelayMs")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<PlaybackPrefsEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: PlaybackPrefsEntity
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpZoomMode: String?
          if (_stmt.isNull(_columnIndexOfZoomMode)) {
            _tmpZoomMode = null
          } else {
            _tmpZoomMode = _stmt.getText(_columnIndexOfZoomMode)
          }
          val _tmpVolumeBoost: Int?
          if (_stmt.isNull(_columnIndexOfVolumeBoost)) {
            _tmpVolumeBoost = null
          } else {
            _tmpVolumeBoost = _stmt.getLong(_columnIndexOfVolumeBoost).toInt()
          }
          val _tmpAudioDelayMs: Int?
          if (_stmt.isNull(_columnIndexOfAudioDelayMs)) {
            _tmpAudioDelayMs = null
          } else {
            _tmpAudioDelayMs = _stmt.getLong(_columnIndexOfAudioDelayMs).toInt()
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = PlaybackPrefsEntity(_tmpProfileId,_tmpContentKey,_tmpZoomMode,_tmpVolumeBoost,_tmpAudioDelayMs,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeZoomCount(): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM playback_prefs WHERE zoomMode IS NOT NULL"
    return createFlow(__db, false, arrayOf("playback_prefs")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeVolumeCount(): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM playback_prefs WHERE volumeBoost IS NOT NULL"
    return createFlow(__db, false, arrayOf("playback_prefs")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAudioDelayCount(): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM playback_prefs WHERE audioDelayMs IS NOT NULL"
    return createFlow(__db, false, arrayOf("playback_prefs")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearZoomColumn() {
    val _sql: String = "UPDATE playback_prefs SET zoomMode = NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearVolumeColumn() {
    val _sql: String = "UPDATE playback_prefs SET volumeBoost = NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearAudioDelayColumn() {
    val _sql: String = "UPDATE playback_prefs SET audioDelayMs = NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun dropEmptyRows() {
    val _sql: String = "DELETE FROM playback_prefs WHERE zoomMode IS NULL AND volumeBoost IS NULL AND audioDelayMs IS NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
