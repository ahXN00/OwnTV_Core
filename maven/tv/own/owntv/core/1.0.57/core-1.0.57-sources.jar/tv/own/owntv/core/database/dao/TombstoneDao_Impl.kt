package tv.own.owntv.core.database.dao

import androidx.room.RoomDatabase
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import tv.own.owntv.core.database.entity.UserDataTombstoneEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TombstoneDao_Impl(
  __db: RoomDatabase,
) : TombstoneDao {
  private val __db: RoomDatabase
  init {
    this.__db = __db
  }

  public override suspend fun deletedAt(
    profileId: Long,
    kind: String,
    identity: String,
  ): Long? {
    val _sql: String = "SELECT deletedAt FROM user_data_tombstones WHERE profileId = ? AND kind = ? AND identity = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, kind)
        _argIndex = 3
        _stmt.bindText(_argIndex, identity)
        val _result: Long?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getLong(0)
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<UserDataTombstoneEntity> {
    val _sql: String = "SELECT * FROM user_data_tombstones"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfIdentity: Int = getColumnIndexOrThrow(_stmt, "identity")
        val _columnIndexOfDeletedAt: Int = getColumnIndexOrThrow(_stmt, "deletedAt")
        val _result: MutableList<UserDataTombstoneEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: UserDataTombstoneEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpKind: String
          _tmpKind = _stmt.getText(_columnIndexOfKind)
          val _tmpIdentity: String
          _tmpIdentity = _stmt.getText(_columnIndexOfIdentity)
          val _tmpDeletedAt: Long
          _tmpDeletedAt = _stmt.getLong(_columnIndexOfDeletedAt)
          _item = UserDataTombstoneEntity(_tmpId,_tmpProfileId,_tmpKind,_tmpIdentity,_tmpDeletedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun count(): Int {
    val _sql: String = "SELECT COUNT(*) FROM user_data_tombstones"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun record(
    profileId: Long,
    kind: String,
    identity: String,
    deletedAt: Long,
  ) {
    val _sql: String = "INSERT INTO user_data_tombstones (profileId, kind, identity, deletedAt) VALUES (?, ?, ?, ?) ON CONFLICT(profileId, kind, identity) DO UPDATE SET deletedAt = MAX(deletedAt, ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, kind)
        _argIndex = 3
        _stmt.bindText(_argIndex, identity)
        _argIndex = 4
        _stmt.bindLong(_argIndex, deletedAt)
        _argIndex = 5
        _stmt.bindLong(_argIndex, deletedAt)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteForProfiles(profileIds: List<Long>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM user_data_tombstones WHERE profileId IN (")
    val _inputSize: Int = profileIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in profileIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun prune(keep: Int) {
    val _sql: String = "DELETE FROM user_data_tombstones WHERE id NOT IN (SELECT id FROM user_data_tombstones ORDER BY deletedAt DESC LIMIT ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, keep.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
