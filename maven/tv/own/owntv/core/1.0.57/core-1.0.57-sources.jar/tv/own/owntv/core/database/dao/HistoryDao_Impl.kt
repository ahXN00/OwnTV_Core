package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.WatchHistoryEntity
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class HistoryDao_Impl(
  __db: RoomDatabase,
) : HistoryDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfWatchHistoryEntity: EntityInsertAdapter<WatchHistoryEntity>

  private val __converters: Converters = Converters()

  private val __insertAdapterOfWatchHistoryEntity_1: EntityInsertAdapter<WatchHistoryEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfWatchHistoryEntity = object : EntityInsertAdapter<WatchHistoryEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `watch_history` (`id`,`profileId`,`mediaType`,`itemId`,`watchedAt`) VALUES (nullif(?, 0),?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: WatchHistoryEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(3, _tmp)
        statement.bindLong(4, entity.itemId)
        statement.bindLong(5, entity.watchedAt)
      }
    }
    this.__insertAdapterOfWatchHistoryEntity_1 = object : EntityInsertAdapter<WatchHistoryEntity>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `watch_history` (`id`,`profileId`,`mediaType`,`itemId`,`watchedAt`) VALUES (nullif(?, 0),?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: WatchHistoryEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(3, _tmp)
        statement.bindLong(4, entity.itemId)
        statement.bindLong(5, entity.watchedAt)
      }
    }
  }

  public override suspend fun record(entry: WatchHistoryEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfWatchHistoryEntity.insert(_connection, entry)
  }

  public override suspend fun insertIfAbsent(entry: WatchHistoryEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfWatchHistoryEntity_1.insert(_connection, entry)
  }

  public override suspend fun watchedAt(
    profileId: Long,
    type: MediaType,
    itemId: Long,
  ): Long? {
    val _sql: String = "SELECT watchedAt FROM watch_history WHERE profileId = ? AND mediaType = ? AND itemId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        val _result: Long?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getLong(0)
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exists(
    profileId: Long,
    type: MediaType,
    itemId: Long,
  ): Boolean {
    val _sql: String = "SELECT EXISTS(SELECT 1 FROM watch_history WHERE profileId = ? AND mediaType = ? AND itemId = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1 != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun count(profileId: Long, type: MediaType): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM watch_history WHERE profileId = ? AND mediaType = ?"
    return createFlow(__db, false, arrayOf("watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        val _result: Int
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeMostRecent(profileId: Long): Flow<WatchHistoryEntity?> {
    val _sql: String = "SELECT * FROM watch_history WHERE profileId = ? ORDER BY watchedAt DESC LIMIT 1"
    return createFlow(__db, false, arrayOf("watch_history")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: WatchHistoryEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          _result = WatchHistoryEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpWatchedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getForProfile(profileId: Long): List<WatchHistoryEntity> {
    val _sql: String = "SELECT * FROM watch_history WHERE profileId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: MutableList<WatchHistoryEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: WatchHistoryEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          _item = WatchHistoryEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpWatchedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getForProfileType(profileId: Long, type: MediaType): List<WatchHistoryEntity> {
    val _sql: String = "SELECT * FROM watch_history WHERE profileId = ? AND mediaType = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: MutableList<WatchHistoryEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: WatchHistoryEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          _item = WatchHistoryEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpWatchedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun episodeIdsInHistory(profileId: Long, seriesId: Long): List<Long> {
    val _sql: String = "SELECT itemId FROM watch_history WHERE profileId = ? AND mediaType = 'EPISODE' AND itemId IN (SELECT id FROM episodes WHERE seriesId = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<WatchHistoryEntity> {
    val _sql: String = "SELECT * FROM watch_history"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfWatchedAt: Int = getColumnIndexOrThrow(_stmt, "watchedAt")
        val _result: MutableList<WatchHistoryEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: WatchHistoryEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpWatchedAt: Long
          _tmpWatchedAt = _stmt.getLong(_columnIndexOfWatchedAt)
          _item = WatchHistoryEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpWatchedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exportRowsForSource(sourceId: Long): List<UserDataExportRow> {
    val _sql: String = "SELECT h.profileId AS profileId, h.mediaType AS mediaType, h.itemId AS itemId, COALESCE(c.sourceId, m.sourceId, s.sourceId, episodeSeries.sourceId) AS sourceId, COALESCE(c.remoteId, m.remoteId, s.remoteId, e.remoteId) AS remoteId, COALESCE(c.name, m.name, s.name) AS name, episodeSeries.remoteId AS seriesRemoteId, episodeSeries.name AS seriesName, e.seasonNumber AS seasonNumber, e.episodeNumber AS episodeNumber, h.watchedAt AS at, 0 AS positionMs, 0 AS durationMs FROM watch_history h LEFT JOIN channels c ON h.mediaType = 'LIVE' AND h.itemId = c.id LEFT JOIN movies m ON h.mediaType = 'MOVIE' AND h.itemId = m.id LEFT JOIN series s ON h.mediaType = 'SERIES' AND h.itemId = s.id LEFT JOIN episodes e ON h.mediaType = 'EPISODE' AND h.itemId = e.id LEFT JOIN series episodeSeries ON e.seriesId = episodeSeries.id WHERE c.sourceId = ? OR m.sourceId = ? OR s.sourceId = ? OR episodeSeries.sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 4
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfProfileId: Int = 0
        val _columnIndexOfMediaType: Int = 1
        val _columnIndexOfItemId: Int = 2
        val _columnIndexOfSourceId: Int = 3
        val _columnIndexOfRemoteId: Int = 4
        val _columnIndexOfName: Int = 5
        val _columnIndexOfSeriesRemoteId: Int = 6
        val _columnIndexOfSeriesName: Int = 7
        val _columnIndexOfSeasonNumber: Int = 8
        val _columnIndexOfEpisodeNumber: Int = 9
        val _columnIndexOfAt: Int = 10
        val _columnIndexOfPositionMs: Int = 11
        val _columnIndexOfDurationMs: Int = 12
        val _result: MutableList<UserDataExportRow> = mutableListOf()
        while (_stmt.step()) {
          val _item: UserDataExportRow
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          val _tmpSeriesRemoteId: String?
          if (_stmt.isNull(_columnIndexOfSeriesRemoteId)) {
            _tmpSeriesRemoteId = null
          } else {
            _tmpSeriesRemoteId = _stmt.getText(_columnIndexOfSeriesRemoteId)
          }
          val _tmpSeriesName: String?
          if (_stmt.isNull(_columnIndexOfSeriesName)) {
            _tmpSeriesName = null
          } else {
            _tmpSeriesName = _stmt.getText(_columnIndexOfSeriesName)
          }
          val _tmpSeasonNumber: Int?
          if (_stmt.isNull(_columnIndexOfSeasonNumber)) {
            _tmpSeasonNumber = null
          } else {
            _tmpSeasonNumber = _stmt.getLong(_columnIndexOfSeasonNumber).toInt()
          }
          val _tmpEpisodeNumber: Int?
          if (_stmt.isNull(_columnIndexOfEpisodeNumber)) {
            _tmpEpisodeNumber = null
          } else {
            _tmpEpisodeNumber = _stmt.getLong(_columnIndexOfEpisodeNumber).toInt()
          }
          val _tmpAt: Long
          _tmpAt = _stmt.getLong(_columnIndexOfAt)
          val _tmpPositionMs: Long
          _tmpPositionMs = _stmt.getLong(_columnIndexOfPositionMs)
          val _tmpDurationMs: Long
          _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs)
          _item = UserDataExportRow(_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpSourceId,_tmpRemoteId,_tmpName,_tmpSeriesRemoteId,_tmpSeriesName,_tmpSeasonNumber,_tmpEpisodeNumber,_tmpAt,_tmpPositionMs,_tmpDurationMs)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun bumpIfNewer(
    profileId: Long,
    type: MediaType,
    itemId: Long,
    at: Long,
  ) {
    val _sql: String = "UPDATE watch_history SET watchedAt = ? WHERE profileId = ? AND mediaType = ? AND itemId = ? AND watchedAt < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, at)
        _argIndex = 2
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 3
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 4
        _stmt.bindLong(_argIndex, itemId)
        _argIndex = 5
        _stmt.bindLong(_argIndex, at)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun remove(
    profileId: Long,
    type: MediaType,
    itemId: Long,
  ) {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ? AND mediaType = ? AND itemId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun removeIfOlderThan(
    profileId: Long,
    type: MediaType,
    itemId: Long,
    at: Long,
  ): Int {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ? AND mediaType = ? AND itemId = ? AND watchedAt <= ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        _argIndex = 4
        _stmt.bindLong(_argIndex, at)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun removeSeriesEpisodes(profileId: Long, seriesId: Long) {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ? AND mediaType = 'EPISODE' AND itemId IN (SELECT id FROM episodes WHERE seriesId = ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, seriesId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clear(profileId: Long) {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearType(profileId: Long, type: MediaType) {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ? AND mediaType = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeSnapshotOrphan(
    profileId: Long,
    type: MediaType,
    itemId: Long,
  ) {
    val _sql: String = "DELETE FROM watch_history WHERE profileId = ? AND mediaType = ? AND itemId = ? AND ((? = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (? = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (? = 'SERIES' AND itemId NOT IN (SELECT id FROM series))  OR (? = 'EPISODE' AND itemId NOT IN (SELECT id FROM episodes)))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindLong(_argIndex, itemId)
        _argIndex = 4
        val _tmp_1: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 5
        val _tmp_2: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_2)
        _argIndex = 6
        val _tmp_3: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_3)
        _argIndex = 7
        val _tmp_4: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_4)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeOrphans() {
    val _sql: String = "DELETE FROM watch_history WHERE (mediaType = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (mediaType = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (mediaType = 'SERIES' AND itemId NOT IN (SELECT id FROM series))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
