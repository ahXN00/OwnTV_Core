package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.TvProviderProgramEntity
import tv.own.owntv.core.model.MediaType
import tv.own.owntv.core.tv.TvProviderSurface

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class TvProviderProgramDao_Impl(
  __db: RoomDatabase,
) : TvProviderProgramDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTvProviderProgramEntity: EntityInsertAdapter<TvProviderProgramEntity>

  private val __converters: Converters = Converters()
  init {
    this.__db = __db
    this.__insertAdapterOfTvProviderProgramEntity = object : EntityInsertAdapter<TvProviderProgramEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `tv_provider_programs` (`id`,`profileId`,`surface`,`mediaType`,`groupId`,`targetItemId`,`providerProgramId`,`lastPositionMs`,`durationMs`,`lastEngagementAt`,`lastPublishedAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TvProviderProgramEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.tvProviderSurfaceToString(entity.surface)
        statement.bindText(3, _tmp)
        val _tmp_1: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(4, _tmp_1)
        statement.bindLong(5, entity.groupId)
        statement.bindLong(6, entity.targetItemId)
        val _tmpProviderProgramId: Long? = entity.providerProgramId
        if (_tmpProviderProgramId == null) {
          statement.bindNull(7)
        } else {
          statement.bindLong(7, _tmpProviderProgramId)
        }
        statement.bindLong(8, entity.lastPositionMs)
        statement.bindLong(9, entity.durationMs)
        statement.bindLong(10, entity.lastEngagementAt)
        statement.bindLong(11, entity.lastPublishedAt)
      }
    }
  }

  public override suspend fun upsert(row: TvProviderProgramEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfTvProviderProgramEntity.insert(_connection, row)
  }

  public override suspend fun upsertAll(rows: List<TvProviderProgramEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfTvProviderProgramEntity.insert(_connection, rows)
  }

  public override suspend fun find(
    profileId: Long,
    surface: TvProviderSurface,
    mediaType: MediaType,
    groupId: Long,
  ): TvProviderProgramEntity? {
    val _sql: String = "SELECT * FROM tv_provider_programs WHERE profileId = ? AND surface = ? AND mediaType = ? AND groupId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.tvProviderSurfaceToString(surface)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        val _tmp_1: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 4
        _stmt.bindLong(_argIndex, groupId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSurface: Int = getColumnIndexOrThrow(_stmt, "surface")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfTargetItemId: Int = getColumnIndexOrThrow(_stmt, "targetItemId")
        val _columnIndexOfProviderProgramId: Int = getColumnIndexOrThrow(_stmt, "providerProgramId")
        val _columnIndexOfLastPositionMs: Int = getColumnIndexOrThrow(_stmt, "lastPositionMs")
        val _columnIndexOfDurationMs: Int = getColumnIndexOrThrow(_stmt, "durationMs")
        val _columnIndexOfLastEngagementAt: Int = getColumnIndexOrThrow(_stmt, "lastEngagementAt")
        val _columnIndexOfLastPublishedAt: Int = getColumnIndexOrThrow(_stmt, "lastPublishedAt")
        val _result: TvProviderProgramEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSurface: TvProviderSurface
          val _tmp_2: String
          _tmp_2 = _stmt.getText(_columnIndexOfSurface)
          _tmpSurface = __converters.stringToTvProviderSurface(_tmp_2)
          val _tmpMediaType: MediaType
          val _tmp_3: String
          _tmp_3 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_3)
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpTargetItemId: Long
          _tmpTargetItemId = _stmt.getLong(_columnIndexOfTargetItemId)
          val _tmpProviderProgramId: Long?
          if (_stmt.isNull(_columnIndexOfProviderProgramId)) {
            _tmpProviderProgramId = null
          } else {
            _tmpProviderProgramId = _stmt.getLong(_columnIndexOfProviderProgramId)
          }
          val _tmpLastPositionMs: Long
          _tmpLastPositionMs = _stmt.getLong(_columnIndexOfLastPositionMs)
          val _tmpDurationMs: Long
          _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs)
          val _tmpLastEngagementAt: Long
          _tmpLastEngagementAt = _stmt.getLong(_columnIndexOfLastEngagementAt)
          val _tmpLastPublishedAt: Long
          _tmpLastPublishedAt = _stmt.getLong(_columnIndexOfLastPublishedAt)
          _result = TvProviderProgramEntity(_tmpId,_tmpProfileId,_tmpSurface,_tmpMediaType,_tmpGroupId,_tmpTargetItemId,_tmpProviderProgramId,_tmpLastPositionMs,_tmpDurationMs,_tmpLastEngagementAt,_tmpLastPublishedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllForProfile(profileId: Long): List<TvProviderProgramEntity> {
    val _sql: String = "SELECT * FROM tv_provider_programs WHERE profileId = ? ORDER BY surface ASC, lastPublishedAt DESC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSurface: Int = getColumnIndexOrThrow(_stmt, "surface")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfTargetItemId: Int = getColumnIndexOrThrow(_stmt, "targetItemId")
        val _columnIndexOfProviderProgramId: Int = getColumnIndexOrThrow(_stmt, "providerProgramId")
        val _columnIndexOfLastPositionMs: Int = getColumnIndexOrThrow(_stmt, "lastPositionMs")
        val _columnIndexOfDurationMs: Int = getColumnIndexOrThrow(_stmt, "durationMs")
        val _columnIndexOfLastEngagementAt: Int = getColumnIndexOrThrow(_stmt, "lastEngagementAt")
        val _columnIndexOfLastPublishedAt: Int = getColumnIndexOrThrow(_stmt, "lastPublishedAt")
        val _result: MutableList<TvProviderProgramEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: TvProviderProgramEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSurface: TvProviderSurface
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfSurface)
          _tmpSurface = __converters.stringToTvProviderSurface(_tmp)
          val _tmpMediaType: MediaType
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_1)
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpTargetItemId: Long
          _tmpTargetItemId = _stmt.getLong(_columnIndexOfTargetItemId)
          val _tmpProviderProgramId: Long?
          if (_stmt.isNull(_columnIndexOfProviderProgramId)) {
            _tmpProviderProgramId = null
          } else {
            _tmpProviderProgramId = _stmt.getLong(_columnIndexOfProviderProgramId)
          }
          val _tmpLastPositionMs: Long
          _tmpLastPositionMs = _stmt.getLong(_columnIndexOfLastPositionMs)
          val _tmpDurationMs: Long
          _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs)
          val _tmpLastEngagementAt: Long
          _tmpLastEngagementAt = _stmt.getLong(_columnIndexOfLastEngagementAt)
          val _tmpLastPublishedAt: Long
          _tmpLastPublishedAt = _stmt.getLong(_columnIndexOfLastPublishedAt)
          _item = TvProviderProgramEntity(_tmpId,_tmpProfileId,_tmpSurface,_tmpMediaType,_tmpGroupId,_tmpTargetItemId,_tmpProviderProgramId,_tmpLastPositionMs,_tmpDurationMs,_tmpLastEngagementAt,_tmpLastPublishedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getForSurface(profileId: Long, surface: TvProviderSurface): List<TvProviderProgramEntity> {
    val _sql: String = "SELECT * FROM tv_provider_programs WHERE profileId = ? AND surface = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.tvProviderSurfaceToString(surface)
        _stmt.bindText(_argIndex, _tmp)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfSurface: Int = getColumnIndexOrThrow(_stmt, "surface")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfTargetItemId: Int = getColumnIndexOrThrow(_stmt, "targetItemId")
        val _columnIndexOfProviderProgramId: Int = getColumnIndexOrThrow(_stmt, "providerProgramId")
        val _columnIndexOfLastPositionMs: Int = getColumnIndexOrThrow(_stmt, "lastPositionMs")
        val _columnIndexOfDurationMs: Int = getColumnIndexOrThrow(_stmt, "durationMs")
        val _columnIndexOfLastEngagementAt: Int = getColumnIndexOrThrow(_stmt, "lastEngagementAt")
        val _columnIndexOfLastPublishedAt: Int = getColumnIndexOrThrow(_stmt, "lastPublishedAt")
        val _result: MutableList<TvProviderProgramEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: TvProviderProgramEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpSurface: TvProviderSurface
          val _tmp_1: String
          _tmp_1 = _stmt.getText(_columnIndexOfSurface)
          _tmpSurface = __converters.stringToTvProviderSurface(_tmp_1)
          val _tmpMediaType: MediaType
          val _tmp_2: String
          _tmp_2 = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp_2)
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpTargetItemId: Long
          _tmpTargetItemId = _stmt.getLong(_columnIndexOfTargetItemId)
          val _tmpProviderProgramId: Long?
          if (_stmt.isNull(_columnIndexOfProviderProgramId)) {
            _tmpProviderProgramId = null
          } else {
            _tmpProviderProgramId = _stmt.getLong(_columnIndexOfProviderProgramId)
          }
          val _tmpLastPositionMs: Long
          _tmpLastPositionMs = _stmt.getLong(_columnIndexOfLastPositionMs)
          val _tmpDurationMs: Long
          _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs)
          val _tmpLastEngagementAt: Long
          _tmpLastEngagementAt = _stmt.getLong(_columnIndexOfLastEngagementAt)
          val _tmpLastPublishedAt: Long
          _tmpLastPublishedAt = _stmt.getLong(_columnIndexOfLastPublishedAt)
          _item = TvProviderProgramEntity(_tmpId,_tmpProfileId,_tmpSurface,_tmpMediaType,_tmpGroupId,_tmpTargetItemId,_tmpProviderProgramId,_tmpLastPositionMs,_tmpDurationMs,_tmpLastEngagementAt,_tmpLastPublishedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(
    profileId: Long,
    surface: TvProviderSurface,
    mediaType: MediaType,
    groupId: Long,
  ) {
    val _sql: String = "DELETE FROM tv_provider_programs WHERE profileId = ? AND surface = ? AND mediaType = ? AND groupId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.tvProviderSurfaceToString(surface)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        val _tmp_1: String = __converters.mediaTypeToString(mediaType)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 4
        _stmt.bindLong(_argIndex, groupId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteForProfile(profileId: Long) {
    val _sql: String = "DELETE FROM tv_provider_programs WHERE profileId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
