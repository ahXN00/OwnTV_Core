package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import tv.own.owntv.core.database.entity.SubtitleCacheEntity
import tv.own.owntv.core.database.entity.SubtitleLinkEntity
import tv.own.owntv.core.database.entity.SubtitleSelectionEntity
import tv.own.owntv.core.database.entity.SubtitleTimingEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class SubtitleDao_Impl(
  __db: RoomDatabase,
) : SubtitleDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSubtitleCacheEntity: EntityInsertAdapter<SubtitleCacheEntity>

  private val __insertAdapterOfSubtitleSelectionEntity: EntityInsertAdapter<SubtitleSelectionEntity>

  private val __insertAdapterOfSubtitleTimingEntity: EntityInsertAdapter<SubtitleTimingEntity>

  private val __insertAdapterOfSubtitleLinkEntity: EntityInsertAdapter<SubtitleLinkEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfSubtitleCacheEntity = object : EntityInsertAdapter<SubtitleCacheEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `subtitle_cache` (`id`,`source`,`openSubFileId`,`language`,`languageName`,`releaseName`,`format`,`hearingImpaired`,`fileName`,`cachedPath`,`lastUsedAt`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SubtitleCacheEntity) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.source)
        val _tmpOpenSubFileId: Long? = entity.openSubFileId
        if (_tmpOpenSubFileId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpOpenSubFileId)
        }
        val _tmpLanguage: String? = entity.language
        if (_tmpLanguage == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpLanguage)
        }
        val _tmpLanguageName: String? = entity.languageName
        if (_tmpLanguageName == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpLanguageName)
        }
        val _tmpReleaseName: String? = entity.releaseName
        if (_tmpReleaseName == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpReleaseName)
        }
        val _tmpFormat: String? = entity.format
        if (_tmpFormat == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpFormat)
        }
        val _tmp: Int = if (entity.hearingImpaired) 1 else 0
        statement.bindLong(8, _tmp.toLong())
        statement.bindText(9, entity.fileName)
        statement.bindText(10, entity.cachedPath)
        statement.bindLong(11, entity.lastUsedAt)
      }
    }
    this.__insertAdapterOfSubtitleSelectionEntity = object : EntityInsertAdapter<SubtitleSelectionEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `subtitle_selection` (`profileId`,`contentKey`,`cacheId`,`off`,`updatedAt`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SubtitleSelectionEntity) {
        statement.bindLong(1, entity.profileId)
        statement.bindText(2, entity.contentKey)
        val _tmpCacheId: Long? = entity.cacheId
        if (_tmpCacheId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpCacheId)
        }
        val _tmp: Int = if (entity.off) 1 else 0
        statement.bindLong(4, _tmp.toLong())
        statement.bindLong(5, entity.updatedAt)
      }
    }
    this.__insertAdapterOfSubtitleTimingEntity = object : EntityInsertAdapter<SubtitleTimingEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `subtitle_timing` (`profileId`,`contentKey`,`subtitleKey`,`offsetMs`,`updatedAt`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SubtitleTimingEntity) {
        statement.bindLong(1, entity.profileId)
        statement.bindText(2, entity.contentKey)
        statement.bindText(3, entity.subtitleKey)
        statement.bindLong(4, entity.offsetMs.toLong())
        statement.bindLong(5, entity.updatedAt)
      }
    }
    this.__insertAdapterOfSubtitleLinkEntity = object : EntityInsertAdapter<SubtitleLinkEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `subtitle_link` (`profileId`,`contentKey`,`cacheId`,`mediaType`,`contentTitle`,`addedAt`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SubtitleLinkEntity) {
        statement.bindLong(1, entity.profileId)
        statement.bindText(2, entity.contentKey)
        statement.bindLong(3, entity.cacheId)
        statement.bindText(4, entity.mediaType)
        statement.bindText(5, entity.contentTitle)
        statement.bindLong(6, entity.addedAt)
      }
    }
  }

  public override suspend fun insertCache(entry: SubtitleCacheEntity): Long = performSuspending(__db, false, true) { _connection ->
    val _result: Long = __insertAdapterOfSubtitleCacheEntity.insertAndReturnId(_connection, entry)
    _result
  }

  public override suspend fun upsertSelection(selection: SubtitleSelectionEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSubtitleSelectionEntity.insert(_connection, selection)
  }

  public override suspend fun upsertTiming(timing: SubtitleTimingEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSubtitleTimingEntity.insert(_connection, timing)
  }

  public override suspend fun insertLink(link: SubtitleLinkEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSubtitleLinkEntity.insert(_connection, link)
  }

  public override suspend fun findByOpenSubFileId(fileId: Long): SubtitleCacheEntity? {
    val _sql: String = "SELECT * FROM subtitle_cache WHERE openSubFileId = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, fileId)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSource: Int = getColumnIndexOrThrow(_stmt, "source")
        val _columnIndexOfOpenSubFileId: Int = getColumnIndexOrThrow(_stmt, "openSubFileId")
        val _columnIndexOfLanguage: Int = getColumnIndexOrThrow(_stmt, "language")
        val _columnIndexOfLanguageName: Int = getColumnIndexOrThrow(_stmt, "languageName")
        val _columnIndexOfReleaseName: Int = getColumnIndexOrThrow(_stmt, "releaseName")
        val _columnIndexOfFormat: Int = getColumnIndexOrThrow(_stmt, "format")
        val _columnIndexOfHearingImpaired: Int = getColumnIndexOrThrow(_stmt, "hearingImpaired")
        val _columnIndexOfFileName: Int = getColumnIndexOrThrow(_stmt, "fileName")
        val _columnIndexOfCachedPath: Int = getColumnIndexOrThrow(_stmt, "cachedPath")
        val _columnIndexOfLastUsedAt: Int = getColumnIndexOrThrow(_stmt, "lastUsedAt")
        val _result: SubtitleCacheEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSource: String
          _tmpSource = _stmt.getText(_columnIndexOfSource)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpHearingImpaired: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfHearingImpaired).toInt()
          _tmpHearingImpaired = _tmp != 0
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpLastUsedAt: Long
          _tmpLastUsedAt = _stmt.getLong(_columnIndexOfLastUsedAt)
          _result = SubtitleCacheEntity(_tmpId,_tmpSource,_tmpOpenSubFileId,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpHearingImpaired,_tmpFileName,_tmpCachedPath,_tmpLastUsedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun cacheById(id: Long): SubtitleCacheEntity? {
    val _sql: String = "SELECT * FROM subtitle_cache WHERE id = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSource: Int = getColumnIndexOrThrow(_stmt, "source")
        val _columnIndexOfOpenSubFileId: Int = getColumnIndexOrThrow(_stmt, "openSubFileId")
        val _columnIndexOfLanguage: Int = getColumnIndexOrThrow(_stmt, "language")
        val _columnIndexOfLanguageName: Int = getColumnIndexOrThrow(_stmt, "languageName")
        val _columnIndexOfReleaseName: Int = getColumnIndexOrThrow(_stmt, "releaseName")
        val _columnIndexOfFormat: Int = getColumnIndexOrThrow(_stmt, "format")
        val _columnIndexOfHearingImpaired: Int = getColumnIndexOrThrow(_stmt, "hearingImpaired")
        val _columnIndexOfFileName: Int = getColumnIndexOrThrow(_stmt, "fileName")
        val _columnIndexOfCachedPath: Int = getColumnIndexOrThrow(_stmt, "cachedPath")
        val _columnIndexOfLastUsedAt: Int = getColumnIndexOrThrow(_stmt, "lastUsedAt")
        val _result: SubtitleCacheEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSource: String
          _tmpSource = _stmt.getText(_columnIndexOfSource)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpHearingImpaired: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfHearingImpaired).toInt()
          _tmpHearingImpaired = _tmp != 0
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpLastUsedAt: Long
          _tmpLastUsedAt = _stmt.getLong(_columnIndexOfLastUsedAt)
          _result = SubtitleCacheEntity(_tmpId,_tmpSource,_tmpOpenSubFileId,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpHearingImpaired,_tmpFileName,_tmpCachedPath,_tmpLastUsedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findLocalByFileName(fileName: String): SubtitleCacheEntity? {
    val _sql: String = "SELECT * FROM subtitle_cache WHERE source = 'LOCAL' AND fileName = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, fileName)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSource: Int = getColumnIndexOrThrow(_stmt, "source")
        val _columnIndexOfOpenSubFileId: Int = getColumnIndexOrThrow(_stmt, "openSubFileId")
        val _columnIndexOfLanguage: Int = getColumnIndexOrThrow(_stmt, "language")
        val _columnIndexOfLanguageName: Int = getColumnIndexOrThrow(_stmt, "languageName")
        val _columnIndexOfReleaseName: Int = getColumnIndexOrThrow(_stmt, "releaseName")
        val _columnIndexOfFormat: Int = getColumnIndexOrThrow(_stmt, "format")
        val _columnIndexOfHearingImpaired: Int = getColumnIndexOrThrow(_stmt, "hearingImpaired")
        val _columnIndexOfFileName: Int = getColumnIndexOrThrow(_stmt, "fileName")
        val _columnIndexOfCachedPath: Int = getColumnIndexOrThrow(_stmt, "cachedPath")
        val _columnIndexOfLastUsedAt: Int = getColumnIndexOrThrow(_stmt, "lastUsedAt")
        val _result: SubtitleCacheEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSource: String
          _tmpSource = _stmt.getText(_columnIndexOfSource)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpHearingImpaired: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfHearingImpaired).toInt()
          _tmpHearingImpaired = _tmp != 0
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpLastUsedAt: Long
          _tmpLastUsedAt = _stmt.getLong(_columnIndexOfLastUsedAt)
          _result = SubtitleCacheEntity(_tmpId,_tmpSource,_tmpOpenSubFileId,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpHearingImpaired,_tmpFileName,_tmpCachedPath,_tmpLastUsedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun selection(profileId: Long, contentKey: String): SubtitleSelectionEntity? {
    val _sql: String = "SELECT * FROM subtitle_selection WHERE profileId = ? AND contentKey = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfCacheId: Int = getColumnIndexOrThrow(_stmt, "cacheId")
        val _columnIndexOfOff: Int = getColumnIndexOrThrow(_stmt, "off")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: SubtitleSelectionEntity?
        if (_stmt.step()) {
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpCacheId: Long?
          if (_stmt.isNull(_columnIndexOfCacheId)) {
            _tmpCacheId = null
          } else {
            _tmpCacheId = _stmt.getLong(_columnIndexOfCacheId)
          }
          val _tmpOff: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfOff).toInt()
          _tmpOff = _tmp != 0
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = SubtitleSelectionEntity(_tmpProfileId,_tmpContentKey,_tmpCacheId,_tmpOff,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun timingOffset(
    profileId: Long,
    contentKey: String,
    subtitleKey: String,
  ): Int? {
    val _sql: String = "SELECT offsetMs FROM subtitle_timing WHERE profileId = ? AND contentKey = ? AND subtitleKey = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        _argIndex = 3
        _stmt.bindText(_argIndex, subtitleKey)
        val _result: Int?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getLong(0).toInt()
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun linksForContent(profileId: Long, contentKey: String): List<LinkedSubtitle> {
    val _sql: String = "SELECT c.id AS cacheId, l.contentKey AS contentKey, l.contentTitle AS contentTitle, l.mediaType AS mediaType, c.language AS language, c.languageName AS languageName, c.releaseName AS releaseName, c.format AS format, c.fileName AS fileName, c.cachedPath AS cachedPath, c.openSubFileId AS openSubFileId, l.addedAt AS addedAt FROM subtitle_link l JOIN subtitle_cache c ON c.id = l.cacheId WHERE l.profileId = ? AND l.contentKey = ? ORDER BY l.addedAt DESC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        val _columnIndexOfCacheId: Int = 0
        val _columnIndexOfContentKey: Int = 1
        val _columnIndexOfContentTitle: Int = 2
        val _columnIndexOfMediaType: Int = 3
        val _columnIndexOfLanguage: Int = 4
        val _columnIndexOfLanguageName: Int = 5
        val _columnIndexOfReleaseName: Int = 6
        val _columnIndexOfFormat: Int = 7
        val _columnIndexOfFileName: Int = 8
        val _columnIndexOfCachedPath: Int = 9
        val _columnIndexOfOpenSubFileId: Int = 10
        val _columnIndexOfAddedAt: Int = 11
        val _result: MutableList<LinkedSubtitle> = mutableListOf()
        while (_stmt.step()) {
          val _item: LinkedSubtitle
          val _tmpCacheId: Long
          _tmpCacheId = _stmt.getLong(_columnIndexOfCacheId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpContentTitle: String
          _tmpContentTitle = _stmt.getText(_columnIndexOfContentTitle)
          val _tmpMediaType: String
          _tmpMediaType = _stmt.getText(_columnIndexOfMediaType)
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpAddedAt: Long
          _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          _item = LinkedSubtitle(_tmpCacheId,_tmpContentKey,_tmpContentTitle,_tmpMediaType,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpFileName,_tmpCachedPath,_tmpOpenSubFileId,_tmpAddedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun linksForType(profileId: Long, mediaType: String): List<LinkedSubtitle> {
    val _sql: String = "SELECT c.id AS cacheId, l.contentKey AS contentKey, l.contentTitle AS contentTitle, l.mediaType AS mediaType, c.language AS language, c.languageName AS languageName, c.releaseName AS releaseName, c.format AS format, c.fileName AS fileName, c.cachedPath AS cachedPath, c.openSubFileId AS openSubFileId, l.addedAt AS addedAt FROM subtitle_link l JOIN subtitle_cache c ON c.id = l.cacheId WHERE l.profileId = ? AND l.mediaType = ? ORDER BY l.contentTitle, c.languageName"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, mediaType)
        val _columnIndexOfCacheId: Int = 0
        val _columnIndexOfContentKey: Int = 1
        val _columnIndexOfContentTitle: Int = 2
        val _columnIndexOfMediaType: Int = 3
        val _columnIndexOfLanguage: Int = 4
        val _columnIndexOfLanguageName: Int = 5
        val _columnIndexOfReleaseName: Int = 6
        val _columnIndexOfFormat: Int = 7
        val _columnIndexOfFileName: Int = 8
        val _columnIndexOfCachedPath: Int = 9
        val _columnIndexOfOpenSubFileId: Int = 10
        val _columnIndexOfAddedAt: Int = 11
        val _result: MutableList<LinkedSubtitle> = mutableListOf()
        while (_stmt.step()) {
          val _item: LinkedSubtitle
          val _tmpCacheId: Long
          _tmpCacheId = _stmt.getLong(_columnIndexOfCacheId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpContentTitle: String
          _tmpContentTitle = _stmt.getText(_columnIndexOfContentTitle)
          val _tmpMediaType: String
          _tmpMediaType = _stmt.getText(_columnIndexOfMediaType)
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpAddedAt: Long
          _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          _item = LinkedSubtitle(_tmpCacheId,_tmpContentKey,_tmpContentTitle,_tmpMediaType,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpFileName,_tmpCachedPath,_tmpOpenSubFileId,_tmpAddedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun linkCountForContent(profileId: Long, contentKey: String): Int {
    val _sql: String = "SELECT COUNT(*) FROM subtitle_link WHERE profileId = ? AND contentKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun linkCountForCacheOtherProfiles(cacheId: Long, profileId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM subtitle_link WHERE cacheId = ? AND profileId != ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, cacheId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, profileId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun cacheIdsForType(profileId: Long, mediaType: String): List<Long> {
    val _sql: String = "SELECT DISTINCT cacheId FROM subtitle_link WHERE profileId = ? AND mediaType = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, mediaType)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun linkCountForCache(cacheId: Long, profileId: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM subtitle_link WHERE cacheId = ? AND profileId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, cacheId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, profileId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allCacheOnce(): List<SubtitleCacheEntity> {
    val _sql: String = "SELECT * FROM subtitle_cache"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSource: Int = getColumnIndexOrThrow(_stmt, "source")
        val _columnIndexOfOpenSubFileId: Int = getColumnIndexOrThrow(_stmt, "openSubFileId")
        val _columnIndexOfLanguage: Int = getColumnIndexOrThrow(_stmt, "language")
        val _columnIndexOfLanguageName: Int = getColumnIndexOrThrow(_stmt, "languageName")
        val _columnIndexOfReleaseName: Int = getColumnIndexOrThrow(_stmt, "releaseName")
        val _columnIndexOfFormat: Int = getColumnIndexOrThrow(_stmt, "format")
        val _columnIndexOfHearingImpaired: Int = getColumnIndexOrThrow(_stmt, "hearingImpaired")
        val _columnIndexOfFileName: Int = getColumnIndexOrThrow(_stmt, "fileName")
        val _columnIndexOfCachedPath: Int = getColumnIndexOrThrow(_stmt, "cachedPath")
        val _columnIndexOfLastUsedAt: Int = getColumnIndexOrThrow(_stmt, "lastUsedAt")
        val _result: MutableList<SubtitleCacheEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SubtitleCacheEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSource: String
          _tmpSource = _stmt.getText(_columnIndexOfSource)
          val _tmpOpenSubFileId: Long?
          if (_stmt.isNull(_columnIndexOfOpenSubFileId)) {
            _tmpOpenSubFileId = null
          } else {
            _tmpOpenSubFileId = _stmt.getLong(_columnIndexOfOpenSubFileId)
          }
          val _tmpLanguage: String?
          if (_stmt.isNull(_columnIndexOfLanguage)) {
            _tmpLanguage = null
          } else {
            _tmpLanguage = _stmt.getText(_columnIndexOfLanguage)
          }
          val _tmpLanguageName: String?
          if (_stmt.isNull(_columnIndexOfLanguageName)) {
            _tmpLanguageName = null
          } else {
            _tmpLanguageName = _stmt.getText(_columnIndexOfLanguageName)
          }
          val _tmpReleaseName: String?
          if (_stmt.isNull(_columnIndexOfReleaseName)) {
            _tmpReleaseName = null
          } else {
            _tmpReleaseName = _stmt.getText(_columnIndexOfReleaseName)
          }
          val _tmpFormat: String?
          if (_stmt.isNull(_columnIndexOfFormat)) {
            _tmpFormat = null
          } else {
            _tmpFormat = _stmt.getText(_columnIndexOfFormat)
          }
          val _tmpHearingImpaired: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfHearingImpaired).toInt()
          _tmpHearingImpaired = _tmp != 0
          val _tmpFileName: String
          _tmpFileName = _stmt.getText(_columnIndexOfFileName)
          val _tmpCachedPath: String
          _tmpCachedPath = _stmt.getText(_columnIndexOfCachedPath)
          val _tmpLastUsedAt: Long
          _tmpLastUsedAt = _stmt.getLong(_columnIndexOfLastUsedAt)
          _item = SubtitleCacheEntity(_tmpId,_tmpSource,_tmpOpenSubFileId,_tmpLanguage,_tmpLanguageName,_tmpReleaseName,_tmpFormat,_tmpHearingImpaired,_tmpFileName,_tmpCachedPath,_tmpLastUsedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allSelectionsOnce(): List<SubtitleSelectionEntity> {
    val _sql: String = "SELECT * FROM subtitle_selection"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfCacheId: Int = getColumnIndexOrThrow(_stmt, "cacheId")
        val _columnIndexOfOff: Int = getColumnIndexOrThrow(_stmt, "off")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<SubtitleSelectionEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SubtitleSelectionEntity
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpCacheId: Long?
          if (_stmt.isNull(_columnIndexOfCacheId)) {
            _tmpCacheId = null
          } else {
            _tmpCacheId = _stmt.getLong(_columnIndexOfCacheId)
          }
          val _tmpOff: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfOff).toInt()
          _tmpOff = _tmp != 0
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = SubtitleSelectionEntity(_tmpProfileId,_tmpContentKey,_tmpCacheId,_tmpOff,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allTimingsOnce(): List<SubtitleTimingEntity> {
    val _sql: String = "SELECT * FROM subtitle_timing"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfSubtitleKey: Int = getColumnIndexOrThrow(_stmt, "subtitleKey")
        val _columnIndexOfOffsetMs: Int = getColumnIndexOrThrow(_stmt, "offsetMs")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<SubtitleTimingEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SubtitleTimingEntity
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpSubtitleKey: String
          _tmpSubtitleKey = _stmt.getText(_columnIndexOfSubtitleKey)
          val _tmpOffsetMs: Int
          _tmpOffsetMs = _stmt.getLong(_columnIndexOfOffsetMs).toInt()
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = SubtitleTimingEntity(_tmpProfileId,_tmpContentKey,_tmpSubtitleKey,_tmpOffsetMs,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allLinksOnce(): List<SubtitleLinkEntity> {
    val _sql: String = "SELECT * FROM subtitle_link"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfCacheId: Int = getColumnIndexOrThrow(_stmt, "cacheId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfContentTitle: Int = getColumnIndexOrThrow(_stmt, "contentTitle")
        val _columnIndexOfAddedAt: Int = getColumnIndexOrThrow(_stmt, "addedAt")
        val _result: MutableList<SubtitleLinkEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: SubtitleLinkEntity
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpCacheId: Long
          _tmpCacheId = _stmt.getLong(_columnIndexOfCacheId)
          val _tmpMediaType: String
          _tmpMediaType = _stmt.getText(_columnIndexOfMediaType)
          val _tmpContentTitle: String
          _tmpContentTitle = _stmt.getText(_columnIndexOfContentTitle)
          val _tmpAddedAt: Long
          _tmpAddedAt = _stmt.getLong(_columnIndexOfAddedAt)
          _item = SubtitleLinkEntity(_tmpProfileId,_tmpContentKey,_tmpCacheId,_tmpMediaType,_tmpContentTitle,_tmpAddedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun touchCache(id: Long, now: Long) {
    val _sql: String = "UPDATE subtitle_cache SET lastUsedAt = ? WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, now)
        _argIndex = 2
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteCache(id: Long) {
    val _sql: String = "DELETE FROM subtitle_cache WHERE id = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearSelection(profileId: Long, contentKey: String) {
    val _sql: String = "DELETE FROM subtitle_selection WHERE profileId = ? AND contentKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindText(_argIndex, contentKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteLinksForProfile(profileId: Long, cacheId: Long) {
    val _sql: String = "DELETE FROM subtitle_link WHERE profileId = ? AND cacheId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, cacheId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearSelectionsForCache(profileId: Long, cacheId: Long) {
    val _sql: String = "UPDATE subtitle_selection SET cacheId = NULL WHERE profileId = ? AND cacheId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, cacheId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteLinksForProfileAndType(
    profileId: Long,
    cacheId: Long,
    mediaType: String,
  ) {
    val _sql: String = "DELETE FROM subtitle_link WHERE profileId = ? AND cacheId = ? AND mediaType = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, cacheId)
        _argIndex = 3
        _stmt.bindText(_argIndex, mediaType)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
