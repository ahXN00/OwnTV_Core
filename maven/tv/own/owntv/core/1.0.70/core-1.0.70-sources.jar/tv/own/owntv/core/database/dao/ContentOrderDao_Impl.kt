package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.Converters
import tv.own.owntv.core.database.entity.ContentOrderEntity
import tv.own.owntv.core.model.MediaType

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class ContentOrderDao_Impl(
  __db: RoomDatabase,
) : ContentOrderDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfContentOrderEntity: EntityInsertAdapter<ContentOrderEntity>

  private val __converters: Converters = Converters()
  init {
    this.__db = __db
    this.__insertAdapterOfContentOrderEntity = object : EntityInsertAdapter<ContentOrderEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `content_order` (`id`,`profileId`,`mediaType`,`contextKey`,`itemId`,`position`) VALUES (nullif(?, 0),?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ContentOrderEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.profileId)
        val _tmp: String = __converters.mediaTypeToString(entity.mediaType)
        statement.bindText(3, _tmp)
        statement.bindText(4, entity.contextKey)
        statement.bindLong(5, entity.itemId)
        statement.bindLong(6, entity.position.toLong())
      }
    }
  }

  public override suspend fun insertAll(rows: List<ContentOrderEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfContentOrderEntity.insert(_connection, rows)
  }

  public override suspend fun replaceContext(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    rows: List<ContentOrderEntity>,
  ): Unit = performInTransactionSuspending(__db) {
    super@ContentOrderDao_Impl.replaceContext(profileId, type, contextKey, rows)
  }

  public override suspend fun saveMove(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    order: List<Long>,
    carried: Set<Long>,
  ): Unit = performInTransactionSuspending(__db) {
    super@ContentOrderDao_Impl.saveMove(profileId, type, contextKey, order, carried)
  }

  public override fun observeContextKeys(profileId: Long, type: MediaType): Flow<List<String>> {
    val _sql: String = "SELECT DISTINCT contextKey FROM content_order WHERE profileId = ? AND mediaType = ?"
    return createFlow(__db, false, arrayOf("content_order")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exists(
    profileId: Long,
    type: MediaType,
    contextKey: String,
    itemId: Long,
  ): Boolean {
    val _sql: String = "SELECT EXISTS(SELECT 1 FROM content_order WHERE profileId = ? AND mediaType = ? AND contextKey = ? AND itemId = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _argIndex = 4
        _stmt.bindLong(_argIndex, itemId)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(0).toInt()
          _result = _tmp_1 != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun movedItemIds(
    profileId: Long,
    type: MediaType,
    contextKey: String,
  ): List<Long> {
    val _sql: String = "SELECT itemId FROM content_order WHERE profileId = ? AND mediaType = ? AND contextKey = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item: Long
          _item = _stmt.getLong(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<ContentOrderEntity> {
    val _sql: String = "SELECT * FROM content_order"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfProfileId: Int = getColumnIndexOrThrow(_stmt, "profileId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfContextKey: Int = getColumnIndexOrThrow(_stmt, "contextKey")
        val _columnIndexOfItemId: Int = getColumnIndexOrThrow(_stmt, "itemId")
        val _columnIndexOfPosition: Int = getColumnIndexOrThrow(_stmt, "position")
        val _result: MutableList<ContentOrderEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: ContentOrderEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpContextKey: String
          _tmpContextKey = _stmt.getText(_columnIndexOfContextKey)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          _item = ContentOrderEntity(_tmpId,_tmpProfileId,_tmpMediaType,_tmpContextKey,_tmpItemId,_tmpPosition)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun exportRowsForSource(sourceId: Long): List<ContentOrderExportRow> {
    val _sql: String = "SELECT o.profileId AS profileId, o.mediaType AS mediaType, o.itemId AS itemId, o.contextKey AS contextKey, o.position AS position, COALESCE(c.sourceId, m.sourceId, s.sourceId) AS sourceId, COALESCE(c.remoteId, m.remoteId, s.remoteId) AS remoteId, COALESCE(c.name, m.name, s.name) AS name FROM content_order o LEFT JOIN channels c ON o.mediaType = 'LIVE' AND o.itemId = c.id LEFT JOIN movies m ON o.mediaType = 'MOVIE' AND o.itemId = m.id LEFT JOIN series s ON o.mediaType = 'SERIES' AND o.itemId = s.id WHERE c.sourceId = ? OR m.sourceId = ? OR s.sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindLong(_argIndex, sourceId)
        val _columnIndexOfProfileId: Int = 0
        val _columnIndexOfMediaType: Int = 1
        val _columnIndexOfItemId: Int = 2
        val _columnIndexOfContextKey: Int = 3
        val _columnIndexOfPosition: Int = 4
        val _columnIndexOfSourceId: Int = 5
        val _columnIndexOfRemoteId: Int = 6
        val _columnIndexOfName: Int = 7
        val _result: MutableList<ContentOrderExportRow> = mutableListOf()
        while (_stmt.step()) {
          val _item: ContentOrderExportRow
          val _tmpProfileId: Long
          _tmpProfileId = _stmt.getLong(_columnIndexOfProfileId)
          val _tmpMediaType: MediaType
          val _tmp: String
          _tmp = _stmt.getText(_columnIndexOfMediaType)
          _tmpMediaType = __converters.stringToMediaType(_tmp)
          val _tmpItemId: Long
          _tmpItemId = _stmt.getLong(_columnIndexOfItemId)
          val _tmpContextKey: String
          _tmpContextKey = _stmt.getText(_columnIndexOfContextKey)
          val _tmpPosition: Int
          _tmpPosition = _stmt.getLong(_columnIndexOfPosition).toInt()
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpRemoteId: String?
          if (_stmt.isNull(_columnIndexOfRemoteId)) {
            _tmpRemoteId = null
          } else {
            _tmpRemoteId = _stmt.getText(_columnIndexOfRemoteId)
          }
          val _tmpName: String?
          if (_stmt.isNull(_columnIndexOfName)) {
            _tmpName = null
          } else {
            _tmpName = _stmt.getText(_columnIndexOfName)
          }
          _item = ContentOrderExportRow(_tmpProfileId,_tmpMediaType,_tmpItemId,_tmpContextKey,_tmpPosition,_tmpSourceId,_tmpRemoteId,_tmpName)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearContext(
    profileId: Long,
    type: MediaType,
    contextKey: String,
  ) {
    val _sql: String = "DELETE FROM content_order WHERE profileId = ? AND mediaType = ? AND contextKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        _stmt.bindText(_argIndex, contextKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearProfile(profileId: Long) {
    val _sql: String = "DELETE FROM content_order WHERE profileId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun dropListOrdersExcept(keep: String) {
    val _sql: String = "DELETE FROM content_order WHERE contextKey != ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, keep)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeSnapshotOrphans(
    profileId: Long,
    type: MediaType,
    itemIds: List<Long>,
  ) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM content_order WHERE profileId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND mediaType = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND itemId IN (")
    val _inputSize: Int = itemIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND ((")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (")
    _stringBuilder.append("?")
    _stringBuilder.append(" = 'SERIES' AND itemId NOT IN (SELECT id FROM series)))")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, profileId)
        _argIndex = 2
        val _tmp: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp)
        _argIndex = 3
        for (_item: Long in itemIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 3 + _inputSize
        val _tmp_1: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_1)
        _argIndex = 4 + _inputSize
        val _tmp_2: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_2)
        _argIndex = 5 + _inputSize
        val _tmp_3: String = __converters.mediaTypeToString(type)
        _stmt.bindText(_argIndex, _tmp_3)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun purgeOrphans() {
    val _sql: String = "DELETE FROM content_order WHERE (mediaType = 'LIVE'   AND itemId NOT IN (SELECT id FROM channels)) OR (mediaType = 'MOVIE'  AND itemId NOT IN (SELECT id FROM movies))   OR (mediaType = 'SERIES' AND itemId NOT IN (SELECT id FROM series))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
