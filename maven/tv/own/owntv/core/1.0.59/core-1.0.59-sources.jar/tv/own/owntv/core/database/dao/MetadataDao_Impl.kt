package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Double
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import tv.own.owntv.core.database.entity.MetadataCacheEntity
import tv.own.owntv.core.database.entity.MetadataMatchEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class MetadataDao_Impl(
  __db: RoomDatabase,
) : MetadataDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfMetadataMatchEntity: EntityInsertAdapter<MetadataMatchEntity>

  private val __insertAdapterOfMetadataCacheEntity: EntityInsertAdapter<MetadataCacheEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfMetadataMatchEntity = object : EntityInsertAdapter<MetadataMatchEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `metadata_match` (`localKey`,`type`,`tmdbId`,`confidence`,`updatedAt`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MetadataMatchEntity) {
        statement.bindText(1, entity.localKey)
        statement.bindText(2, entity.type)
        val _tmpTmdbId: Int? = entity.tmdbId
        if (_tmpTmdbId == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpTmdbId.toLong())
        }
        statement.bindDouble(4, entity.confidence)
        statement.bindLong(5, entity.updatedAt)
      }
    }
    this.__insertAdapterOfMetadataCacheEntity = object : EntityInsertAdapter<MetadataCacheEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `metadata_cache` (`key`,`tmdbId`,`imdbId`,`type`,`title`,`year`,`overview`,`posterPath`,`backdropPath`,`rating`,`genresJson`,`castJson`,`trailerKey`,`logoPath`,`updatedAt`,`airDate`,`originalLanguage`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: MetadataCacheEntity) {
        statement.bindText(1, entity.key)
        statement.bindLong(2, entity.tmdbId.toLong())
        val _tmpImdbId: String? = entity.imdbId
        if (_tmpImdbId == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpImdbId)
        }
        statement.bindText(4, entity.type)
        statement.bindText(5, entity.title)
        val _tmpYear: Int? = entity.year
        if (_tmpYear == null) {
          statement.bindNull(6)
        } else {
          statement.bindLong(6, _tmpYear.toLong())
        }
        val _tmpOverview: String? = entity.overview
        if (_tmpOverview == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpOverview)
        }
        val _tmpPosterPath: String? = entity.posterPath
        if (_tmpPosterPath == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpPosterPath)
        }
        val _tmpBackdropPath: String? = entity.backdropPath
        if (_tmpBackdropPath == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpBackdropPath)
        }
        val _tmpRating: Double? = entity.rating
        if (_tmpRating == null) {
          statement.bindNull(10)
        } else {
          statement.bindDouble(10, _tmpRating)
        }
        val _tmpGenresJson: String? = entity.genresJson
        if (_tmpGenresJson == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpGenresJson)
        }
        val _tmpCastJson: String? = entity.castJson
        if (_tmpCastJson == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpCastJson)
        }
        val _tmpTrailerKey: String? = entity.trailerKey
        if (_tmpTrailerKey == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpTrailerKey)
        }
        val _tmpLogoPath: String? = entity.logoPath
        if (_tmpLogoPath == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpLogoPath)
        }
        statement.bindLong(15, entity.updatedAt)
        val _tmpAirDate: String? = entity.airDate
        if (_tmpAirDate == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpAirDate)
        }
        val _tmpOriginalLanguage: String? = entity.originalLanguage
        if (_tmpOriginalLanguage == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpOriginalLanguage)
        }
      }
    }
  }

  public override suspend fun upsertMatch(match: MetadataMatchEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfMetadataMatchEntity.insert(_connection, match)
  }

  public override suspend fun upsertCache(entity: MetadataCacheEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfMetadataCacheEntity.insert(_connection, entity)
  }

  public override suspend fun upsertCaches(entities: List<MetadataCacheEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfMetadataCacheEntity.insert(_connection, entities)
  }

  public override suspend fun getMatch(localKey: String): MetadataMatchEntity? {
    val _sql: String = "SELECT * FROM metadata_match WHERE localKey = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, localKey)
        val _columnIndexOfLocalKey: Int = getColumnIndexOrThrow(_stmt, "localKey")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfConfidence: Int = getColumnIndexOrThrow(_stmt, "confidence")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MetadataMatchEntity?
        if (_stmt.step()) {
          val _tmpLocalKey: String
          _tmpLocalKey = _stmt.getText(_columnIndexOfLocalKey)
          val _tmpType: String
          _tmpType = _stmt.getText(_columnIndexOfType)
          val _tmpTmdbId: Int?
          if (_stmt.isNull(_columnIndexOfTmdbId)) {
            _tmpTmdbId = null
          } else {
            _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          }
          val _tmpConfidence: Double
          _tmpConfidence = _stmt.getDouble(_columnIndexOfConfidence)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = MetadataMatchEntity(_tmpLocalKey,_tmpType,_tmpTmdbId,_tmpConfidence,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getMatches(keys: List<String>): List<MetadataMatchEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM metadata_match WHERE localKey IN (")
    val _inputSize: Int = keys.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in keys) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfLocalKey: Int = getColumnIndexOrThrow(_stmt, "localKey")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfConfidence: Int = getColumnIndexOrThrow(_stmt, "confidence")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<MetadataMatchEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MetadataMatchEntity
          val _tmpLocalKey: String
          _tmpLocalKey = _stmt.getText(_columnIndexOfLocalKey)
          val _tmpType: String
          _tmpType = _stmt.getText(_columnIndexOfType)
          val _tmpTmdbId: Int?
          if (_stmt.isNull(_columnIndexOfTmdbId)) {
            _tmpTmdbId = null
          } else {
            _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          }
          val _tmpConfidence: Double
          _tmpConfidence = _stmt.getDouble(_columnIndexOfConfidence)
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item_1 = MetadataMatchEntity(_tmpLocalKey,_tmpType,_tmpTmdbId,_tmpConfidence,_tmpUpdatedAt)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getCache(key: String): MetadataCacheEntity? {
    val _sql: String = "SELECT * FROM metadata_cache WHERE key = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfImdbId: Int = getColumnIndexOrThrow(_stmt, "imdbId")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfGenresJson: Int = getColumnIndexOrThrow(_stmt, "genresJson")
        val _columnIndexOfCastJson: Int = getColumnIndexOrThrow(_stmt, "castJson")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfLogoPath: Int = getColumnIndexOrThrow(_stmt, "logoPath")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _columnIndexOfAirDate: Int = getColumnIndexOrThrow(_stmt, "airDate")
        val _columnIndexOfOriginalLanguage: Int = getColumnIndexOrThrow(_stmt, "originalLanguage")
        val _result: MetadataCacheEntity?
        if (_stmt.step()) {
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpImdbId: String?
          if (_stmt.isNull(_columnIndexOfImdbId)) {
            _tmpImdbId = null
          } else {
            _tmpImdbId = _stmt.getText(_columnIndexOfImdbId)
          }
          val _tmpType: String
          _tmpType = _stmt.getText(_columnIndexOfType)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpGenresJson: String?
          if (_stmt.isNull(_columnIndexOfGenresJson)) {
            _tmpGenresJson = null
          } else {
            _tmpGenresJson = _stmt.getText(_columnIndexOfGenresJson)
          }
          val _tmpCastJson: String?
          if (_stmt.isNull(_columnIndexOfCastJson)) {
            _tmpCastJson = null
          } else {
            _tmpCastJson = _stmt.getText(_columnIndexOfCastJson)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpLogoPath: String?
          if (_stmt.isNull(_columnIndexOfLogoPath)) {
            _tmpLogoPath = null
          } else {
            _tmpLogoPath = _stmt.getText(_columnIndexOfLogoPath)
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          val _tmpAirDate: String?
          if (_stmt.isNull(_columnIndexOfAirDate)) {
            _tmpAirDate = null
          } else {
            _tmpAirDate = _stmt.getText(_columnIndexOfAirDate)
          }
          val _tmpOriginalLanguage: String?
          if (_stmt.isNull(_columnIndexOfOriginalLanguage)) {
            _tmpOriginalLanguage = null
          } else {
            _tmpOriginalLanguage = _stmt.getText(_columnIndexOfOriginalLanguage)
          }
          _result = MetadataCacheEntity(_tmpKey,_tmpTmdbId,_tmpImdbId,_tmpType,_tmpTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpGenresJson,_tmpCastJson,_tmpTrailerKey,_tmpLogoPath,_tmpUpdatedAt,_tmpAirDate,_tmpOriginalLanguage)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getCaches(keys: List<String>): List<MetadataCacheEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM metadata_cache WHERE key IN (")
    val _inputSize: Int = keys.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in keys) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfTmdbId: Int = getColumnIndexOrThrow(_stmt, "tmdbId")
        val _columnIndexOfImdbId: Int = getColumnIndexOrThrow(_stmt, "imdbId")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfYear: Int = getColumnIndexOrThrow(_stmt, "year")
        val _columnIndexOfOverview: Int = getColumnIndexOrThrow(_stmt, "overview")
        val _columnIndexOfPosterPath: Int = getColumnIndexOrThrow(_stmt, "posterPath")
        val _columnIndexOfBackdropPath: Int = getColumnIndexOrThrow(_stmt, "backdropPath")
        val _columnIndexOfRating: Int = getColumnIndexOrThrow(_stmt, "rating")
        val _columnIndexOfGenresJson: Int = getColumnIndexOrThrow(_stmt, "genresJson")
        val _columnIndexOfCastJson: Int = getColumnIndexOrThrow(_stmt, "castJson")
        val _columnIndexOfTrailerKey: Int = getColumnIndexOrThrow(_stmt, "trailerKey")
        val _columnIndexOfLogoPath: Int = getColumnIndexOrThrow(_stmt, "logoPath")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _columnIndexOfAirDate: Int = getColumnIndexOrThrow(_stmt, "airDate")
        val _columnIndexOfOriginalLanguage: Int = getColumnIndexOrThrow(_stmt, "originalLanguage")
        val _result: MutableList<MetadataCacheEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: MetadataCacheEntity
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpTmdbId: Int
          _tmpTmdbId = _stmt.getLong(_columnIndexOfTmdbId).toInt()
          val _tmpImdbId: String?
          if (_stmt.isNull(_columnIndexOfImdbId)) {
            _tmpImdbId = null
          } else {
            _tmpImdbId = _stmt.getText(_columnIndexOfImdbId)
          }
          val _tmpType: String
          _tmpType = _stmt.getText(_columnIndexOfType)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpYear: Int?
          if (_stmt.isNull(_columnIndexOfYear)) {
            _tmpYear = null
          } else {
            _tmpYear = _stmt.getLong(_columnIndexOfYear).toInt()
          }
          val _tmpOverview: String?
          if (_stmt.isNull(_columnIndexOfOverview)) {
            _tmpOverview = null
          } else {
            _tmpOverview = _stmt.getText(_columnIndexOfOverview)
          }
          val _tmpPosterPath: String?
          if (_stmt.isNull(_columnIndexOfPosterPath)) {
            _tmpPosterPath = null
          } else {
            _tmpPosterPath = _stmt.getText(_columnIndexOfPosterPath)
          }
          val _tmpBackdropPath: String?
          if (_stmt.isNull(_columnIndexOfBackdropPath)) {
            _tmpBackdropPath = null
          } else {
            _tmpBackdropPath = _stmt.getText(_columnIndexOfBackdropPath)
          }
          val _tmpRating: Double?
          if (_stmt.isNull(_columnIndexOfRating)) {
            _tmpRating = null
          } else {
            _tmpRating = _stmt.getDouble(_columnIndexOfRating)
          }
          val _tmpGenresJson: String?
          if (_stmt.isNull(_columnIndexOfGenresJson)) {
            _tmpGenresJson = null
          } else {
            _tmpGenresJson = _stmt.getText(_columnIndexOfGenresJson)
          }
          val _tmpCastJson: String?
          if (_stmt.isNull(_columnIndexOfCastJson)) {
            _tmpCastJson = null
          } else {
            _tmpCastJson = _stmt.getText(_columnIndexOfCastJson)
          }
          val _tmpTrailerKey: String?
          if (_stmt.isNull(_columnIndexOfTrailerKey)) {
            _tmpTrailerKey = null
          } else {
            _tmpTrailerKey = _stmt.getText(_columnIndexOfTrailerKey)
          }
          val _tmpLogoPath: String?
          if (_stmt.isNull(_columnIndexOfLogoPath)) {
            _tmpLogoPath = null
          } else {
            _tmpLogoPath = _stmt.getText(_columnIndexOfLogoPath)
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          val _tmpAirDate: String?
          if (_stmt.isNull(_columnIndexOfAirDate)) {
            _tmpAirDate = null
          } else {
            _tmpAirDate = _stmt.getText(_columnIndexOfAirDate)
          }
          val _tmpOriginalLanguage: String?
          if (_stmt.isNull(_columnIndexOfOriginalLanguage)) {
            _tmpOriginalLanguage = null
          } else {
            _tmpOriginalLanguage = _stmt.getText(_columnIndexOfOriginalLanguage)
          }
          _item_1 = MetadataCacheEntity(_tmpKey,_tmpTmdbId,_tmpImdbId,_tmpType,_tmpTitle,_tmpYear,_tmpOverview,_tmpPosterPath,_tmpBackdropPath,_tmpRating,_tmpGenresJson,_tmpCastJson,_tmpTrailerKey,_tmpLogoPath,_tmpUpdatedAt,_tmpAirDate,_tmpOriginalLanguage)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteMatch(localKey: String) {
    val _sql: String = "DELETE FROM metadata_match WHERE localKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, localKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteCache(key: String) {
    val _sql: String = "DELETE FROM metadata_cache WHERE key = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearCache() {
    val _sql: String = "DELETE FROM metadata_cache"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearMatches() {
    val _sql: String = "DELETE FROM metadata_match"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearNegativeMatches() {
    val _sql: String = "DELETE FROM metadata_match WHERE tmdbId IS NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun evictCacheOlderThan(cutoff: Long): Int {
    val _sql: String = "DELETE FROM metadata_cache WHERE updatedAt < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, cutoff)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun evictMatchesOlderThan(cutoff: Long): Int {
    val _sql: String = "DELETE FROM metadata_match WHERE updatedAt < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, cutoff)
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
