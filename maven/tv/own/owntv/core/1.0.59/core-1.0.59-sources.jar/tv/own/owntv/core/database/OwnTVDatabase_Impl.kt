package tv.own.owntv.core.database

import androidx.room.InvalidationTracker
import androidx.room.RoomOpenDelegate
import androidx.room.migration.AutoMigrationSpec
import androidx.room.migration.Migration
import androidx.room.util.FtsTableInfo
import androidx.room.util.TableInfo
import androidx.room.util.dropFtsSyncTriggers
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Lazy
import kotlin.String
import kotlin.Suppress
import kotlin.collections.List
import kotlin.collections.Map
import kotlin.collections.MutableList
import kotlin.collections.MutableMap
import kotlin.collections.MutableSet
import kotlin.collections.Set
import kotlin.collections.mutableListOf
import kotlin.collections.mutableMapOf
import kotlin.collections.mutableSetOf
import kotlin.reflect.KClass
import tv.own.owntv.core.database.dao.CatalogBackfillDao
import tv.own.owntv.core.database.dao.CatalogBackfillDao_Impl
import tv.own.owntv.core.database.dao.CategoryDao
import tv.own.owntv.core.database.dao.CategoryDao_Impl
import tv.own.owntv.core.database.dao.ChannelDao
import tv.own.owntv.core.database.dao.ChannelDao_Impl
import tv.own.owntv.core.database.dao.ContentOrderDao
import tv.own.owntv.core.database.dao.ContentOrderDao_Impl
import tv.own.owntv.core.database.dao.CustomCategoryDao
import tv.own.owntv.core.database.dao.CustomCategoryDao_Impl
import tv.own.owntv.core.database.dao.DownloadDao
import tv.own.owntv.core.database.dao.DownloadDao_Impl
import tv.own.owntv.core.database.dao.EpgDao
import tv.own.owntv.core.database.dao.EpgDao_Impl
import tv.own.owntv.core.database.dao.FavoriteDao
import tv.own.owntv.core.database.dao.FavoriteDao_Impl
import tv.own.owntv.core.database.dao.HistoryDao
import tv.own.owntv.core.database.dao.HistoryDao_Impl
import tv.own.owntv.core.database.dao.MetadataDao
import tv.own.owntv.core.database.dao.MetadataDao_Impl
import tv.own.owntv.core.database.dao.MovieDao
import tv.own.owntv.core.database.dao.MovieDao_Impl
import tv.own.owntv.core.database.dao.PlaybackPrefsDao
import tv.own.owntv.core.database.dao.PlaybackPrefsDao_Impl
import tv.own.owntv.core.database.dao.PlaybackQuirkDao
import tv.own.owntv.core.database.dao.PlaybackQuirkDao_Impl
import tv.own.owntv.core.database.dao.ProfileDao
import tv.own.owntv.core.database.dao.ProfileDao_Impl
import tv.own.owntv.core.database.dao.ProgressDao
import tv.own.owntv.core.database.dao.ProgressDao_Impl
import tv.own.owntv.core.database.dao.RecordingDao
import tv.own.owntv.core.database.dao.RecordingDao_Impl
import tv.own.owntv.core.database.dao.SeriesDao
import tv.own.owntv.core.database.dao.SeriesDao_Impl
import tv.own.owntv.core.database.dao.SeriesSortOrderDao
import tv.own.owntv.core.database.dao.SeriesSortOrderDao_Impl
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.dao.SourceDao_Impl
import tv.own.owntv.core.database.dao.SubtitleDao
import tv.own.owntv.core.database.dao.SubtitleDao_Impl
import tv.own.owntv.core.database.dao.TombstoneDao
import tv.own.owntv.core.database.dao.TombstoneDao_Impl
import tv.own.owntv.core.database.dao.TrendingDao
import tv.own.owntv.core.database.dao.TrendingDao_Impl
import tv.own.owntv.core.database.dao.TvProviderProgramDao
import tv.own.owntv.core.database.dao.TvProviderProgramDao_Impl
import androidx.room.util.FtsTableInfo.Companion.read as ftsTableInfoRead
import androidx.room.util.TableInfo.Companion.read as tableInfoRead

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class OwnTVDatabase_Impl : OwnTVDatabase() {
  private val _profileDao: Lazy<ProfileDao> = lazy {
    ProfileDao_Impl(this)
  }

  private val _sourceDao: Lazy<SourceDao> = lazy {
    SourceDao_Impl(this)
  }

  private val _categoryDao: Lazy<CategoryDao> = lazy {
    CategoryDao_Impl(this)
  }

  private val _channelDao: Lazy<ChannelDao> = lazy {
    ChannelDao_Impl(this)
  }

  private val _movieDao: Lazy<MovieDao> = lazy {
    MovieDao_Impl(this)
  }

  private val _seriesDao: Lazy<SeriesDao> = lazy {
    SeriesDao_Impl(this)
  }

  private val _favoriteDao: Lazy<FavoriteDao> = lazy {
    FavoriteDao_Impl(this)
  }

  private val _historyDao: Lazy<HistoryDao> = lazy {
    HistoryDao_Impl(this)
  }

  private val _progressDao: Lazy<ProgressDao> = lazy {
    ProgressDao_Impl(this)
  }

  private val _contentOrderDao: Lazy<ContentOrderDao> = lazy {
    ContentOrderDao_Impl(this)
  }

  private val _playbackPrefsDao: Lazy<PlaybackPrefsDao> = lazy {
    PlaybackPrefsDao_Impl(this)
  }

  private val _playbackQuirkDao: Lazy<PlaybackQuirkDao> = lazy {
    PlaybackQuirkDao_Impl(this)
  }

  private val _customCategoryDao: Lazy<CustomCategoryDao> = lazy {
    CustomCategoryDao_Impl(this)
  }

  private val _seriesSortOrderDao: Lazy<SeriesSortOrderDao> = lazy {
    SeriesSortOrderDao_Impl(this)
  }

  private val _tombstoneDao: Lazy<TombstoneDao> = lazy {
    TombstoneDao_Impl(this)
  }

  private val _tvProviderProgramDao: Lazy<TvProviderProgramDao> = lazy {
    TvProviderProgramDao_Impl(this)
  }

  private val _downloadDao: Lazy<DownloadDao> = lazy {
    DownloadDao_Impl(this)
  }

  private val _recordingDao: Lazy<RecordingDao> = lazy {
    RecordingDao_Impl(this)
  }

  private val _catalogBackfillDao: Lazy<CatalogBackfillDao> = lazy {
    CatalogBackfillDao_Impl(this)
  }

  private val _epgDao: Lazy<EpgDao> = lazy {
    EpgDao_Impl(this)
  }

  private val _metadataDao: Lazy<MetadataDao> = lazy {
    MetadataDao_Impl(this)
  }

  private val _trendingDao: Lazy<TrendingDao> = lazy {
    TrendingDao_Impl(this)
  }

  private val _subtitleDao: Lazy<SubtitleDao> = lazy {
    SubtitleDao_Impl(this)
  }

  protected override fun createOpenDelegate(): RoomOpenDelegate {
    val _openDelegate: RoomOpenDelegate = object : RoomOpenDelegate(46, "636314dffe6ba4eb6df1dbdd291a21b0", "b98dc0d2e5a667deae712d1632c6779a") {
      public override fun createAllTables(connection: SQLiteConnection) {
        connection.execSQL("CREATE TABLE IF NOT EXISTS `profiles` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `avatarColor` INTEGER NOT NULL, `avatarId` INTEGER NOT NULL, `avatarPath` TEXT, `isKids` INTEGER NOT NULL, `pinHash` TEXT, `createdAt` INTEGER NOT NULL)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `sources` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `url` TEXT NOT NULL, `username` TEXT, `password` TEXT, `mac` TEXT, `stalkerSerialNumber` TEXT, `stalkerDeviceId` TEXT, `stalkerDeviceId2` TEXT, `stalkerSignature` TEXT, `userAgent` TEXT, `epgUrl` TEXT, `syncLive` INTEGER NOT NULL, `syncMovies` INTEGER NOT NULL, `syncSeries` INTEGER NOT NULL, `importPortalEpg` INTEGER NOT NULL DEFAULT 1, `hlsSupported` INTEGER NOT NULL, `preferHls` INTEGER NOT NULL, `livePrerollSecs` INTEGER NOT NULL, `liveEnginePreference` TEXT, `liveLatencyMode` TEXT, `liveLatencyCustomSecs` INTEGER NOT NULL, `maxConnections` INTEGER NOT NULL, `maxConnectionsProbedAt` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `lastSyncAt` INTEGER, `catchupTimezone` TEXT, `catchupOffsetMin` INTEGER, `vodEnginePreference` TEXT, `liveTuneTimeoutSecs` INTEGER, `httpReferer` TEXT)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_sources_type` ON `sources` (`type`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `profile_source` (`profileId` INTEGER NOT NULL, `sourceId` INTEGER NOT NULL, PRIMARY KEY(`profileId`, `sourceId`), FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_profile_source_sourceId` ON `profile_source` (`sourceId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `categories` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `name` TEXT NOT NULL, `remoteId` TEXT, `sortOrder` INTEGER NOT NULL, FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_categories_sourceId` ON `categories` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_categories_sourceId_mediaType` ON `categories` (`sourceId`, `mediaType`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_categories_sourceId_mediaType_remoteId` ON `categories` (`sourceId`, `mediaType`, `remoteId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `channels` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `categoryId` INTEGER, `name` TEXT NOT NULL, `logoUrl` TEXT, `streamUrl` TEXT NOT NULL, `epgChannelId` TEXT, `number` INTEGER, `remoteId` TEXT, `sortOrder` INTEGER NOT NULL, `catchup` INTEGER NOT NULL, `catchupDays` INTEGER NOT NULL, `catchupSource` TEXT, `catchupType` TEXT, `httpHeaders` TEXT, `drmConfig` TEXT, `manifestType` TEXT, `directSource` TEXT, `contentHash` INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`categoryId`) REFERENCES `categories`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_sourceId` ON `channels` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_categoryId` ON `channels` (`categoryId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_name` ON `channels` (`name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_epgChannelId` ON `channels` (`epgChannelId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_channels_sourceId_remoteId` ON `channels` (`sourceId`, `remoteId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_sourceId_name` ON `channels` (`sourceId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_categoryId_name` ON `channels` (`categoryId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_sourceId_sortOrder_name` ON `channels` (`sourceId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_categoryId_sortOrder_name` ON `channels` (`categoryId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_channels_sourceId_number` ON `channels` (`sourceId`, `number`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `movies` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `categoryId` INTEGER, `name` TEXT NOT NULL, `posterUrl` TEXT, `backdropUrl` TEXT, `year` INTEGER, `rating` REAL, `durationSecs` INTEGER, `plot` TEXT, `streamUrl` TEXT NOT NULL, `containerExt` TEXT, `remoteId` TEXT, `addedAt` INTEGER, `sortOrder` INTEGER NOT NULL, `httpHeaders` TEXT, `drmConfig` TEXT, `manifestType` TEXT, `contentHash` INTEGER NOT NULL DEFAULT 0, `canonicalTitle` TEXT NOT NULL DEFAULT '', `titleSignature` TEXT NOT NULL DEFAULT '', `parsedYear` INTEGER, `providerLanguage` TEXT, `qualityRank` INTEGER NOT NULL DEFAULT 0, `advertisedCapabilities` TEXT, FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`categoryId`) REFERENCES `categories`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId` ON `movies` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_categoryId` ON `movies` (`categoryId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_name` ON `movies` (`name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId_name` ON `movies` (`sourceId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_categoryId_name` ON `movies` (`categoryId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId_sortOrder_name` ON `movies` (`sourceId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_categoryId_sortOrder_name` ON `movies` (`categoryId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_movies_sourceId_remoteId` ON `movies` (`sourceId`, `remoteId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId_rating_name` ON `movies` (`sourceId`, `rating`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_categoryId_rating_name` ON `movies` (`categoryId`, `rating`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId_addedAt_sortOrder` ON `movies` (`sourceId`, `addedAt`, `sortOrder`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_categoryId_addedAt_sortOrder` ON `movies` (`categoryId`, `addedAt`, `sortOrder`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_sourceId_titleSignature_parsedYear` ON `movies` (`sourceId`, `titleSignature`, `parsedYear`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `series` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `categoryId` INTEGER, `name` TEXT NOT NULL, `posterUrl` TEXT, `backdropUrl` TEXT, `year` INTEGER, `rating` REAL, `plot` TEXT, `remoteId` TEXT, `sortOrder` INTEGER NOT NULL, `contentHash` INTEGER NOT NULL DEFAULT 0, `addedAt` INTEGER, `episodesSyncedAt` INTEGER NOT NULL DEFAULT 0, `canonicalTitle` TEXT NOT NULL DEFAULT '', `titleSignature` TEXT NOT NULL DEFAULT '', `parsedYear` INTEGER, `providerLanguage` TEXT, `qualityRank` INTEGER NOT NULL DEFAULT 0, `advertisedCapabilities` TEXT, FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`categoryId`) REFERENCES `categories`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId` ON `series` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_categoryId` ON `series` (`categoryId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_name` ON `series` (`name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId_name` ON `series` (`sourceId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_categoryId_name` ON `series` (`categoryId`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId_sortOrder_name` ON `series` (`sourceId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_categoryId_sortOrder_name` ON `series` (`categoryId`, `sortOrder`, `name`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_series_sourceId_remoteId` ON `series` (`sourceId`, `remoteId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId_rating_name` ON `series` (`sourceId`, `rating`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_categoryId_rating_name` ON `series` (`categoryId`, `rating`, `name`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId_addedAt_sortOrder` ON `series` (`sourceId`, `addedAt`, `sortOrder`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_categoryId_addedAt_sortOrder` ON `series` (`categoryId`, `addedAt`, `sortOrder`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sourceId_titleSignature_parsedYear` ON `series` (`sourceId`, `titleSignature`, `parsedYear`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `seasons` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `seriesId` INTEGER NOT NULL, `seasonNumber` INTEGER NOT NULL, `name` TEXT, `remoteId` TEXT, FOREIGN KEY(`seriesId`) REFERENCES `series`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_seasons_seriesId` ON `seasons` (`seriesId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `episodes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `seriesId` INTEGER NOT NULL, `seasonId` INTEGER, `seasonNumber` INTEGER NOT NULL, `episodeNumber` INTEGER NOT NULL, `name` TEXT NOT NULL, `plot` TEXT, `streamUrl` TEXT NOT NULL, `durationSecs` INTEGER, `containerExt` TEXT, `remoteId` TEXT, `httpHeaders` TEXT, `drmConfig` TEXT, `manifestType` TEXT, `airDateMs` INTEGER, FOREIGN KEY(`seriesId`) REFERENCES `series`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`seasonId`) REFERENCES `seasons`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_episodes_seriesId` ON `episodes` (`seriesId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_episodes_seasonId` ON `episodes` (`seasonId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_episodes_name` ON `episodes` (`name`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_episodes_seriesId_remoteId` ON `episodes` (`seriesId`, `remoteId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `favorites` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `addedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_favorites_profileId` ON `favorites` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_favorites_profileId_mediaType_itemId` ON `favorites` (`profileId`, `mediaType`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `watch_history` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `watchedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_watch_history_profileId` ON `watch_history` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_watch_history_profileId_watchedAt` ON `watch_history` (`profileId`, `watchedAt`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_watch_history_profileId_mediaType_itemId` ON `watch_history` (`profileId`, `mediaType`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `playback_progress` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `positionMs` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_playback_progress_profileId` ON `playback_progress` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_playback_progress_profileId_mediaType_itemId` ON `playback_progress` (`profileId`, `mediaType`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `content_order` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `contextKey` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `position` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_content_order_profileId` ON `content_order` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_content_order_profileId_mediaType_contextKey` ON `content_order` (`profileId`, `mediaType`, `contextKey`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_content_order_profileId_mediaType_contextKey_itemId` ON `content_order` (`profileId`, `mediaType`, `contextKey`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `custom_category_members` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `contextKey` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `position` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_custom_category_members_profileId` ON `custom_category_members` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_custom_category_members_profileId_mediaType_contextKey` ON `custom_category_members` (`profileId`, `mediaType`, `contextKey`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_custom_category_members_profileId_mediaType_contextKey_itemId` ON `custom_category_members` (`profileId`, `mediaType`, `contextKey`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `playback_prefs` (`profileId` INTEGER NOT NULL, `contentKey` TEXT NOT NULL, `zoomMode` TEXT, `volumeBoost` INTEGER, `audioDelayMs` INTEGER, `updatedAt` INTEGER NOT NULL, `sourceId` INTEGER NOT NULL DEFAULT -1, `audioLang` TEXT, `subtitleLang` TEXT, PRIMARY KEY(`profileId`, `contentKey`), FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_playback_prefs_profileId` ON `playback_prefs` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_playback_prefs_sourceId` ON `playback_prefs` (`sourceId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `playback_quirks` (`contentKey` TEXT NOT NULL, `sourceId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `enginePin` TEXT, `audioOnly` INTEGER, `audioDelayMs` INTEGER, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`contentKey`))")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_playback_quirks_sourceId` ON `playback_quirks` (`sourceId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `series_sort_order` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `seriesId` INTEGER NOT NULL, `seasonsDescending` INTEGER NOT NULL, `episodesDescending` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_series_sort_order_profileId` ON `series_sort_order` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_series_sort_order_profileId_seriesId` ON `series_sort_order` (`profileId`, `seriesId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `user_data_tombstones` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `kind` TEXT NOT NULL, `identity` TEXT NOT NULL, `deletedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_user_data_tombstones_profileId` ON `user_data_tombstones` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_user_data_tombstones_profileId_kind_identity` ON `user_data_tombstones` (`profileId`, `kind`, `identity`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_user_data_tombstones_deletedAt` ON `user_data_tombstones` (`deletedAt`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `downloads` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `itemId` INTEGER NOT NULL, `title` TEXT NOT NULL, `posterUrl` TEXT, `streamUrl` TEXT NOT NULL, `filePath` TEXT, `status` TEXT NOT NULL, `downloadedBytes` INTEGER NOT NULL, `totalBytes` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_downloads_profileId` ON `downloads` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_downloads_status` ON `downloads` (`status`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_downloads_profileId_mediaType_itemId` ON `downloads` (`profileId`, `mediaType`, `itemId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `recordings` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `sourceId` INTEGER NOT NULL, `channelId` INTEGER NOT NULL, `channelName` TEXT NOT NULL, `channelIconUrl` TEXT, `epgChannelId` TEXT, `streamUrl` TEXT NOT NULL, `httpHeaders` TEXT, `title` TEXT NOT NULL, `description` TEXT, `programmeStartMs` INTEGER NOT NULL, `programmeStopMs` INTEGER NOT NULL, `startMs` INTEGER NOT NULL, `stopMs` INTEGER NOT NULL, `status` TEXT NOT NULL, `failure` TEXT NOT NULL, `filePath` TEXT, `bytes` INTEGER NOT NULL, `startedAt` INTEGER, `endedAt` INTEGER, `ruleId` INTEGER, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_profileId` ON `recordings` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_status` ON `recordings` (`status`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_startMs_stopMs` ON `recordings` (`startMs`, `stopMs`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_sourceId` ON `recordings` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recordings_ruleId` ON `recordings` (`ruleId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_recordings_profileId_channelId_programmeStartMs` ON `recordings` (`profileId`, `channelId`, `programmeStartMs`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `catalog_backfill` (`sourceId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `categoryRemoteId` TEXT NOT NULL, `categoryDbId` INTEGER, `totalItems` INTEGER NOT NULL, `maxPageItems` INTEGER NOT NULL, `nextPage` INTEGER NOT NULL, `lastPage` INTEGER NOT NULL, `sortBase` INTEGER NOT NULL, `done` INTEGER NOT NULL, PRIMARY KEY(`sourceId`, `mediaType`, `categoryRemoteId`), FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_catalog_backfill_sourceId` ON `catalog_backfill` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_catalog_backfill_sourceId_mediaType_done` ON `catalog_backfill` (`sourceId`, `mediaType`, `done`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `recording_rules` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `sourceId` INTEGER NOT NULL, `channelId` INTEGER NOT NULL, `channelName` TEXT NOT NULL, `epgChannelId` TEXT, `title` TEXT NOT NULL, `titleKey` TEXT NOT NULL, `enabled` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_recording_rules_profileId` ON `recording_rules` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_recording_rules_profileId_channelId_titleKey` ON `recording_rules` (`profileId`, `channelId`, `titleKey`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `tv_provider_programs` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `profileId` INTEGER NOT NULL, `surface` TEXT NOT NULL, `mediaType` TEXT NOT NULL, `groupId` INTEGER NOT NULL, `targetItemId` INTEGER NOT NULL, `providerProgramId` INTEGER, `lastPositionMs` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, `lastEngagementAt` INTEGER NOT NULL, `lastPublishedAt` INTEGER NOT NULL, FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_tv_provider_programs_profileId` ON `tv_provider_programs` (`profileId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_tv_provider_programs_profileId_surface_mediaType_groupId` ON `tv_provider_programs` (`profileId`, `surface`, `mediaType`, `groupId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `epg_channels` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `epgChannelId` TEXT NOT NULL, `displayName` TEXT, `iconUrl` TEXT, `normName` TEXT, `normId` TEXT)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_channels_sourceId` ON `epg_channels` (`sourceId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_epg_channels_sourceId_epgChannelId` ON `epg_channels` (`sourceId`, `epgChannelId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_channels_normName` ON `epg_channels` (`normName`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `epg_programmes` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `sourceId` INTEGER NOT NULL, `epgChannelId` TEXT NOT NULL, `startMs` INTEGER NOT NULL, `stopMs` INTEGER NOT NULL, `title` TEXT NOT NULL, `description` TEXT, `contentHash` INTEGER NOT NULL DEFAULT 0)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_programmes_epgChannelId_startMs` ON `epg_programmes` (`epgChannelId`, `startMs`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_programmes_sourceId` ON `epg_programmes` (`sourceId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_programmes_stopMs` ON `epg_programmes` (`stopMs`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_programmes_startMs_stopMs` ON `epg_programmes` (`startMs`, `stopMs`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_epg_programmes_sourceId_epgChannelId` ON `epg_programmes` (`sourceId`, `epgChannelId`)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_epg_programmes_natural_key` ON `epg_programmes` (`sourceId`, `epgChannelId`, `startMs`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `metadata_cache` (`key` TEXT NOT NULL, `tmdbId` INTEGER NOT NULL, `imdbId` TEXT, `type` TEXT NOT NULL, `title` TEXT NOT NULL, `year` INTEGER, `overview` TEXT, `posterPath` TEXT, `backdropPath` TEXT, `rating` REAL, `genresJson` TEXT, `castJson` TEXT, `trailerKey` TEXT, `logoPath` TEXT, `updatedAt` INTEGER NOT NULL, `airDate` TEXT, `originalLanguage` TEXT, PRIMARY KEY(`key`))")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_metadata_cache_tmdbId` ON `metadata_cache` (`tmdbId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_metadata_cache_updatedAt` ON `metadata_cache` (`updatedAt`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `metadata_match` (`localKey` TEXT NOT NULL, `type` TEXT NOT NULL, `tmdbId` INTEGER, `confidence` REAL NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`localKey`))")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_metadata_match_updatedAt` ON `metadata_match` (`updatedAt`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `trending_snapshots` (`sourceId` INTEGER NOT NULL, `status` TEXT NOT NULL, `metadataLanguage` TEXT NOT NULL, `refreshedAt` INTEGER NOT NULL, `candidateFetchedAt` INTEGER NOT NULL, `generationId` TEXT NOT NULL, `itemCount` INTEGER NOT NULL, `matchedItemCount` INTEGER NOT NULL DEFAULT 0, `lastAttemptAt` INTEGER NOT NULL DEFAULT 0, `lastAttemptStatus` TEXT NOT NULL DEFAULT 'NEVER', `failureStage` TEXT, PRIMARY KEY(`sourceId`), FOREIGN KEY(`sourceId`) REFERENCES `sources`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `trending_items` (`sourceId` INTEGER NOT NULL, `position` INTEGER NOT NULL, `tmdbId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `trendingRank` INTEGER NOT NULL, `providerItemId` INTEGER NOT NULL, `providerRemoteId` TEXT, `providerStableKey` TEXT NOT NULL, `providerRawName` TEXT NOT NULL, `canonicalTitle` TEXT NOT NULL, `providerLanguage` TEXT, `advertisedQuality` TEXT, `advertisedCapabilities` TEXT, `localizedTitle` TEXT NOT NULL, `originalTitle` TEXT, `year` INTEGER, `overview` TEXT, `posterPath` TEXT, `backdropPath` TEXT, `rating` REAL, `trailerKey` TEXT, `generationId` TEXT NOT NULL, `refreshedAt` INTEGER NOT NULL, PRIMARY KEY(`sourceId`, `position`), FOREIGN KEY(`sourceId`) REFERENCES `trending_snapshots`(`sourceId`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_trending_items_sourceId_mediaType_providerItemId` ON `trending_items` (`sourceId`, `mediaType`, `providerItemId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_trending_items_mediaType_tmdbId` ON `trending_items` (`mediaType`, `tmdbId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `subtitle_cache` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `source` TEXT NOT NULL, `openSubFileId` INTEGER, `language` TEXT, `languageName` TEXT, `releaseName` TEXT, `format` TEXT, `hearingImpaired` INTEGER NOT NULL, `fileName` TEXT NOT NULL, `cachedPath` TEXT NOT NULL, `lastUsedAt` INTEGER NOT NULL)")
        connection.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_subtitle_cache_openSubFileId` ON `subtitle_cache` (`openSubFileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_cache_lastUsedAt` ON `subtitle_cache` (`lastUsedAt`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `subtitle_selection` (`profileId` INTEGER NOT NULL, `contentKey` TEXT NOT NULL, `cacheId` INTEGER, `off` INTEGER NOT NULL DEFAULT 0, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`profileId`, `contentKey`), FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`cacheId`) REFERENCES `subtitle_cache`(`id`) ON UPDATE NO ACTION ON DELETE SET NULL )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_selection_profileId` ON `subtitle_selection` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_selection_cacheId` ON `subtitle_selection` (`cacheId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `subtitle_timing` (`profileId` INTEGER NOT NULL, `contentKey` TEXT NOT NULL, `subtitleKey` TEXT NOT NULL, `offsetMs` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`profileId`, `contentKey`, `subtitleKey`), FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_timing_profileId` ON `subtitle_timing` (`profileId`)")
        connection.execSQL("CREATE TABLE IF NOT EXISTS `subtitle_link` (`profileId` INTEGER NOT NULL, `contentKey` TEXT NOT NULL, `cacheId` INTEGER NOT NULL, `mediaType` TEXT NOT NULL, `contentTitle` TEXT NOT NULL, `addedAt` INTEGER NOT NULL, PRIMARY KEY(`profileId`, `contentKey`, `cacheId`), FOREIGN KEY(`profileId`) REFERENCES `profiles`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`cacheId`) REFERENCES `subtitle_cache`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_link_profileId` ON `subtitle_link` (`profileId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_link_cacheId` ON `subtitle_link` (`cacheId`)")
        connection.execSQL("CREATE INDEX IF NOT EXISTS `index_subtitle_link_profileId_mediaType` ON `subtitle_link` (`profileId`, `mediaType`)")
        connection.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS `channels_fts` USING FTS4(`name` TEXT NOT NULL, content=`channels`)")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_BEFORE_UPDATE BEFORE UPDATE ON `channels` BEGIN DELETE FROM `channels_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_BEFORE_DELETE BEFORE DELETE ON `channels` BEGIN DELETE FROM `channels_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_AFTER_UPDATE AFTER UPDATE ON `channels` BEGIN INSERT INTO `channels_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_AFTER_INSERT AFTER INSERT ON `channels` BEGIN INSERT INTO `channels_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS `movies_fts` USING FTS4(`name` TEXT NOT NULL, content=`movies`)")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_BEFORE_UPDATE BEFORE UPDATE ON `movies` BEGIN DELETE FROM `movies_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_BEFORE_DELETE BEFORE DELETE ON `movies` BEGIN DELETE FROM `movies_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_AFTER_UPDATE AFTER UPDATE ON `movies` BEGIN INSERT INTO `movies_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_AFTER_INSERT AFTER INSERT ON `movies` BEGIN INSERT INTO `movies_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS `series_fts` USING FTS4(`name` TEXT NOT NULL, content=`series`)")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_BEFORE_UPDATE BEFORE UPDATE ON `series` BEGIN DELETE FROM `series_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_BEFORE_DELETE BEFORE DELETE ON `series` BEGIN DELETE FROM `series_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_AFTER_UPDATE AFTER UPDATE ON `series` BEGIN INSERT INTO `series_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_AFTER_INSERT AFTER INSERT ON `series` BEGIN INSERT INTO `series_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS `episodes_fts` USING FTS4(`name` TEXT NOT NULL, content=`episodes`)")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_BEFORE_UPDATE BEFORE UPDATE ON `episodes` BEGIN DELETE FROM `episodes_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_BEFORE_DELETE BEFORE DELETE ON `episodes` BEGIN DELETE FROM `episodes_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_AFTER_UPDATE AFTER UPDATE ON `episodes` BEGIN INSERT INTO `episodes_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_AFTER_INSERT AFTER INSERT ON `episodes` BEGIN INSERT INTO `episodes_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)")
        connection.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '636314dffe6ba4eb6df1dbdd291a21b0')")
      }

      public override fun dropAllTables(connection: SQLiteConnection) {
        connection.execSQL("DROP TABLE IF EXISTS `profiles`")
        connection.execSQL("DROP TABLE IF EXISTS `sources`")
        connection.execSQL("DROP TABLE IF EXISTS `profile_source`")
        connection.execSQL("DROP TABLE IF EXISTS `categories`")
        connection.execSQL("DROP TABLE IF EXISTS `channels`")
        connection.execSQL("DROP TABLE IF EXISTS `movies`")
        connection.execSQL("DROP TABLE IF EXISTS `series`")
        connection.execSQL("DROP TABLE IF EXISTS `seasons`")
        connection.execSQL("DROP TABLE IF EXISTS `episodes`")
        connection.execSQL("DROP TABLE IF EXISTS `favorites`")
        connection.execSQL("DROP TABLE IF EXISTS `watch_history`")
        connection.execSQL("DROP TABLE IF EXISTS `playback_progress`")
        connection.execSQL("DROP TABLE IF EXISTS `content_order`")
        connection.execSQL("DROP TABLE IF EXISTS `custom_category_members`")
        connection.execSQL("DROP TABLE IF EXISTS `playback_prefs`")
        connection.execSQL("DROP TABLE IF EXISTS `playback_quirks`")
        connection.execSQL("DROP TABLE IF EXISTS `series_sort_order`")
        connection.execSQL("DROP TABLE IF EXISTS `user_data_tombstones`")
        connection.execSQL("DROP TABLE IF EXISTS `downloads`")
        connection.execSQL("DROP TABLE IF EXISTS `recordings`")
        connection.execSQL("DROP TABLE IF EXISTS `catalog_backfill`")
        connection.execSQL("DROP TABLE IF EXISTS `recording_rules`")
        connection.execSQL("DROP TABLE IF EXISTS `tv_provider_programs`")
        connection.execSQL("DROP TABLE IF EXISTS `epg_channels`")
        connection.execSQL("DROP TABLE IF EXISTS `epg_programmes`")
        connection.execSQL("DROP TABLE IF EXISTS `metadata_cache`")
        connection.execSQL("DROP TABLE IF EXISTS `metadata_match`")
        connection.execSQL("DROP TABLE IF EXISTS `trending_snapshots`")
        connection.execSQL("DROP TABLE IF EXISTS `trending_items`")
        connection.execSQL("DROP TABLE IF EXISTS `subtitle_cache`")
        connection.execSQL("DROP TABLE IF EXISTS `subtitle_selection`")
        connection.execSQL("DROP TABLE IF EXISTS `subtitle_timing`")
        connection.execSQL("DROP TABLE IF EXISTS `subtitle_link`")
        connection.execSQL("DROP TABLE IF EXISTS `channels_fts`")
        connection.execSQL("DROP TABLE IF EXISTS `movies_fts`")
        connection.execSQL("DROP TABLE IF EXISTS `series_fts`")
        connection.execSQL("DROP TABLE IF EXISTS `episodes_fts`")
      }

      public override fun onCreate(connection: SQLiteConnection) {
      }

      public override fun onOpen(connection: SQLiteConnection) {
        connection.execSQL("PRAGMA foreign_keys = ON")
        internalInitInvalidationTracker(connection)
      }

      public override fun onPreMigrate(connection: SQLiteConnection) {
        dropFtsSyncTriggers(connection)
      }

      public override fun onPostMigrate(connection: SQLiteConnection) {
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_BEFORE_UPDATE BEFORE UPDATE ON `channels` BEGIN DELETE FROM `channels_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_BEFORE_DELETE BEFORE DELETE ON `channels` BEGIN DELETE FROM `channels_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_AFTER_UPDATE AFTER UPDATE ON `channels` BEGIN INSERT INTO `channels_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_channels_fts_AFTER_INSERT AFTER INSERT ON `channels` BEGIN INSERT INTO `channels_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_BEFORE_UPDATE BEFORE UPDATE ON `movies` BEGIN DELETE FROM `movies_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_BEFORE_DELETE BEFORE DELETE ON `movies` BEGIN DELETE FROM `movies_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_AFTER_UPDATE AFTER UPDATE ON `movies` BEGIN INSERT INTO `movies_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_movies_fts_AFTER_INSERT AFTER INSERT ON `movies` BEGIN INSERT INTO `movies_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_BEFORE_UPDATE BEFORE UPDATE ON `series` BEGIN DELETE FROM `series_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_BEFORE_DELETE BEFORE DELETE ON `series` BEGIN DELETE FROM `series_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_AFTER_UPDATE AFTER UPDATE ON `series` BEGIN INSERT INTO `series_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_series_fts_AFTER_INSERT AFTER INSERT ON `series` BEGIN INSERT INTO `series_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_BEFORE_UPDATE BEFORE UPDATE ON `episodes` BEGIN DELETE FROM `episodes_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_BEFORE_DELETE BEFORE DELETE ON `episodes` BEGIN DELETE FROM `episodes_fts` WHERE `docid`=OLD.`rowid`; END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_AFTER_UPDATE AFTER UPDATE ON `episodes` BEGIN INSERT INTO `episodes_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
        connection.execSQL("CREATE TRIGGER IF NOT EXISTS room_fts_content_sync_episodes_fts_AFTER_INSERT AFTER INSERT ON `episodes` BEGIN INSERT INTO `episodes_fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END")
      }

      public override fun onValidateSchema(connection: SQLiteConnection): RoomOpenDelegate.ValidationResult {
        val _columnsProfiles: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsProfiles.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("avatarColor", TableInfo.Column("avatarColor", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("avatarId", TableInfo.Column("avatarId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("avatarPath", TableInfo.Column("avatarPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("isKids", TableInfo.Column("isKids", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("pinHash", TableInfo.Column("pinHash", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfiles.put("createdAt", TableInfo.Column("createdAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysProfiles: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesProfiles: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoProfiles: TableInfo = TableInfo("profiles", _columnsProfiles, _foreignKeysProfiles, _indicesProfiles)
        val _existingProfiles: TableInfo = tableInfoRead(connection, "profiles")
        if (!_infoProfiles.equals(_existingProfiles)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |profiles(tv.own.owntv.core.database.entity.ProfileEntity).
              | Expected:
              |""".trimMargin() + _infoProfiles + """
              |
              | Found:
              |""".trimMargin() + _existingProfiles)
        }
        val _columnsSources: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSources.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("type", TableInfo.Column("type", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("url", TableInfo.Column("url", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("username", TableInfo.Column("username", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("password", TableInfo.Column("password", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("mac", TableInfo.Column("mac", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("stalkerSerialNumber", TableInfo.Column("stalkerSerialNumber", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("stalkerDeviceId", TableInfo.Column("stalkerDeviceId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("stalkerDeviceId2", TableInfo.Column("stalkerDeviceId2", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("stalkerSignature", TableInfo.Column("stalkerSignature", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("userAgent", TableInfo.Column("userAgent", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("epgUrl", TableInfo.Column("epgUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("syncLive", TableInfo.Column("syncLive", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("syncMovies", TableInfo.Column("syncMovies", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("syncSeries", TableInfo.Column("syncSeries", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("importPortalEpg", TableInfo.Column("importPortalEpg", "INTEGER", true, 0, "1", TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("hlsSupported", TableInfo.Column("hlsSupported", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("preferHls", TableInfo.Column("preferHls", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("livePrerollSecs", TableInfo.Column("livePrerollSecs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("liveEnginePreference", TableInfo.Column("liveEnginePreference", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("liveLatencyMode", TableInfo.Column("liveLatencyMode", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("liveLatencyCustomSecs", TableInfo.Column("liveLatencyCustomSecs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("maxConnections", TableInfo.Column("maxConnections", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("maxConnectionsProbedAt", TableInfo.Column("maxConnectionsProbedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("createdAt", TableInfo.Column("createdAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("lastSyncAt", TableInfo.Column("lastSyncAt", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("catchupTimezone", TableInfo.Column("catchupTimezone", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("catchupOffsetMin", TableInfo.Column("catchupOffsetMin", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("vodEnginePreference", TableInfo.Column("vodEnginePreference", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("liveTuneTimeoutSecs", TableInfo.Column("liveTuneTimeoutSecs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSources.put("httpReferer", TableInfo.Column("httpReferer", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSources: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesSources: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSources.add(TableInfo.Index("index_sources_type", false, listOf("type"), listOf("ASC")))
        val _infoSources: TableInfo = TableInfo("sources", _columnsSources, _foreignKeysSources, _indicesSources)
        val _existingSources: TableInfo = tableInfoRead(connection, "sources")
        if (!_infoSources.equals(_existingSources)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |sources(tv.own.owntv.core.database.entity.SourceEntity).
              | Expected:
              |""".trimMargin() + _infoSources + """
              |
              | Found:
              |""".trimMargin() + _existingSources)
        }
        val _columnsProfileSource: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsProfileSource.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsProfileSource.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysProfileSource: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysProfileSource.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        _foreignKeysProfileSource.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        val _indicesProfileSource: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesProfileSource.add(TableInfo.Index("index_profile_source_sourceId", false, listOf("sourceId"), listOf("ASC")))
        val _infoProfileSource: TableInfo = TableInfo("profile_source", _columnsProfileSource, _foreignKeysProfileSource, _indicesProfileSource)
        val _existingProfileSource: TableInfo = tableInfoRead(connection, "profile_source")
        if (!_infoProfileSource.equals(_existingProfileSource)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |profile_source(tv.own.owntv.core.database.entity.ProfileSourceCrossRef).
              | Expected:
              |""".trimMargin() + _infoProfileSource + """
              |
              | Found:
              |""".trimMargin() + _existingProfileSource)
        }
        val _columnsCategories: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsCategories.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCategories.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCategories.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCategories.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCategories.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCategories.put("sortOrder", TableInfo.Column("sortOrder", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysCategories: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysCategories.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        val _indicesCategories: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesCategories.add(TableInfo.Index("index_categories_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesCategories.add(TableInfo.Index("index_categories_sourceId_mediaType", false, listOf("sourceId", "mediaType"), listOf("ASC", "ASC")))
        _indicesCategories.add(TableInfo.Index("index_categories_sourceId_mediaType_remoteId", true, listOf("sourceId", "mediaType", "remoteId"), listOf("ASC", "ASC", "ASC")))
        val _infoCategories: TableInfo = TableInfo("categories", _columnsCategories, _foreignKeysCategories, _indicesCategories)
        val _existingCategories: TableInfo = tableInfoRead(connection, "categories")
        if (!_infoCategories.equals(_existingCategories)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |categories(tv.own.owntv.core.database.entity.CategoryEntity).
              | Expected:
              |""".trimMargin() + _infoCategories + """
              |
              | Found:
              |""".trimMargin() + _existingCategories)
        }
        val _columnsChannels: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsChannels.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("categoryId", TableInfo.Column("categoryId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("logoUrl", TableInfo.Column("logoUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("streamUrl", TableInfo.Column("streamUrl", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("epgChannelId", TableInfo.Column("epgChannelId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("number", TableInfo.Column("number", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("sortOrder", TableInfo.Column("sortOrder", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("catchup", TableInfo.Column("catchup", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("catchupDays", TableInfo.Column("catchupDays", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("catchupSource", TableInfo.Column("catchupSource", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("catchupType", TableInfo.Column("catchupType", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("httpHeaders", TableInfo.Column("httpHeaders", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("drmConfig", TableInfo.Column("drmConfig", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("manifestType", TableInfo.Column("manifestType", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("directSource", TableInfo.Column("directSource", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsChannels.put("contentHash", TableInfo.Column("contentHash", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysChannels: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysChannels.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        _foreignKeysChannels.add(TableInfo.ForeignKey("categories", "SET NULL", "NO ACTION", listOf("categoryId"), listOf("id")))
        val _indicesChannels: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesChannels.add(TableInfo.Index("index_channels_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_categoryId", false, listOf("categoryId"), listOf("ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_name", false, listOf("name"), listOf("ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_epgChannelId", false, listOf("epgChannelId"), listOf("ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_sourceId_remoteId", true, listOf("sourceId", "remoteId"), listOf("ASC", "ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_sourceId_name", false, listOf("sourceId", "name"), listOf("ASC", "ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_categoryId_name", false, listOf("categoryId", "name"), listOf("ASC", "ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_sourceId_sortOrder_name", false, listOf("sourceId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_categoryId_sortOrder_name", false, listOf("categoryId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesChannels.add(TableInfo.Index("index_channels_sourceId_number", false, listOf("sourceId", "number"), listOf("ASC", "ASC")))
        val _infoChannels: TableInfo = TableInfo("channels", _columnsChannels, _foreignKeysChannels, _indicesChannels)
        val _existingChannels: TableInfo = tableInfoRead(connection, "channels")
        if (!_infoChannels.equals(_existingChannels)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |channels(tv.own.owntv.core.database.entity.ChannelEntity).
              | Expected:
              |""".trimMargin() + _infoChannels + """
              |
              | Found:
              |""".trimMargin() + _existingChannels)
        }
        val _columnsMovies: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMovies.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("categoryId", TableInfo.Column("categoryId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("posterUrl", TableInfo.Column("posterUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("backdropUrl", TableInfo.Column("backdropUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("year", TableInfo.Column("year", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("rating", TableInfo.Column("rating", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("durationSecs", TableInfo.Column("durationSecs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("plot", TableInfo.Column("plot", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("streamUrl", TableInfo.Column("streamUrl", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("containerExt", TableInfo.Column("containerExt", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("addedAt", TableInfo.Column("addedAt", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("sortOrder", TableInfo.Column("sortOrder", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("httpHeaders", TableInfo.Column("httpHeaders", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("drmConfig", TableInfo.Column("drmConfig", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("manifestType", TableInfo.Column("manifestType", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("contentHash", TableInfo.Column("contentHash", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("canonicalTitle", TableInfo.Column("canonicalTitle", "TEXT", true, 0, "''", TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("titleSignature", TableInfo.Column("titleSignature", "TEXT", true, 0, "''", TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("parsedYear", TableInfo.Column("parsedYear", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("providerLanguage", TableInfo.Column("providerLanguage", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("qualityRank", TableInfo.Column("qualityRank", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsMovies.put("advertisedCapabilities", TableInfo.Column("advertisedCapabilities", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMovies: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysMovies.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        _foreignKeysMovies.add(TableInfo.ForeignKey("categories", "SET NULL", "NO ACTION", listOf("categoryId"), listOf("id")))
        val _indicesMovies: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_categoryId", false, listOf("categoryId"), listOf("ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_name", false, listOf("name"), listOf("ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_name", false, listOf("sourceId", "name"), listOf("ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_categoryId_name", false, listOf("categoryId", "name"), listOf("ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_sortOrder_name", false, listOf("sourceId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_categoryId_sortOrder_name", false, listOf("categoryId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_remoteId", true, listOf("sourceId", "remoteId"), listOf("ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_rating_name", false, listOf("sourceId", "rating", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_categoryId_rating_name", false, listOf("categoryId", "rating", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_addedAt_sortOrder", false, listOf("sourceId", "addedAt", "sortOrder"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_categoryId_addedAt_sortOrder", false, listOf("categoryId", "addedAt", "sortOrder"), listOf("ASC", "ASC", "ASC")))
        _indicesMovies.add(TableInfo.Index("index_movies_sourceId_titleSignature_parsedYear", false, listOf("sourceId", "titleSignature", "parsedYear"), listOf("ASC", "ASC", "ASC")))
        val _infoMovies: TableInfo = TableInfo("movies", _columnsMovies, _foreignKeysMovies, _indicesMovies)
        val _existingMovies: TableInfo = tableInfoRead(connection, "movies")
        if (!_infoMovies.equals(_existingMovies)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |movies(tv.own.owntv.core.database.entity.MovieEntity).
              | Expected:
              |""".trimMargin() + _infoMovies + """
              |
              | Found:
              |""".trimMargin() + _existingMovies)
        }
        val _columnsSeries: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSeries.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("categoryId", TableInfo.Column("categoryId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("posterUrl", TableInfo.Column("posterUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("backdropUrl", TableInfo.Column("backdropUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("year", TableInfo.Column("year", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("rating", TableInfo.Column("rating", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("plot", TableInfo.Column("plot", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("sortOrder", TableInfo.Column("sortOrder", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("contentHash", TableInfo.Column("contentHash", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("addedAt", TableInfo.Column("addedAt", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("episodesSyncedAt", TableInfo.Column("episodesSyncedAt", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("canonicalTitle", TableInfo.Column("canonicalTitle", "TEXT", true, 0, "''", TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("titleSignature", TableInfo.Column("titleSignature", "TEXT", true, 0, "''", TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("parsedYear", TableInfo.Column("parsedYear", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("providerLanguage", TableInfo.Column("providerLanguage", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("qualityRank", TableInfo.Column("qualityRank", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsSeries.put("advertisedCapabilities", TableInfo.Column("advertisedCapabilities", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSeries: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSeries.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        _foreignKeysSeries.add(TableInfo.ForeignKey("categories", "SET NULL", "NO ACTION", listOf("categoryId"), listOf("id")))
        val _indicesSeries: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSeries.add(TableInfo.Index("index_series_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_categoryId", false, listOf("categoryId"), listOf("ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_name", false, listOf("name"), listOf("ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_name", false, listOf("sourceId", "name"), listOf("ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_categoryId_name", false, listOf("categoryId", "name"), listOf("ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_sortOrder_name", false, listOf("sourceId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_categoryId_sortOrder_name", false, listOf("categoryId", "sortOrder", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_remoteId", true, listOf("sourceId", "remoteId"), listOf("ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_rating_name", false, listOf("sourceId", "rating", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_categoryId_rating_name", false, listOf("categoryId", "rating", "name"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_addedAt_sortOrder", false, listOf("sourceId", "addedAt", "sortOrder"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_categoryId_addedAt_sortOrder", false, listOf("categoryId", "addedAt", "sortOrder"), listOf("ASC", "ASC", "ASC")))
        _indicesSeries.add(TableInfo.Index("index_series_sourceId_titleSignature_parsedYear", false, listOf("sourceId", "titleSignature", "parsedYear"), listOf("ASC", "ASC", "ASC")))
        val _infoSeries: TableInfo = TableInfo("series", _columnsSeries, _foreignKeysSeries, _indicesSeries)
        val _existingSeries: TableInfo = tableInfoRead(connection, "series")
        if (!_infoSeries.equals(_existingSeries)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |series(tv.own.owntv.core.database.entity.SeriesEntity).
              | Expected:
              |""".trimMargin() + _infoSeries + """
              |
              | Found:
              |""".trimMargin() + _existingSeries)
        }
        val _columnsSeasons: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSeasons.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeasons.put("seriesId", TableInfo.Column("seriesId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeasons.put("seasonNumber", TableInfo.Column("seasonNumber", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeasons.put("name", TableInfo.Column("name", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeasons.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSeasons: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSeasons.add(TableInfo.ForeignKey("series", "CASCADE", "NO ACTION", listOf("seriesId"), listOf("id")))
        val _indicesSeasons: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSeasons.add(TableInfo.Index("index_seasons_seriesId", false, listOf("seriesId"), listOf("ASC")))
        val _infoSeasons: TableInfo = TableInfo("seasons", _columnsSeasons, _foreignKeysSeasons, _indicesSeasons)
        val _existingSeasons: TableInfo = tableInfoRead(connection, "seasons")
        if (!_infoSeasons.equals(_existingSeasons)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |seasons(tv.own.owntv.core.database.entity.SeasonEntity).
              | Expected:
              |""".trimMargin() + _infoSeasons + """
              |
              | Found:
              |""".trimMargin() + _existingSeasons)
        }
        val _columnsEpisodes: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEpisodes.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("seriesId", TableInfo.Column("seriesId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("seasonId", TableInfo.Column("seasonId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("seasonNumber", TableInfo.Column("seasonNumber", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("episodeNumber", TableInfo.Column("episodeNumber", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("name", TableInfo.Column("name", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("plot", TableInfo.Column("plot", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("streamUrl", TableInfo.Column("streamUrl", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("durationSecs", TableInfo.Column("durationSecs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("containerExt", TableInfo.Column("containerExt", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("remoteId", TableInfo.Column("remoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("httpHeaders", TableInfo.Column("httpHeaders", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("drmConfig", TableInfo.Column("drmConfig", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("manifestType", TableInfo.Column("manifestType", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpisodes.put("airDateMs", TableInfo.Column("airDateMs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEpisodes: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysEpisodes.add(TableInfo.ForeignKey("series", "CASCADE", "NO ACTION", listOf("seriesId"), listOf("id")))
        _foreignKeysEpisodes.add(TableInfo.ForeignKey("seasons", "CASCADE", "NO ACTION", listOf("seasonId"), listOf("id")))
        val _indicesEpisodes: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesEpisodes.add(TableInfo.Index("index_episodes_seriesId", false, listOf("seriesId"), listOf("ASC")))
        _indicesEpisodes.add(TableInfo.Index("index_episodes_seasonId", false, listOf("seasonId"), listOf("ASC")))
        _indicesEpisodes.add(TableInfo.Index("index_episodes_name", false, listOf("name"), listOf("ASC")))
        _indicesEpisodes.add(TableInfo.Index("index_episodes_seriesId_remoteId", true, listOf("seriesId", "remoteId"), listOf("ASC", "ASC")))
        val _infoEpisodes: TableInfo = TableInfo("episodes", _columnsEpisodes, _foreignKeysEpisodes, _indicesEpisodes)
        val _existingEpisodes: TableInfo = tableInfoRead(connection, "episodes")
        if (!_infoEpisodes.equals(_existingEpisodes)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |episodes(tv.own.owntv.core.database.entity.EpisodeEntity).
              | Expected:
              |""".trimMargin() + _infoEpisodes + """
              |
              | Found:
              |""".trimMargin() + _existingEpisodes)
        }
        val _columnsFavorites: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsFavorites.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsFavorites.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsFavorites.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsFavorites.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsFavorites.put("addedAt", TableInfo.Column("addedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysFavorites: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysFavorites.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesFavorites: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesFavorites.add(TableInfo.Index("index_favorites_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesFavorites.add(TableInfo.Index("index_favorites_profileId_mediaType_itemId", true, listOf("profileId", "mediaType", "itemId"), listOf("ASC", "ASC", "ASC")))
        val _infoFavorites: TableInfo = TableInfo("favorites", _columnsFavorites, _foreignKeysFavorites, _indicesFavorites)
        val _existingFavorites: TableInfo = tableInfoRead(connection, "favorites")
        if (!_infoFavorites.equals(_existingFavorites)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |favorites(tv.own.owntv.core.database.entity.FavoriteEntity).
              | Expected:
              |""".trimMargin() + _infoFavorites + """
              |
              | Found:
              |""".trimMargin() + _existingFavorites)
        }
        val _columnsWatchHistory: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsWatchHistory.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsWatchHistory.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsWatchHistory.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsWatchHistory.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsWatchHistory.put("watchedAt", TableInfo.Column("watchedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysWatchHistory: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysWatchHistory.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesWatchHistory: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesWatchHistory.add(TableInfo.Index("index_watch_history_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesWatchHistory.add(TableInfo.Index("index_watch_history_profileId_watchedAt", false, listOf("profileId", "watchedAt"), listOf("ASC", "ASC")))
        _indicesWatchHistory.add(TableInfo.Index("index_watch_history_profileId_mediaType_itemId", true, listOf("profileId", "mediaType", "itemId"), listOf("ASC", "ASC", "ASC")))
        val _infoWatchHistory: TableInfo = TableInfo("watch_history", _columnsWatchHistory, _foreignKeysWatchHistory, _indicesWatchHistory)
        val _existingWatchHistory: TableInfo = tableInfoRead(connection, "watch_history")
        if (!_infoWatchHistory.equals(_existingWatchHistory)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |watch_history(tv.own.owntv.core.database.entity.WatchHistoryEntity).
              | Expected:
              |""".trimMargin() + _infoWatchHistory + """
              |
              | Found:
              |""".trimMargin() + _existingWatchHistory)
        }
        val _columnsPlaybackProgress: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsPlaybackProgress.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("positionMs", TableInfo.Column("positionMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("durationMs", TableInfo.Column("durationMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackProgress.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysPlaybackProgress: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysPlaybackProgress.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesPlaybackProgress: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesPlaybackProgress.add(TableInfo.Index("index_playback_progress_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesPlaybackProgress.add(TableInfo.Index("index_playback_progress_profileId_mediaType_itemId", true, listOf("profileId", "mediaType", "itemId"), listOf("ASC", "ASC", "ASC")))
        val _infoPlaybackProgress: TableInfo = TableInfo("playback_progress", _columnsPlaybackProgress, _foreignKeysPlaybackProgress, _indicesPlaybackProgress)
        val _existingPlaybackProgress: TableInfo = tableInfoRead(connection, "playback_progress")
        if (!_infoPlaybackProgress.equals(_existingPlaybackProgress)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |playback_progress(tv.own.owntv.core.database.entity.PlaybackProgressEntity).
              | Expected:
              |""".trimMargin() + _infoPlaybackProgress + """
              |
              | Found:
              |""".trimMargin() + _existingPlaybackProgress)
        }
        val _columnsContentOrder: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsContentOrder.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsContentOrder.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsContentOrder.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsContentOrder.put("contextKey", TableInfo.Column("contextKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsContentOrder.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsContentOrder.put("position", TableInfo.Column("position", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysContentOrder: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysContentOrder.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesContentOrder: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesContentOrder.add(TableInfo.Index("index_content_order_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesContentOrder.add(TableInfo.Index("index_content_order_profileId_mediaType_contextKey", false, listOf("profileId", "mediaType", "contextKey"), listOf("ASC", "ASC", "ASC")))
        _indicesContentOrder.add(TableInfo.Index("index_content_order_profileId_mediaType_contextKey_itemId", true, listOf("profileId", "mediaType", "contextKey", "itemId"), listOf("ASC", "ASC", "ASC", "ASC")))
        val _infoContentOrder: TableInfo = TableInfo("content_order", _columnsContentOrder, _foreignKeysContentOrder, _indicesContentOrder)
        val _existingContentOrder: TableInfo = tableInfoRead(connection, "content_order")
        if (!_infoContentOrder.equals(_existingContentOrder)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |content_order(tv.own.owntv.core.database.entity.ContentOrderEntity).
              | Expected:
              |""".trimMargin() + _infoContentOrder + """
              |
              | Found:
              |""".trimMargin() + _existingContentOrder)
        }
        val _columnsCustomCategoryMembers: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsCustomCategoryMembers.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCustomCategoryMembers.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCustomCategoryMembers.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCustomCategoryMembers.put("contextKey", TableInfo.Column("contextKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCustomCategoryMembers.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCustomCategoryMembers.put("position", TableInfo.Column("position", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysCustomCategoryMembers: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysCustomCategoryMembers.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesCustomCategoryMembers: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesCustomCategoryMembers.add(TableInfo.Index("index_custom_category_members_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesCustomCategoryMembers.add(TableInfo.Index("index_custom_category_members_profileId_mediaType_contextKey", false, listOf("profileId", "mediaType", "contextKey"), listOf("ASC", "ASC", "ASC")))
        _indicesCustomCategoryMembers.add(TableInfo.Index("index_custom_category_members_profileId_mediaType_contextKey_itemId", true, listOf("profileId", "mediaType", "contextKey", "itemId"), listOf("ASC", "ASC", "ASC", "ASC")))
        val _infoCustomCategoryMembers: TableInfo = TableInfo("custom_category_members", _columnsCustomCategoryMembers, _foreignKeysCustomCategoryMembers, _indicesCustomCategoryMembers)
        val _existingCustomCategoryMembers: TableInfo = tableInfoRead(connection, "custom_category_members")
        if (!_infoCustomCategoryMembers.equals(_existingCustomCategoryMembers)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |custom_category_members(tv.own.owntv.core.database.entity.CustomCategoryMemberEntity).
              | Expected:
              |""".trimMargin() + _infoCustomCategoryMembers + """
              |
              | Found:
              |""".trimMargin() + _existingCustomCategoryMembers)
        }
        val _columnsPlaybackPrefs: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsPlaybackPrefs.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("contentKey", TableInfo.Column("contentKey", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("zoomMode", TableInfo.Column("zoomMode", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("volumeBoost", TableInfo.Column("volumeBoost", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("audioDelayMs", TableInfo.Column("audioDelayMs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, "-1", TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("audioLang", TableInfo.Column("audioLang", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackPrefs.put("subtitleLang", TableInfo.Column("subtitleLang", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysPlaybackPrefs: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysPlaybackPrefs.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesPlaybackPrefs: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesPlaybackPrefs.add(TableInfo.Index("index_playback_prefs_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesPlaybackPrefs.add(TableInfo.Index("index_playback_prefs_sourceId", false, listOf("sourceId"), listOf("ASC")))
        val _infoPlaybackPrefs: TableInfo = TableInfo("playback_prefs", _columnsPlaybackPrefs, _foreignKeysPlaybackPrefs, _indicesPlaybackPrefs)
        val _existingPlaybackPrefs: TableInfo = tableInfoRead(connection, "playback_prefs")
        if (!_infoPlaybackPrefs.equals(_existingPlaybackPrefs)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |playback_prefs(tv.own.owntv.core.database.entity.PlaybackPrefsEntity).
              | Expected:
              |""".trimMargin() + _infoPlaybackPrefs + """
              |
              | Found:
              |""".trimMargin() + _existingPlaybackPrefs)
        }
        val _columnsPlaybackQuirks: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsPlaybackQuirks.put("contentKey", TableInfo.Column("contentKey", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("enginePin", TableInfo.Column("enginePin", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("audioOnly", TableInfo.Column("audioOnly", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("audioDelayMs", TableInfo.Column("audioDelayMs", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsPlaybackQuirks.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysPlaybackQuirks: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesPlaybackQuirks: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesPlaybackQuirks.add(TableInfo.Index("index_playback_quirks_sourceId", false, listOf("sourceId"), listOf("ASC")))
        val _infoPlaybackQuirks: TableInfo = TableInfo("playback_quirks", _columnsPlaybackQuirks, _foreignKeysPlaybackQuirks, _indicesPlaybackQuirks)
        val _existingPlaybackQuirks: TableInfo = tableInfoRead(connection, "playback_quirks")
        if (!_infoPlaybackQuirks.equals(_existingPlaybackQuirks)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |playback_quirks(tv.own.owntv.core.database.entity.PlaybackQuirkEntity).
              | Expected:
              |""".trimMargin() + _infoPlaybackQuirks + """
              |
              | Found:
              |""".trimMargin() + _existingPlaybackQuirks)
        }
        val _columnsSeriesSortOrder: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSeriesSortOrder.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeriesSortOrder.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeriesSortOrder.put("seriesId", TableInfo.Column("seriesId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeriesSortOrder.put("seasonsDescending", TableInfo.Column("seasonsDescending", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSeriesSortOrder.put("episodesDescending", TableInfo.Column("episodesDescending", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSeriesSortOrder: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSeriesSortOrder.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesSeriesSortOrder: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSeriesSortOrder.add(TableInfo.Index("index_series_sort_order_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesSeriesSortOrder.add(TableInfo.Index("index_series_sort_order_profileId_seriesId", true, listOf("profileId", "seriesId"), listOf("ASC", "ASC")))
        val _infoSeriesSortOrder: TableInfo = TableInfo("series_sort_order", _columnsSeriesSortOrder, _foreignKeysSeriesSortOrder, _indicesSeriesSortOrder)
        val _existingSeriesSortOrder: TableInfo = tableInfoRead(connection, "series_sort_order")
        if (!_infoSeriesSortOrder.equals(_existingSeriesSortOrder)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |series_sort_order(tv.own.owntv.core.database.entity.SeriesSortOrderEntity).
              | Expected:
              |""".trimMargin() + _infoSeriesSortOrder + """
              |
              | Found:
              |""".trimMargin() + _existingSeriesSortOrder)
        }
        val _columnsUserDataTombstones: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsUserDataTombstones.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUserDataTombstones.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUserDataTombstones.put("kind", TableInfo.Column("kind", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUserDataTombstones.put("identity", TableInfo.Column("identity", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsUserDataTombstones.put("deletedAt", TableInfo.Column("deletedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysUserDataTombstones: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysUserDataTombstones.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesUserDataTombstones: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesUserDataTombstones.add(TableInfo.Index("index_user_data_tombstones_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesUserDataTombstones.add(TableInfo.Index("index_user_data_tombstones_profileId_kind_identity", true, listOf("profileId", "kind", "identity"), listOf("ASC", "ASC", "ASC")))
        _indicesUserDataTombstones.add(TableInfo.Index("index_user_data_tombstones_deletedAt", false, listOf("deletedAt"), listOf("ASC")))
        val _infoUserDataTombstones: TableInfo = TableInfo("user_data_tombstones", _columnsUserDataTombstones, _foreignKeysUserDataTombstones, _indicesUserDataTombstones)
        val _existingUserDataTombstones: TableInfo = tableInfoRead(connection, "user_data_tombstones")
        if (!_infoUserDataTombstones.equals(_existingUserDataTombstones)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |user_data_tombstones(tv.own.owntv.core.database.entity.UserDataTombstoneEntity).
              | Expected:
              |""".trimMargin() + _infoUserDataTombstones + """
              |
              | Found:
              |""".trimMargin() + _existingUserDataTombstones)
        }
        val _columnsDownloads: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsDownloads.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("itemId", TableInfo.Column("itemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("title", TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("posterUrl", TableInfo.Column("posterUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("streamUrl", TableInfo.Column("streamUrl", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("filePath", TableInfo.Column("filePath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("status", TableInfo.Column("status", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("downloadedBytes", TableInfo.Column("downloadedBytes", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("totalBytes", TableInfo.Column("totalBytes", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("createdAt", TableInfo.Column("createdAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsDownloads.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysDownloads: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysDownloads.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesDownloads: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesDownloads.add(TableInfo.Index("index_downloads_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesDownloads.add(TableInfo.Index("index_downloads_status", false, listOf("status"), listOf("ASC")))
        _indicesDownloads.add(TableInfo.Index("index_downloads_profileId_mediaType_itemId", true, listOf("profileId", "mediaType", "itemId"), listOf("ASC", "ASC", "ASC")))
        val _infoDownloads: TableInfo = TableInfo("downloads", _columnsDownloads, _foreignKeysDownloads, _indicesDownloads)
        val _existingDownloads: TableInfo = tableInfoRead(connection, "downloads")
        if (!_infoDownloads.equals(_existingDownloads)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |downloads(tv.own.owntv.core.database.entity.DownloadEntity).
              | Expected:
              |""".trimMargin() + _infoDownloads + """
              |
              | Found:
              |""".trimMargin() + _existingDownloads)
        }
        val _columnsRecordings: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsRecordings.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("channelId", TableInfo.Column("channelId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("channelName", TableInfo.Column("channelName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("channelIconUrl", TableInfo.Column("channelIconUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("epgChannelId", TableInfo.Column("epgChannelId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("streamUrl", TableInfo.Column("streamUrl", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("httpHeaders", TableInfo.Column("httpHeaders", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("title", TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("description", TableInfo.Column("description", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("programmeStartMs", TableInfo.Column("programmeStartMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("programmeStopMs", TableInfo.Column("programmeStopMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("startMs", TableInfo.Column("startMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("stopMs", TableInfo.Column("stopMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("status", TableInfo.Column("status", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("failure", TableInfo.Column("failure", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("filePath", TableInfo.Column("filePath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("bytes", TableInfo.Column("bytes", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("startedAt", TableInfo.Column("startedAt", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("endedAt", TableInfo.Column("endedAt", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("ruleId", TableInfo.Column("ruleId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("createdAt", TableInfo.Column("createdAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordings.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysRecordings: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysRecordings.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesRecordings: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesRecordings.add(TableInfo.Index("index_recordings_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesRecordings.add(TableInfo.Index("index_recordings_status", false, listOf("status"), listOf("ASC")))
        _indicesRecordings.add(TableInfo.Index("index_recordings_startMs_stopMs", false, listOf("startMs", "stopMs"), listOf("ASC", "ASC")))
        _indicesRecordings.add(TableInfo.Index("index_recordings_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesRecordings.add(TableInfo.Index("index_recordings_ruleId", false, listOf("ruleId"), listOf("ASC")))
        _indicesRecordings.add(TableInfo.Index("index_recordings_profileId_channelId_programmeStartMs", true, listOf("profileId", "channelId", "programmeStartMs"), listOf("ASC", "ASC", "ASC")))
        val _infoRecordings: TableInfo = TableInfo("recordings", _columnsRecordings, _foreignKeysRecordings, _indicesRecordings)
        val _existingRecordings: TableInfo = tableInfoRead(connection, "recordings")
        if (!_infoRecordings.equals(_existingRecordings)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |recordings(tv.own.owntv.core.database.entity.RecordingEntity).
              | Expected:
              |""".trimMargin() + _infoRecordings + """
              |
              | Found:
              |""".trimMargin() + _existingRecordings)
        }
        val _columnsCatalogBackfill: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsCatalogBackfill.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("categoryRemoteId", TableInfo.Column("categoryRemoteId", "TEXT", true, 3, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("categoryDbId", TableInfo.Column("categoryDbId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("totalItems", TableInfo.Column("totalItems", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("maxPageItems", TableInfo.Column("maxPageItems", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("nextPage", TableInfo.Column("nextPage", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("lastPage", TableInfo.Column("lastPage", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("sortBase", TableInfo.Column("sortBase", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsCatalogBackfill.put("done", TableInfo.Column("done", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysCatalogBackfill: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysCatalogBackfill.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        val _indicesCatalogBackfill: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesCatalogBackfill.add(TableInfo.Index("index_catalog_backfill_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesCatalogBackfill.add(TableInfo.Index("index_catalog_backfill_sourceId_mediaType_done", false, listOf("sourceId", "mediaType", "done"), listOf("ASC", "ASC", "ASC")))
        val _infoCatalogBackfill: TableInfo = TableInfo("catalog_backfill", _columnsCatalogBackfill, _foreignKeysCatalogBackfill, _indicesCatalogBackfill)
        val _existingCatalogBackfill: TableInfo = tableInfoRead(connection, "catalog_backfill")
        if (!_infoCatalogBackfill.equals(_existingCatalogBackfill)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |catalog_backfill(tv.own.owntv.core.database.entity.CatalogBackfillEntity).
              | Expected:
              |""".trimMargin() + _infoCatalogBackfill + """
              |
              | Found:
              |""".trimMargin() + _existingCatalogBackfill)
        }
        val _columnsRecordingRules: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsRecordingRules.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("channelId", TableInfo.Column("channelId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("channelName", TableInfo.Column("channelName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("epgChannelId", TableInfo.Column("epgChannelId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("title", TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("titleKey", TableInfo.Column("titleKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("enabled", TableInfo.Column("enabled", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsRecordingRules.put("createdAt", TableInfo.Column("createdAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysRecordingRules: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysRecordingRules.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesRecordingRules: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesRecordingRules.add(TableInfo.Index("index_recording_rules_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesRecordingRules.add(TableInfo.Index("index_recording_rules_profileId_channelId_titleKey", true, listOf("profileId", "channelId", "titleKey"), listOf("ASC", "ASC", "ASC")))
        val _infoRecordingRules: TableInfo = TableInfo("recording_rules", _columnsRecordingRules, _foreignKeysRecordingRules, _indicesRecordingRules)
        val _existingRecordingRules: TableInfo = tableInfoRead(connection, "recording_rules")
        if (!_infoRecordingRules.equals(_existingRecordingRules)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |recording_rules(tv.own.owntv.core.database.entity.RecordingRuleEntity).
              | Expected:
              |""".trimMargin() + _infoRecordingRules + """
              |
              | Found:
              |""".trimMargin() + _existingRecordingRules)
        }
        val _columnsTvProviderPrograms: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTvProviderPrograms.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("surface", TableInfo.Column("surface", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("groupId", TableInfo.Column("groupId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("targetItemId", TableInfo.Column("targetItemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("providerProgramId", TableInfo.Column("providerProgramId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("lastPositionMs", TableInfo.Column("lastPositionMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("durationMs", TableInfo.Column("durationMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("lastEngagementAt", TableInfo.Column("lastEngagementAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTvProviderPrograms.put("lastPublishedAt", TableInfo.Column("lastPublishedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTvProviderPrograms: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysTvProviderPrograms.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesTvProviderPrograms: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesTvProviderPrograms.add(TableInfo.Index("index_tv_provider_programs_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesTvProviderPrograms.add(TableInfo.Index("index_tv_provider_programs_profileId_surface_mediaType_groupId", true, listOf("profileId", "surface", "mediaType", "groupId"), listOf("ASC", "ASC", "ASC", "ASC")))
        val _infoTvProviderPrograms: TableInfo = TableInfo("tv_provider_programs", _columnsTvProviderPrograms, _foreignKeysTvProviderPrograms, _indicesTvProviderPrograms)
        val _existingTvProviderPrograms: TableInfo = tableInfoRead(connection, "tv_provider_programs")
        if (!_infoTvProviderPrograms.equals(_existingTvProviderPrograms)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |tv_provider_programs(tv.own.owntv.core.database.entity.TvProviderProgramEntity).
              | Expected:
              |""".trimMargin() + _infoTvProviderPrograms + """
              |
              | Found:
              |""".trimMargin() + _existingTvProviderPrograms)
        }
        val _columnsEpgChannels: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEpgChannels.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("epgChannelId", TableInfo.Column("epgChannelId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("displayName", TableInfo.Column("displayName", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("iconUrl", TableInfo.Column("iconUrl", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("normName", TableInfo.Column("normName", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgChannels.put("normId", TableInfo.Column("normId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEpgChannels: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEpgChannels: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesEpgChannels.add(TableInfo.Index("index_epg_channels_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesEpgChannels.add(TableInfo.Index("index_epg_channels_sourceId_epgChannelId", true, listOf("sourceId", "epgChannelId"), listOf("ASC", "ASC")))
        _indicesEpgChannels.add(TableInfo.Index("index_epg_channels_normName", false, listOf("normName"), listOf("ASC")))
        val _infoEpgChannels: TableInfo = TableInfo("epg_channels", _columnsEpgChannels, _foreignKeysEpgChannels, _indicesEpgChannels)
        val _existingEpgChannels: TableInfo = tableInfoRead(connection, "epg_channels")
        if (!_infoEpgChannels.equals(_existingEpgChannels)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |epg_channels(tv.own.owntv.core.database.entity.EpgChannelEntity).
              | Expected:
              |""".trimMargin() + _infoEpgChannels + """
              |
              | Found:
              |""".trimMargin() + _existingEpgChannels)
        }
        val _columnsEpgProgrammes: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsEpgProgrammes.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("epgChannelId", TableInfo.Column("epgChannelId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("startMs", TableInfo.Column("startMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("stopMs", TableInfo.Column("stopMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("title", TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("description", TableInfo.Column("description", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsEpgProgrammes.put("contentHash", TableInfo.Column("contentHash", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysEpgProgrammes: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesEpgProgrammes: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_epgChannelId_startMs", false, listOf("epgChannelId", "startMs"), listOf("ASC", "ASC")))
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_sourceId", false, listOf("sourceId"), listOf("ASC")))
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_stopMs", false, listOf("stopMs"), listOf("ASC")))
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_startMs_stopMs", false, listOf("startMs", "stopMs"), listOf("ASC", "ASC")))
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_sourceId_epgChannelId", false, listOf("sourceId", "epgChannelId"), listOf("ASC", "ASC")))
        _indicesEpgProgrammes.add(TableInfo.Index("index_epg_programmes_natural_key", true, listOf("sourceId", "epgChannelId", "startMs"), listOf("ASC", "ASC", "ASC")))
        val _infoEpgProgrammes: TableInfo = TableInfo("epg_programmes", _columnsEpgProgrammes, _foreignKeysEpgProgrammes, _indicesEpgProgrammes)
        val _existingEpgProgrammes: TableInfo = tableInfoRead(connection, "epg_programmes")
        if (!_infoEpgProgrammes.equals(_existingEpgProgrammes)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |epg_programmes(tv.own.owntv.core.database.entity.EpgProgrammeEntity).
              | Expected:
              |""".trimMargin() + _infoEpgProgrammes + """
              |
              | Found:
              |""".trimMargin() + _existingEpgProgrammes)
        }
        val _columnsMetadataCache: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMetadataCache.put("key", TableInfo.Column("key", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("tmdbId", TableInfo.Column("tmdbId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("imdbId", TableInfo.Column("imdbId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("type", TableInfo.Column("type", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("title", TableInfo.Column("title", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("year", TableInfo.Column("year", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("overview", TableInfo.Column("overview", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("posterPath", TableInfo.Column("posterPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("backdropPath", TableInfo.Column("backdropPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("rating", TableInfo.Column("rating", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("genresJson", TableInfo.Column("genresJson", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("castJson", TableInfo.Column("castJson", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("trailerKey", TableInfo.Column("trailerKey", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("logoPath", TableInfo.Column("logoPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("airDate", TableInfo.Column("airDate", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataCache.put("originalLanguage", TableInfo.Column("originalLanguage", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMetadataCache: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesMetadataCache: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesMetadataCache.add(TableInfo.Index("index_metadata_cache_tmdbId", false, listOf("tmdbId"), listOf("ASC")))
        _indicesMetadataCache.add(TableInfo.Index("index_metadata_cache_updatedAt", false, listOf("updatedAt"), listOf("ASC")))
        val _infoMetadataCache: TableInfo = TableInfo("metadata_cache", _columnsMetadataCache, _foreignKeysMetadataCache, _indicesMetadataCache)
        val _existingMetadataCache: TableInfo = tableInfoRead(connection, "metadata_cache")
        if (!_infoMetadataCache.equals(_existingMetadataCache)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |metadata_cache(tv.own.owntv.core.database.entity.MetadataCacheEntity).
              | Expected:
              |""".trimMargin() + _infoMetadataCache + """
              |
              | Found:
              |""".trimMargin() + _existingMetadataCache)
        }
        val _columnsMetadataMatch: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsMetadataMatch.put("localKey", TableInfo.Column("localKey", "TEXT", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataMatch.put("type", TableInfo.Column("type", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataMatch.put("tmdbId", TableInfo.Column("tmdbId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataMatch.put("confidence", TableInfo.Column("confidence", "REAL", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsMetadataMatch.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysMetadataMatch: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesMetadataMatch: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesMetadataMatch.add(TableInfo.Index("index_metadata_match_updatedAt", false, listOf("updatedAt"), listOf("ASC")))
        val _infoMetadataMatch: TableInfo = TableInfo("metadata_match", _columnsMetadataMatch, _foreignKeysMetadataMatch, _indicesMetadataMatch)
        val _existingMetadataMatch: TableInfo = tableInfoRead(connection, "metadata_match")
        if (!_infoMetadataMatch.equals(_existingMetadataMatch)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |metadata_match(tv.own.owntv.core.database.entity.MetadataMatchEntity).
              | Expected:
              |""".trimMargin() + _infoMetadataMatch + """
              |
              | Found:
              |""".trimMargin() + _existingMetadataMatch)
        }
        val _columnsTrendingSnapshots: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTrendingSnapshots.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("status", TableInfo.Column("status", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("metadataLanguage", TableInfo.Column("metadataLanguage", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("refreshedAt", TableInfo.Column("refreshedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("candidateFetchedAt", TableInfo.Column("candidateFetchedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("generationId", TableInfo.Column("generationId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("itemCount", TableInfo.Column("itemCount", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("matchedItemCount", TableInfo.Column("matchedItemCount", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("lastAttemptAt", TableInfo.Column("lastAttemptAt", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("lastAttemptStatus", TableInfo.Column("lastAttemptStatus", "TEXT", true, 0, "'NEVER'", TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingSnapshots.put("failureStage", TableInfo.Column("failureStage", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTrendingSnapshots: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysTrendingSnapshots.add(TableInfo.ForeignKey("sources", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("id")))
        val _indicesTrendingSnapshots: MutableSet<TableInfo.Index> = mutableSetOf()
        val _infoTrendingSnapshots: TableInfo = TableInfo("trending_snapshots", _columnsTrendingSnapshots, _foreignKeysTrendingSnapshots, _indicesTrendingSnapshots)
        val _existingTrendingSnapshots: TableInfo = tableInfoRead(connection, "trending_snapshots")
        if (!_infoTrendingSnapshots.equals(_existingTrendingSnapshots)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |trending_snapshots(tv.own.owntv.core.database.entity.TrendingSnapshotEntity).
              | Expected:
              |""".trimMargin() + _infoTrendingSnapshots + """
              |
              | Found:
              |""".trimMargin() + _existingTrendingSnapshots)
        }
        val _columnsTrendingItems: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsTrendingItems.put("sourceId", TableInfo.Column("sourceId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("position", TableInfo.Column("position", "INTEGER", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("tmdbId", TableInfo.Column("tmdbId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("trendingRank", TableInfo.Column("trendingRank", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("providerItemId", TableInfo.Column("providerItemId", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("providerRemoteId", TableInfo.Column("providerRemoteId", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("providerStableKey", TableInfo.Column("providerStableKey", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("providerRawName", TableInfo.Column("providerRawName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("canonicalTitle", TableInfo.Column("canonicalTitle", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("providerLanguage", TableInfo.Column("providerLanguage", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("advertisedQuality", TableInfo.Column("advertisedQuality", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("advertisedCapabilities", TableInfo.Column("advertisedCapabilities", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("localizedTitle", TableInfo.Column("localizedTitle", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("originalTitle", TableInfo.Column("originalTitle", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("year", TableInfo.Column("year", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("overview", TableInfo.Column("overview", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("posterPath", TableInfo.Column("posterPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("backdropPath", TableInfo.Column("backdropPath", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("rating", TableInfo.Column("rating", "REAL", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("trailerKey", TableInfo.Column("trailerKey", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("generationId", TableInfo.Column("generationId", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsTrendingItems.put("refreshedAt", TableInfo.Column("refreshedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysTrendingItems: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysTrendingItems.add(TableInfo.ForeignKey("trending_snapshots", "CASCADE", "NO ACTION", listOf("sourceId"), listOf("sourceId")))
        val _indicesTrendingItems: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesTrendingItems.add(TableInfo.Index("index_trending_items_sourceId_mediaType_providerItemId", false, listOf("sourceId", "mediaType", "providerItemId"), listOf("ASC", "ASC", "ASC")))
        _indicesTrendingItems.add(TableInfo.Index("index_trending_items_mediaType_tmdbId", false, listOf("mediaType", "tmdbId"), listOf("ASC", "ASC")))
        val _infoTrendingItems: TableInfo = TableInfo("trending_items", _columnsTrendingItems, _foreignKeysTrendingItems, _indicesTrendingItems)
        val _existingTrendingItems: TableInfo = tableInfoRead(connection, "trending_items")
        if (!_infoTrendingItems.equals(_existingTrendingItems)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |trending_items(tv.own.owntv.core.database.entity.TrendingItemEntity).
              | Expected:
              |""".trimMargin() + _infoTrendingItems + """
              |
              | Found:
              |""".trimMargin() + _existingTrendingItems)
        }
        val _columnsSubtitleCache: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSubtitleCache.put("id", TableInfo.Column("id", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("source", TableInfo.Column("source", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("openSubFileId", TableInfo.Column("openSubFileId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("language", TableInfo.Column("language", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("languageName", TableInfo.Column("languageName", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("releaseName", TableInfo.Column("releaseName", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("format", TableInfo.Column("format", "TEXT", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("hearingImpaired", TableInfo.Column("hearingImpaired", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("fileName", TableInfo.Column("fileName", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("cachedPath", TableInfo.Column("cachedPath", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleCache.put("lastUsedAt", TableInfo.Column("lastUsedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSubtitleCache: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        val _indicesSubtitleCache: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSubtitleCache.add(TableInfo.Index("index_subtitle_cache_openSubFileId", true, listOf("openSubFileId"), listOf("ASC")))
        _indicesSubtitleCache.add(TableInfo.Index("index_subtitle_cache_lastUsedAt", false, listOf("lastUsedAt"), listOf("ASC")))
        val _infoSubtitleCache: TableInfo = TableInfo("subtitle_cache", _columnsSubtitleCache, _foreignKeysSubtitleCache, _indicesSubtitleCache)
        val _existingSubtitleCache: TableInfo = tableInfoRead(connection, "subtitle_cache")
        if (!_infoSubtitleCache.equals(_existingSubtitleCache)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |subtitle_cache(tv.own.owntv.core.database.entity.SubtitleCacheEntity).
              | Expected:
              |""".trimMargin() + _infoSubtitleCache + """
              |
              | Found:
              |""".trimMargin() + _existingSubtitleCache)
        }
        val _columnsSubtitleSelection: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSubtitleSelection.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleSelection.put("contentKey", TableInfo.Column("contentKey", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleSelection.put("cacheId", TableInfo.Column("cacheId", "INTEGER", false, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleSelection.put("off", TableInfo.Column("off", "INTEGER", true, 0, "0", TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleSelection.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSubtitleSelection: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSubtitleSelection.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        _foreignKeysSubtitleSelection.add(TableInfo.ForeignKey("subtitle_cache", "SET NULL", "NO ACTION", listOf("cacheId"), listOf("id")))
        val _indicesSubtitleSelection: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSubtitleSelection.add(TableInfo.Index("index_subtitle_selection_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesSubtitleSelection.add(TableInfo.Index("index_subtitle_selection_cacheId", false, listOf("cacheId"), listOf("ASC")))
        val _infoSubtitleSelection: TableInfo = TableInfo("subtitle_selection", _columnsSubtitleSelection, _foreignKeysSubtitleSelection, _indicesSubtitleSelection)
        val _existingSubtitleSelection: TableInfo = tableInfoRead(connection, "subtitle_selection")
        if (!_infoSubtitleSelection.equals(_existingSubtitleSelection)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |subtitle_selection(tv.own.owntv.core.database.entity.SubtitleSelectionEntity).
              | Expected:
              |""".trimMargin() + _infoSubtitleSelection + """
              |
              | Found:
              |""".trimMargin() + _existingSubtitleSelection)
        }
        val _columnsSubtitleTiming: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSubtitleTiming.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleTiming.put("contentKey", TableInfo.Column("contentKey", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleTiming.put("subtitleKey", TableInfo.Column("subtitleKey", "TEXT", true, 3, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleTiming.put("offsetMs", TableInfo.Column("offsetMs", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleTiming.put("updatedAt", TableInfo.Column("updatedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSubtitleTiming: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSubtitleTiming.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        val _indicesSubtitleTiming: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSubtitleTiming.add(TableInfo.Index("index_subtitle_timing_profileId", false, listOf("profileId"), listOf("ASC")))
        val _infoSubtitleTiming: TableInfo = TableInfo("subtitle_timing", _columnsSubtitleTiming, _foreignKeysSubtitleTiming, _indicesSubtitleTiming)
        val _existingSubtitleTiming: TableInfo = tableInfoRead(connection, "subtitle_timing")
        if (!_infoSubtitleTiming.equals(_existingSubtitleTiming)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |subtitle_timing(tv.own.owntv.core.database.entity.SubtitleTimingEntity).
              | Expected:
              |""".trimMargin() + _infoSubtitleTiming + """
              |
              | Found:
              |""".trimMargin() + _existingSubtitleTiming)
        }
        val _columnsSubtitleLink: MutableMap<String, TableInfo.Column> = mutableMapOf()
        _columnsSubtitleLink.put("profileId", TableInfo.Column("profileId", "INTEGER", true, 1, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleLink.put("contentKey", TableInfo.Column("contentKey", "TEXT", true, 2, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleLink.put("cacheId", TableInfo.Column("cacheId", "INTEGER", true, 3, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleLink.put("mediaType", TableInfo.Column("mediaType", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleLink.put("contentTitle", TableInfo.Column("contentTitle", "TEXT", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        _columnsSubtitleLink.put("addedAt", TableInfo.Column("addedAt", "INTEGER", true, 0, null, TableInfo.CREATED_FROM_ENTITY))
        val _foreignKeysSubtitleLink: MutableSet<TableInfo.ForeignKey> = mutableSetOf()
        _foreignKeysSubtitleLink.add(TableInfo.ForeignKey("profiles", "CASCADE", "NO ACTION", listOf("profileId"), listOf("id")))
        _foreignKeysSubtitleLink.add(TableInfo.ForeignKey("subtitle_cache", "CASCADE", "NO ACTION", listOf("cacheId"), listOf("id")))
        val _indicesSubtitleLink: MutableSet<TableInfo.Index> = mutableSetOf()
        _indicesSubtitleLink.add(TableInfo.Index("index_subtitle_link_profileId", false, listOf("profileId"), listOf("ASC")))
        _indicesSubtitleLink.add(TableInfo.Index("index_subtitle_link_cacheId", false, listOf("cacheId"), listOf("ASC")))
        _indicesSubtitleLink.add(TableInfo.Index("index_subtitle_link_profileId_mediaType", false, listOf("profileId", "mediaType"), listOf("ASC", "ASC")))
        val _infoSubtitleLink: TableInfo = TableInfo("subtitle_link", _columnsSubtitleLink, _foreignKeysSubtitleLink, _indicesSubtitleLink)
        val _existingSubtitleLink: TableInfo = tableInfoRead(connection, "subtitle_link")
        if (!_infoSubtitleLink.equals(_existingSubtitleLink)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |subtitle_link(tv.own.owntv.core.database.entity.SubtitleLinkEntity).
              | Expected:
              |""".trimMargin() + _infoSubtitleLink + """
              |
              | Found:
              |""".trimMargin() + _existingSubtitleLink)
        }
        val _columnsChannelsFts: MutableSet<String> = mutableSetOf()
        _columnsChannelsFts.add("name")
        val _infoChannelsFts: FtsTableInfo = FtsTableInfo("channels_fts", _columnsChannelsFts, "CREATE VIRTUAL TABLE IF NOT EXISTS `channels_fts` USING FTS4(`name` TEXT NOT NULL, content=`channels`)")
        val _existingChannelsFts: FtsTableInfo = ftsTableInfoRead(connection, "channels_fts")
        if (!_infoChannelsFts.equals(_existingChannelsFts)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |channels_fts(tv.own.owntv.core.database.entity.ChannelFtsEntity).
              | Expected:
              |""".trimMargin() + _infoChannelsFts + """
              |
              | Found:
              |""".trimMargin() + _existingChannelsFts)
        }
        val _columnsMoviesFts: MutableSet<String> = mutableSetOf()
        _columnsMoviesFts.add("name")
        val _infoMoviesFts: FtsTableInfo = FtsTableInfo("movies_fts", _columnsMoviesFts, "CREATE VIRTUAL TABLE IF NOT EXISTS `movies_fts` USING FTS4(`name` TEXT NOT NULL, content=`movies`)")
        val _existingMoviesFts: FtsTableInfo = ftsTableInfoRead(connection, "movies_fts")
        if (!_infoMoviesFts.equals(_existingMoviesFts)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |movies_fts(tv.own.owntv.core.database.entity.MovieFtsEntity).
              | Expected:
              |""".trimMargin() + _infoMoviesFts + """
              |
              | Found:
              |""".trimMargin() + _existingMoviesFts)
        }
        val _columnsSeriesFts: MutableSet<String> = mutableSetOf()
        _columnsSeriesFts.add("name")
        val _infoSeriesFts: FtsTableInfo = FtsTableInfo("series_fts", _columnsSeriesFts, "CREATE VIRTUAL TABLE IF NOT EXISTS `series_fts` USING FTS4(`name` TEXT NOT NULL, content=`series`)")
        val _existingSeriesFts: FtsTableInfo = ftsTableInfoRead(connection, "series_fts")
        if (!_infoSeriesFts.equals(_existingSeriesFts)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |series_fts(tv.own.owntv.core.database.entity.SeriesFtsEntity).
              | Expected:
              |""".trimMargin() + _infoSeriesFts + """
              |
              | Found:
              |""".trimMargin() + _existingSeriesFts)
        }
        val _columnsEpisodesFts: MutableSet<String> = mutableSetOf()
        _columnsEpisodesFts.add("name")
        val _infoEpisodesFts: FtsTableInfo = FtsTableInfo("episodes_fts", _columnsEpisodesFts, "CREATE VIRTUAL TABLE IF NOT EXISTS `episodes_fts` USING FTS4(`name` TEXT NOT NULL, content=`episodes`)")
        val _existingEpisodesFts: FtsTableInfo = ftsTableInfoRead(connection, "episodes_fts")
        if (!_infoEpisodesFts.equals(_existingEpisodesFts)) {
          return RoomOpenDelegate.ValidationResult(false, """
              |episodes_fts(tv.own.owntv.core.database.entity.EpisodeFtsEntity).
              | Expected:
              |""".trimMargin() + _infoEpisodesFts + """
              |
              | Found:
              |""".trimMargin() + _existingEpisodesFts)
        }
        return RoomOpenDelegate.ValidationResult(true, null)
      }
    }
    return _openDelegate
  }

  protected override fun createInvalidationTracker(): InvalidationTracker {
    val _shadowTablesMap: MutableMap<String, String> = mutableMapOf()
    _shadowTablesMap.put("channels_fts", "channels")
    _shadowTablesMap.put("movies_fts", "movies")
    _shadowTablesMap.put("series_fts", "series")
    _shadowTablesMap.put("episodes_fts", "episodes")
    val _viewTables: MutableMap<String, Set<String>> = mutableMapOf()
    return InvalidationTracker(this, _shadowTablesMap, _viewTables, "profiles", "sources", "profile_source", "categories", "channels", "movies", "series", "seasons", "episodes", "favorites", "watch_history", "playback_progress", "content_order", "custom_category_members", "playback_prefs", "playback_quirks", "series_sort_order", "user_data_tombstones", "downloads", "recordings", "catalog_backfill", "recording_rules", "tv_provider_programs", "epg_channels", "epg_programmes", "metadata_cache", "metadata_match", "trending_snapshots", "trending_items", "subtitle_cache", "subtitle_selection", "subtitle_timing", "subtitle_link", "channels_fts", "movies_fts", "series_fts", "episodes_fts")
  }

  public override fun clearAllTables() {
    super.performClear(true, "profiles", "sources", "profile_source", "categories", "channels", "movies", "series", "seasons", "episodes", "favorites", "watch_history", "playback_progress", "content_order", "custom_category_members", "playback_prefs", "playback_quirks", "series_sort_order", "user_data_tombstones", "downloads", "recordings", "catalog_backfill", "recording_rules", "tv_provider_programs", "epg_channels", "epg_programmes", "metadata_cache", "metadata_match", "trending_snapshots", "trending_items", "subtitle_cache", "subtitle_selection", "subtitle_timing", "subtitle_link", "channels_fts", "movies_fts", "series_fts", "episodes_fts")
  }

  protected override fun getRequiredTypeConverterClasses(): Map<KClass<*>, List<KClass<*>>> {
    val _typeConvertersMap: MutableMap<KClass<*>, List<KClass<*>>> = mutableMapOf()
    _typeConvertersMap.put(ProfileDao::class, ProfileDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(SourceDao::class, SourceDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(CategoryDao::class, CategoryDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(ChannelDao::class, ChannelDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(MovieDao::class, MovieDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(SeriesDao::class, SeriesDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(FavoriteDao::class, FavoriteDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(HistoryDao::class, HistoryDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(ProgressDao::class, ProgressDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(ContentOrderDao::class, ContentOrderDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(PlaybackPrefsDao::class, PlaybackPrefsDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(PlaybackQuirkDao::class, PlaybackQuirkDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(CustomCategoryDao::class, CustomCategoryDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(SeriesSortOrderDao::class, SeriesSortOrderDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TombstoneDao::class, TombstoneDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TvProviderProgramDao::class, TvProviderProgramDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(DownloadDao::class, DownloadDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(RecordingDao::class, RecordingDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(CatalogBackfillDao::class, CatalogBackfillDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(EpgDao::class, EpgDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(MetadataDao::class, MetadataDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(TrendingDao::class, TrendingDao_Impl.getRequiredConverters())
    _typeConvertersMap.put(SubtitleDao::class, SubtitleDao_Impl.getRequiredConverters())
    return _typeConvertersMap
  }

  public override fun getRequiredAutoMigrationSpecClasses(): Set<KClass<out AutoMigrationSpec>> {
    val _autoMigrationSpecsSet: MutableSet<KClass<out AutoMigrationSpec>> = mutableSetOf()
    return _autoMigrationSpecsSet
  }

  public override fun createAutoMigrations(autoMigrationSpecs: Map<KClass<out AutoMigrationSpec>, AutoMigrationSpec>): List<Migration> {
    val _autoMigrations: MutableList<Migration> = mutableListOf()
    return _autoMigrations
  }

  public override fun profileDao(): ProfileDao = _profileDao.value

  public override fun sourceDao(): SourceDao = _sourceDao.value

  public override fun categoryDao(): CategoryDao = _categoryDao.value

  public override fun channelDao(): ChannelDao = _channelDao.value

  public override fun movieDao(): MovieDao = _movieDao.value

  public override fun seriesDao(): SeriesDao = _seriesDao.value

  public override fun favoriteDao(): FavoriteDao = _favoriteDao.value

  public override fun historyDao(): HistoryDao = _historyDao.value

  public override fun progressDao(): ProgressDao = _progressDao.value

  public override fun contentOrderDao(): ContentOrderDao = _contentOrderDao.value

  public override fun playbackPrefsDao(): PlaybackPrefsDao = _playbackPrefsDao.value

  public override fun playbackQuirkDao(): PlaybackQuirkDao = _playbackQuirkDao.value

  public override fun customCategoryDao(): CustomCategoryDao = _customCategoryDao.value

  public override fun seriesSortOrderDao(): SeriesSortOrderDao = _seriesSortOrderDao.value

  public override fun tombstoneDao(): TombstoneDao = _tombstoneDao.value

  public override fun tvProviderProgramDao(): TvProviderProgramDao = _tvProviderProgramDao.value

  public override fun downloadDao(): DownloadDao = _downloadDao.value

  public override fun recordingDao(): RecordingDao = _recordingDao.value

  public override fun catalogBackfillDao(): CatalogBackfillDao = _catalogBackfillDao.value

  public override fun epgDao(): EpgDao = _epgDao.value

  public override fun metadataDao(): MetadataDao = _metadataDao.value

  public override fun trendingDao(): TrendingDao = _trendingDao.value

  public override fun subtitleDao(): SubtitleDao = _subtitleDao.value
}
