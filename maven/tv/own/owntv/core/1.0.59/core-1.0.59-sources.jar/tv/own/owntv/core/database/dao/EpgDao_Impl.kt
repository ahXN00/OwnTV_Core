package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.appendPlaceholders
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.getTotalChangedRows
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.EpgChannelEntity
import tv.own.owntv.core.database.entity.EpgChannelIcon
import tv.own.owntv.core.database.entity.EpgChannelName
import tv.own.owntv.core.database.entity.EpgHashProjection
import tv.own.owntv.core.database.entity.EpgProgrammeEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class EpgDao_Impl(
  __db: RoomDatabase,
) : EpgDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfEpgChannelEntity: EntityInsertAdapter<EpgChannelEntity>

  private val __insertAdapterOfEpgProgrammeEntity: EntityInsertAdapter<EpgProgrammeEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfEpgChannelEntity = object : EntityInsertAdapter<EpgChannelEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `epg_channels` (`id`,`sourceId`,`epgChannelId`,`displayName`,`iconUrl`,`normName`,`normId`) VALUES (nullif(?, 0),?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: EpgChannelEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        statement.bindText(3, entity.epgChannelId)
        val _tmpDisplayName: String? = entity.displayName
        if (_tmpDisplayName == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpDisplayName)
        }
        val _tmpIconUrl: String? = entity.iconUrl
        if (_tmpIconUrl == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpIconUrl)
        }
        val _tmpNormName: String? = entity.normName
        if (_tmpNormName == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpNormName)
        }
        val _tmpNormId: String? = entity.normId
        if (_tmpNormId == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpNormId)
        }
      }
    }
    this.__insertAdapterOfEpgProgrammeEntity = object : EntityInsertAdapter<EpgProgrammeEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `epg_programmes` (`id`,`sourceId`,`epgChannelId`,`startMs`,`stopMs`,`title`,`description`,`contentHash`) VALUES (nullif(?, 0),?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: EpgProgrammeEntity) {
        statement.bindLong(1, entity.id)
        statement.bindLong(2, entity.sourceId)
        statement.bindText(3, entity.epgChannelId)
        statement.bindLong(4, entity.startMs)
        statement.bindLong(5, entity.stopMs)
        statement.bindText(6, entity.title)
        val _tmpDescription: String? = entity.description
        if (_tmpDescription == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpDescription)
        }
        statement.bindLong(8, entity.contentHash.toLong())
      }
    }
  }

  public override suspend fun upsertChannels(channels: List<EpgChannelEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfEpgChannelEntity.insert(_connection, channels)
  }

  public override suspend fun upsertProgrammes(programmes: List<EpgProgrammeEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfEpgProgrammeEntity.insert(_connection, programmes)
  }

  public override suspend fun epgHashesForChannel(sourceId: Long, epgChannelId: String): List<EpgHashProjection> {
    val _sql: String = "SELECT id, epgChannelId, startMs, contentHash FROM epg_programmes WHERE sourceId = ? AND epgChannelId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindText(_argIndex, epgChannelId)
        val _columnIndexOfId: Int = 0
        val _columnIndexOfEpgChannelId: Int = 1
        val _columnIndexOfStartMs: Int = 2
        val _columnIndexOfContentHash: Int = 3
        val _result: MutableList<EpgHashProjection> = mutableListOf()
        while (_stmt.step()) {
          val _item: EpgHashProjection
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = EpgHashProjection(_tmpId,_tmpEpgChannelId,_tmpStartMs,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun nowPlaying(epgChannelId: String, now: Long): EpgProgrammeEntity? {
    val _sql: String = "SELECT * FROM epg_programmes WHERE epgChannelId = ? AND startMs <= ? AND stopMs > ? ORDER BY startMs DESC LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        _argIndex = 3
        _stmt.bindLong(_argIndex, now)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: EpgProgrammeEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _result = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun previousProgramme(epgChannelId: String, now: Long): EpgProgrammeEntity? {
    val _sql: String = "SELECT * FROM epg_programmes WHERE epgChannelId = ? AND stopMs <= ? ORDER BY stopMs DESC LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: EpgProgrammeEntity?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _result = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun upcoming(
    epgChannelId: String,
    now: Long,
    limit: Int,
  ): Flow<List<EpgProgrammeEntity>> {
    val _sql: String = "SELECT * FROM epg_programmes WHERE epgChannelId = ? AND stopMs > ? ORDER BY startMs ASC LIMIT ?"
    return createFlow(__db, false, arrayOf("epg_programmes")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        _argIndex = 3
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<EpgProgrammeEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: EpgProgrammeEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun coverageDays(epgChannelId: String): Int? {
    val _sql: String = "SELECT (MAX(stopMs) - MIN(startMs)) / 86400000 FROM epg_programmes WHERE epgChannelId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        val _result: Int?
        if (_stmt.step()) {
          val _tmp: Int?
          if (_stmt.isNull(0)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(0).toInt()
          }
          _result = _tmp
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun programmeDescription(programmeId: Long): String? {
    val _sql: String = "SELECT description FROM epg_programmes WHERE id = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, programmeId)
        val _result: String?
        if (_stmt.step()) {
          if (_stmt.isNull(0)) {
            _result = null
          } else {
            _result = _stmt.getText(0)
          }
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun programmesForChannel(
    epgKey: String,
    from: Long,
    to: Long,
  ): List<EpgProgrammeEntity> {
    val _sql: String = "SELECT * FROM epg_programmes WHERE epgChannelId = ? AND startMs > ? - 86400000 AND stopMs > ? AND startMs < ? ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgKey)
        _argIndex = 2
        _stmt.bindLong(_argIndex, from)
        _argIndex = 3
        _stmt.bindLong(_argIndex, from)
        _argIndex = 4
        _stmt.bindLong(_argIndex, to)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfEpgChannelId: Int = getColumnIndexOrThrow(_stmt, "epgChannelId")
        val _columnIndexOfStartMs: Int = getColumnIndexOrThrow(_stmt, "startMs")
        val _columnIndexOfStopMs: Int = getColumnIndexOrThrow(_stmt, "stopMs")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfDescription: Int = getColumnIndexOrThrow(_stmt, "description")
        val _columnIndexOfContentHash: Int = getColumnIndexOrThrow(_stmt, "contentHash")
        val _result: MutableList<EpgProgrammeEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: EpgProgrammeEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun programmeSummariesForChannel(
    epgKey: String,
    from: Long,
    to: Long,
  ): List<EpgProgrammeEntity> {
    val _sql: String = "SELECT id, sourceId, epgChannelId, startMs, stopMs, title, NULL AS description, 0 AS contentHash FROM epg_programmes WHERE epgChannelId = ? AND startMs > ? - 86400000 AND stopMs > ? AND startMs < ? ORDER BY startMs ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgKey)
        _argIndex = 2
        _stmt.bindLong(_argIndex, from)
        _argIndex = 3
        _stmt.bindLong(_argIndex, from)
        _argIndex = 4
        _stmt.bindLong(_argIndex, to)
        val _columnIndexOfId: Int = 0
        val _columnIndexOfSourceId: Int = 1
        val _columnIndexOfEpgChannelId: Int = 2
        val _columnIndexOfStartMs: Int = 3
        val _columnIndexOfStopMs: Int = 4
        val _columnIndexOfTitle: Int = 5
        val _columnIndexOfDescription: Int = 6
        val _columnIndexOfContentHash: Int = 7
        val _result: MutableList<EpgProgrammeEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: EpgProgrammeEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun programmeSummariesForChannels(
    epgKeys: List<String>,
    from: Long,
    to: Long,
  ): List<EpgProgrammeEntity> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT id, sourceId, epgChannelId, startMs, stopMs, title, NULL AS description, 0 AS contentHash FROM epg_programmes WHERE epgChannelId IN (")
    val _inputSize: Int = epgKeys.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND startMs > ")
    _stringBuilder.append("?")
    _stringBuilder.append(" - 86400000 AND stopMs > ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND startMs < ")
    _stringBuilder.append("?")
    _stringBuilder.append(" ORDER BY epgChannelId ASC, startMs ASC")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in epgKeys) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _argIndex = 1 + _inputSize
        _stmt.bindLong(_argIndex, from)
        _argIndex = 2 + _inputSize
        _stmt.bindLong(_argIndex, from)
        _argIndex = 3 + _inputSize
        _stmt.bindLong(_argIndex, to)
        val _columnIndexOfId: Int = 0
        val _columnIndexOfSourceId: Int = 1
        val _columnIndexOfEpgChannelId: Int = 2
        val _columnIndexOfStartMs: Int = 3
        val _columnIndexOfStopMs: Int = 4
        val _columnIndexOfTitle: Int = 5
        val _columnIndexOfDescription: Int = 6
        val _columnIndexOfContentHash: Int = 7
        val _result: MutableList<EpgProgrammeEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: EpgProgrammeEntity
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpStartMs: Long
          _tmpStartMs = _stmt.getLong(_columnIndexOfStartMs)
          val _tmpStopMs: Long
          _tmpStopMs = _stmt.getLong(_columnIndexOfStopMs)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpDescription: String?
          if (_stmt.isNull(_columnIndexOfDescription)) {
            _tmpDescription = null
          } else {
            _tmpDescription = _stmt.getText(_columnIndexOfDescription)
          }
          val _tmpContentHash: Int
          _tmpContentHash = _stmt.getLong(_columnIndexOfContentHash).toInt()
          _item_1 = EpgProgrammeEntity(_tmpId,_tmpSourceId,_tmpEpgChannelId,_tmpStartMs,_tmpStopMs,_tmpTitle,_tmpDescription,_tmpContentHash)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countForSources(sourceIds: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(*) FROM epg_programmes WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countUpcomingForChannel(epgChannelId: String, now: Long): Int {
    val _sql: String = "SELECT COUNT(*) FROM epg_programmes WHERE epgChannelId = ? AND stopMs > ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun countForSource(sourceId: Long): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM epg_programmes WHERE sourceId = ?"
    return createFlow(__db, false, arrayOf("epg_programmes")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun countGuideChannels(sourceIds: List<Long>): Int {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT COUNT(DISTINCT epgChannelId) FROM epg_programmes WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun guideChannelNames(limit: Int): List<EpgChannelName> {
    val _sql: String = "SELECT epgChannelId, displayName, normName, normId FROM epg_channels LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, limit.toLong())
        val _columnIndexOfEpgChannelId: Int = 0
        val _columnIndexOfDisplayName: Int = 1
        val _columnIndexOfNormName: Int = 2
        val _columnIndexOfNormId: Int = 3
        val _result: MutableList<EpgChannelName> = mutableListOf()
        while (_stmt.step()) {
          val _item: EpgChannelName
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpDisplayName: String?
          if (_stmt.isNull(_columnIndexOfDisplayName)) {
            _tmpDisplayName = null
          } else {
            _tmpDisplayName = _stmt.getText(_columnIndexOfDisplayName)
          }
          val _tmpNormName: String?
          if (_stmt.isNull(_columnIndexOfNormName)) {
            _tmpNormName = null
          } else {
            _tmpNormName = _stmt.getText(_columnIndexOfNormName)
          }
          val _tmpNormId: String?
          if (_stmt.isNull(_columnIndexOfNormId)) {
            _tmpNormId = null
          } else {
            _tmpNormId = _stmt.getText(_columnIndexOfNormId)
          }
          _item = EpgChannelName(_tmpEpgChannelId,_tmpDisplayName,_tmpNormName,_tmpNormId)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun guideProgrammeChannelIds(limit: Int): List<String> {
    val _sql: String = "SELECT DISTINCT epgChannelId FROM epg_programmes LIMIT ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, limit.toLong())
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeChannelIcons(sourceIds: List<Long>): Flow<List<EpgChannelIcon>> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT epgChannelId, iconUrl FROM epg_channels WHERE sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND iconUrl IS NOT NULL AND iconUrl != ''")
    val _sql: String = _stringBuilder.toString()
    return createFlow(__db, false, arrayOf("epg_channels")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfEpgChannelId: Int = 0
        val _columnIndexOfIconUrl: Int = 1
        val _result: MutableList<EpgChannelIcon> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: EpgChannelIcon
          val _tmpEpgChannelId: String
          _tmpEpgChannelId = _stmt.getText(_columnIndexOfEpgChannelId)
          val _tmpIconUrl: String
          _tmpIconUrl = _stmt.getText(_columnIndexOfIconUrl)
          _item_1 = EpgChannelIcon(_tmpEpgChannelId,_tmpIconUrl)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun sourcesWithIconsFor(epgChannelIds: List<String>): List<Long> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT DISTINCT sourceId FROM epg_channels WHERE epgChannelId IN (")
    val _inputSize: Int = epgChannelIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(") AND iconUrl IS NOT NULL AND iconUrl != ''")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in epgChannelIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _result: MutableList<Long> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: Long
          _item_1 = _stmt.getLong(0)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun epgChannelIdsForSource(sourceId: Long): List<String> {
    val _sql: String = "SELECT epgChannelId FROM epg_channels WHERE sourceId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearSource(sourceId: Long) {
    val _sql: String = "DELETE FROM epg_programmes WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteProgrammesByIds(ids: List<Long>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM epg_programmes WHERE id IN (")
    val _inputSize: Int = ids.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: Long in ids) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteProgrammesForChannels(sourceId: Long, epgChannelIds: List<String>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM epg_programmes WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND epgChannelId IN (")
    val _inputSize: Int = epgChannelIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in epgChannelIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun prune(before: Long) {
    val _sql: String = "DELETE FROM epg_programmes WHERE stopMs < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, before)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun pruneFuture(after: Long) {
    val _sql: String = "DELETE FROM epg_programmes WHERE startMs > ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, after)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun collapseDuplicateProgrammes(): Int {
    val _sql: String = "DELETE FROM epg_programmes WHERE id IN (SELECT a.id FROM epg_programmes a JOIN epg_programmes b ON a.epgChannelId = b.epgChannelId AND a.id <> b.id AND a.title = b.title AND a.startMs < b.stopMs AND b.startMs < a.stopMs AND ((b.stopMs - b.startMs) > (a.stopMs - a.startMs) OR ((b.stopMs - b.startMs) = (a.stopMs - a.startMs) AND b.id < a.id)))"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
        getTotalChangedRows(_connection)
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun pruneOutsideWindow(
    sourceId: Long,
    from: Long,
    to: Long,
  ) {
    val _sql: String = "DELETE FROM epg_programmes WHERE sourceId = ? AND (stopMs <= ? OR startMs >= ?)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        _stmt.bindLong(_argIndex, from)
        _argIndex = 3
        _stmt.bindLong(_argIndex, to)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearChannel(epgChannelId: String) {
    val _sql: String = "DELETE FROM epg_programmes WHERE epgChannelId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearChannelForSources(epgChannelId: String, sourceIds: List<Long>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM epg_programmes WHERE epgChannelId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND sourceId IN (")
    val _inputSize: Int = sourceIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, epgChannelId)
        _argIndex = 2
        for (_item: Long in sourceIds) {
          _stmt.bindLong(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteChannelsByEpgIds(sourceId: Long, epgChannelIds: List<String>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("DELETE FROM epg_channels WHERE sourceId = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" AND epgChannelId IN (")
    val _inputSize: Int = epgChannelIds.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 2
        for (_item: String in epgChannelIds) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearChannelsForSource(sourceId: Long) {
    val _sql: String = "DELETE FROM epg_channels WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
