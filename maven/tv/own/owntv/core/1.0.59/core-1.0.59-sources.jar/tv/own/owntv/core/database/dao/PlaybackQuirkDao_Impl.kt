package tv.own.owntv.core.database.dao

import androidx.room.EntityInsertAdapter
import androidx.room.RoomDatabase
import androidx.room.coroutines.createFlow
import androidx.room.util.getColumnIndexOrThrow
import androidx.room.util.performInTransactionSuspending
import androidx.room.util.performSuspending
import androidx.sqlite.SQLiteStatement
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow
import tv.own.owntv.core.database.entity.PlaybackQuirkEntity

@Generated(value = ["androidx.room.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL"])
public class PlaybackQuirkDao_Impl(
  __db: RoomDatabase,
) : PlaybackQuirkDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfPlaybackQuirkEntity: EntityInsertAdapter<PlaybackQuirkEntity>

  private val __insertAdapterOfPlaybackQuirkEntity_1: EntityInsertAdapter<PlaybackQuirkEntity>
  init {
    this.__db = __db
    this.__insertAdapterOfPlaybackQuirkEntity = object : EntityInsertAdapter<PlaybackQuirkEntity>() {
      protected override fun createQuery(): String = "INSERT OR IGNORE INTO `playback_quirks` (`contentKey`,`sourceId`,`mediaType`,`enginePin`,`audioOnly`,`audioDelayMs`,`updatedAt`) VALUES (?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: PlaybackQuirkEntity) {
        statement.bindText(1, entity.contentKey)
        statement.bindLong(2, entity.sourceId)
        statement.bindText(3, entity.mediaType)
        val _tmpEnginePin: String? = entity.enginePin
        if (_tmpEnginePin == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpEnginePin)
        }
        val _tmpAudioOnly: Boolean? = entity.audioOnly
        val _tmp: Int? = _tmpAudioOnly?.let { if (it) 1 else 0 }
        if (_tmp == null) {
          statement.bindNull(5)
        } else {
          statement.bindLong(5, _tmp.toLong())
        }
        val _tmpAudioDelayMs: Int? = entity.audioDelayMs
        if (_tmpAudioDelayMs == null) {
          statement.bindNull(6)
        } else {
          statement.bindLong(6, _tmpAudioDelayMs.toLong())
        }
        statement.bindLong(7, entity.updatedAt)
      }
    }
    this.__insertAdapterOfPlaybackQuirkEntity_1 = object : EntityInsertAdapter<PlaybackQuirkEntity>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `playback_quirks` (`contentKey`,`sourceId`,`mediaType`,`enginePin`,`audioOnly`,`audioDelayMs`,`updatedAt`) VALUES (?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: PlaybackQuirkEntity) {
        statement.bindText(1, entity.contentKey)
        statement.bindLong(2, entity.sourceId)
        statement.bindText(3, entity.mediaType)
        val _tmpEnginePin: String? = entity.enginePin
        if (_tmpEnginePin == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpEnginePin)
        }
        val _tmpAudioOnly: Boolean? = entity.audioOnly
        val _tmp: Int? = _tmpAudioOnly?.let { if (it) 1 else 0 }
        if (_tmp == null) {
          statement.bindNull(5)
        } else {
          statement.bindLong(5, _tmp.toLong())
        }
        val _tmpAudioDelayMs: Int? = entity.audioDelayMs
        if (_tmpAudioDelayMs == null) {
          statement.bindNull(6)
        } else {
          statement.bindLong(6, _tmpAudioDelayMs.toLong())
        }
        statement.bindLong(7, entity.updatedAt)
      }
    }
  }

  public override suspend fun insertIfMissing(row: PlaybackQuirkEntity): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfPlaybackQuirkEntity.insert(_connection, row)
  }

  public override suspend fun insertAll(rows: List<PlaybackQuirkEntity>): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfPlaybackQuirkEntity_1.insert(_connection, rows)
  }

  public override suspend fun setEnginePin(
    contentKey: String,
    sourceId: Long,
    mediaType: String,
    pin: String?,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.setEnginePin(contentKey, sourceId, mediaType, pin)
  }

  public override suspend fun setAudioOnly(
    contentKey: String,
    sourceId: Long,
    mediaType: String,
    audioOnly: Boolean,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.setAudioOnly(contentKey, sourceId, mediaType, audioOnly)
  }

  public override suspend fun setAudioDelay(
    contentKey: String,
    sourceId: Long,
    mediaType: String,
    audioDelayMs: Int?,
  ): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.setAudioDelay(contentKey, sourceId, mediaType, audioDelayMs)
  }

  public override suspend fun clearVodPins(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.clearVodPins()
  }

  public override suspend fun clearLivePins(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.clearLivePins()
  }

  public override suspend fun clearAudioDelays(): Unit = performInTransactionSuspending(__db) {
    super@PlaybackQuirkDao_Impl.clearAudioDelays()
  }

  public override suspend fun `get`(contentKey: String): PlaybackQuirkEntity? {
    val _sql: String = "SELECT * FROM playback_quirks WHERE contentKey = ? LIMIT 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, contentKey)
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfEnginePin: Int = getColumnIndexOrThrow(_stmt, "enginePin")
        val _columnIndexOfAudioOnly: Int = getColumnIndexOrThrow(_stmt, "audioOnly")
        val _columnIndexOfAudioDelayMs: Int = getColumnIndexOrThrow(_stmt, "audioDelayMs")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: PlaybackQuirkEntity?
        if (_stmt.step()) {
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: String
          _tmpMediaType = _stmt.getText(_columnIndexOfMediaType)
          val _tmpEnginePin: String?
          if (_stmt.isNull(_columnIndexOfEnginePin)) {
            _tmpEnginePin = null
          } else {
            _tmpEnginePin = _stmt.getText(_columnIndexOfEnginePin)
          }
          val _tmpAudioOnly: Boolean?
          val _tmp: Int?
          if (_stmt.isNull(_columnIndexOfAudioOnly)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(_columnIndexOfAudioOnly).toInt()
          }
          _tmpAudioOnly = _tmp?.let { it != 0 }
          val _tmpAudioDelayMs: Int?
          if (_stmt.isNull(_columnIndexOfAudioDelayMs)) {
            _tmpAudioDelayMs = null
          } else {
            _tmpAudioDelayMs = _stmt.getLong(_columnIndexOfAudioDelayMs).toInt()
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _result = PlaybackQuirkEntity(_tmpContentKey,_tmpSourceId,_tmpMediaType,_tmpEnginePin,_tmpAudioOnly,_tmpAudioDelayMs,_tmpUpdatedAt)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observePinned(pin: String, live: Boolean): Flow<List<String>> {
    val _sql: String = "SELECT contentKey FROM playback_quirks WHERE enginePin = ? AND (mediaType = 'LIVE') = ?"
    return createFlow(__db, false, arrayOf("playback_quirks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, pin)
        _argIndex = 2
        val _tmp: Int = if (live) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAudioOnly(): Flow<List<String>> {
    val _sql: String = "SELECT contentKey FROM playback_quirks WHERE audioOnly = 1"
    return createFlow(__db, false, arrayOf("playback_quirks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun observeAudioDelayCount(): Flow<Int> {
    val _sql: String = "SELECT COUNT(*) FROM playback_quirks WHERE audioDelayMs IS NOT NULL"
    return createFlow(__db, false, arrayOf("playback_quirks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllOnce(): List<PlaybackQuirkEntity> {
    val _sql: String = "SELECT * FROM playback_quirks"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfContentKey: Int = getColumnIndexOrThrow(_stmt, "contentKey")
        val _columnIndexOfSourceId: Int = getColumnIndexOrThrow(_stmt, "sourceId")
        val _columnIndexOfMediaType: Int = getColumnIndexOrThrow(_stmt, "mediaType")
        val _columnIndexOfEnginePin: Int = getColumnIndexOrThrow(_stmt, "enginePin")
        val _columnIndexOfAudioOnly: Int = getColumnIndexOrThrow(_stmt, "audioOnly")
        val _columnIndexOfAudioDelayMs: Int = getColumnIndexOrThrow(_stmt, "audioDelayMs")
        val _columnIndexOfUpdatedAt: Int = getColumnIndexOrThrow(_stmt, "updatedAt")
        val _result: MutableList<PlaybackQuirkEntity> = mutableListOf()
        while (_stmt.step()) {
          val _item: PlaybackQuirkEntity
          val _tmpContentKey: String
          _tmpContentKey = _stmt.getText(_columnIndexOfContentKey)
          val _tmpSourceId: Long
          _tmpSourceId = _stmt.getLong(_columnIndexOfSourceId)
          val _tmpMediaType: String
          _tmpMediaType = _stmt.getText(_columnIndexOfMediaType)
          val _tmpEnginePin: String?
          if (_stmt.isNull(_columnIndexOfEnginePin)) {
            _tmpEnginePin = null
          } else {
            _tmpEnginePin = _stmt.getText(_columnIndexOfEnginePin)
          }
          val _tmpAudioOnly: Boolean?
          val _tmp: Int?
          if (_stmt.isNull(_columnIndexOfAudioOnly)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(_columnIndexOfAudioOnly).toInt()
          }
          _tmpAudioOnly = _tmp?.let { it != 0 }
          val _tmpAudioDelayMs: Int?
          if (_stmt.isNull(_columnIndexOfAudioDelayMs)) {
            _tmpAudioDelayMs = null
          } else {
            _tmpAudioDelayMs = _stmt.getLong(_columnIndexOfAudioDelayMs).toInt()
          }
          val _tmpUpdatedAt: Long
          _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt)
          _item = PlaybackQuirkEntity(_tmpContentKey,_tmpSourceId,_tmpMediaType,_tmpEnginePin,_tmpAudioOnly,_tmpAudioDelayMs,_tmpUpdatedAt)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun count(): Int {
    val _sql: String = "SELECT COUNT(*) FROM playback_quirks"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateEnginePin(
    contentKey: String,
    pin: String?,
    now: Long,
  ) {
    val _sql: String = "UPDATE playback_quirks SET enginePin = ?, updatedAt = ? WHERE contentKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (pin == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, pin)
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        _argIndex = 3
        _stmt.bindText(_argIndex, contentKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateAudioOnly(
    contentKey: String,
    audioOnly: Boolean?,
    now: Long,
  ) {
    val _sql: String = "UPDATE playback_quirks SET audioOnly = ?, updatedAt = ? WHERE contentKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int? = audioOnly?.let { if (it) 1 else 0 }
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, _tmp.toLong())
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        _argIndex = 3
        _stmt.bindText(_argIndex, contentKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateAudioDelay(
    contentKey: String,
    audioDelayMs: Int?,
    now: Long,
  ) {
    val _sql: String = "UPDATE playback_quirks SET audioDelayMs = ?, updatedAt = ? WHERE contentKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (audioDelayMs == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, audioDelayMs.toLong())
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, now)
        _argIndex = 3
        _stmt.bindText(_argIndex, contentKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun dropEmptyRows() {
    val _sql: String = "DELETE FROM playback_quirks WHERE enginePin IS NULL AND audioOnly IS NULL AND audioDelayMs IS NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearVodPinColumn() {
    val _sql: String = "UPDATE playback_quirks SET enginePin = NULL WHERE mediaType != 'LIVE'"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearLivePinColumn() {
    val _sql: String = "UPDATE playback_quirks SET enginePin = NULL WHERE mediaType = 'LIVE'"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearAudioDelayColumn() {
    val _sql: String = "UPDATE playback_quirks SET audioDelayMs = NULL"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun migrateKey(
    legacyKey: String,
    stableKey: String,
    sourceId: Long,
  ) {
    val _sql: String = "UPDATE OR IGNORE playback_quirks SET contentKey = ?, sourceId = ? WHERE contentKey = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, stableKey)
        _argIndex = 2
        _stmt.bindLong(_argIndex, sourceId)
        _argIndex = 3
        _stmt.bindText(_argIndex, legacyKey)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteBySource(sourceId: Long) {
    val _sql: String = "DELETE FROM playback_quirks WHERE sourceId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, sourceId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredConverters(): List<KClass<*>> = emptyList()
  }
}
